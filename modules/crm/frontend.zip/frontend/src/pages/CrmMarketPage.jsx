import { useCallback, useEffect, useMemo, useState } from 'react';
import {
  fetchMarketHistory,
  fetchMarketHistoryResults,
  fetchMarketLeads,
  fetchMarketMessage,
  fetchMarketSettings,
  getBootData,
  importMarketLead,
  importMarketLeadsBulk,
  runMarketSearch,
  saveMarketMessage,
  saveMarketSettings,
} from '../api';

function IconSearch() {
  return (
    <svg className="crm-desk-search-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <circle cx="11" cy="11" r="8" />
      <path d="m21 21-4.3-4.3" />
    </svg>
  );
}

function marketViewHref(view) {
  try {
    const url = new URL(window.location.href);
    url.searchParams.set('module', url.searchParams.get('module') || 'crm');
    url.searchParams.set('view', view);
    return url.toString();
  } catch {
    return `?module=crm&view=${encodeURIComponent(view)}`;
  }
}

const COUNTRIES = ['Tanzania', 'Kenya', 'Uganda', 'Rwanda', 'South Africa', 'United Arab Emirates', 'India', 'United Kingdom', 'United States', 'China'];

export default function CrmMarketPage() {
  const boot = getBootData();
  const links = boot.links || {};
  const initial = boot.market || {};
  const view = String(initial.view || 'home');
  const isImport = view === 'import';
  const isSearch = view === 'search';
  const isHistory = view === 'history';
  const isMessage = view === 'message';
  const isSettings = view === 'settings';
  const isHome = view === 'home' || (!isImport && !isSearch && !isHistory && !isMessage && !isSettings);

  const [status, setStatus] = useState(initial.status || {});
  const [leads, setLeads] = useState(Array.isArray(initial.leads) ? initial.leads : []);
  const [search, setSearch] = useState('');
  const [selected, setSelected] = useState({});
  const [busyId, setBusyId] = useState('');
  const [bulkBusy, setBulkBusy] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [searchQ, setSearchQ] = useState(() => {
    try {
      return new URLSearchParams(window.location.search).get('q') || '';
    } catch {
      return '';
    }
  });
  const [searchLocation, setSearchLocation] = useState('Tanzania');
  const [searchBusy, setSearchBusy] = useState(false);
  const [searchRows, setSearchRows] = useState([]);
  const [historyRows, setHistoryRows] = useState([]);
  const [historyLoading, setHistoryLoading] = useState(false);
  const [historyOpen, setHistoryOpen] = useState(null);
  const [historyResults, setHistoryResults] = useState([]);
  const [historyBusy, setHistoryBusy] = useState(false);
  const [tplSubject, setTplSubject] = useState('');
  const [tplHtml, setTplHtml] = useState('');
  const [tplSendMode, setTplSendMode] = useState('manual');
  const [tplBusy, setTplBusy] = useState(false);
  const [setHost, setSetHost] = useState('');
  const [setKey, setSetKey] = useState('');
  const [setLimit, setSetLimit] = useState(50);
  const [setRegion, setSetRegion] = useState('tz');
  const [setLanguage, setSetLanguage] = useState('en');
  const [setKeyMasked, setSetKeyMasked] = useState('');
  const [setHasKey, setSetHasKey] = useState(false);
  const [setBusy, setSetBusy] = useState(false);

  const customersUrl = links.customersList || links.dashboard || '#';
  const selectedIds = useMemo(
    () => Object.keys(selected).filter((id) => selected[id]),
    [selected]
  );

  const refresh = useCallback(async (q = search) => {
    setError('');
    try {
      const data = await fetchMarketLeads(q);
      setStatus(data.status || {});
      setLeads(Array.isArray(data.leads) ? data.leads : []);
    } catch (e) {
      setError(e.message || 'Failed to load market leads.');
    }
  }, [search]);

  useEffect(() => {
    if (isImport || isHome) void refresh();
  }, [isImport, isHome, refresh]);

  useEffect(() => {
    if (!isHistory) return undefined;
    let cancelled = false;
    setHistoryLoading(true);
    fetchMarketHistory()
      .then((data) => {
        if (!cancelled) setHistoryRows(Array.isArray(data.records) ? data.records : []);
      })
      .catch((e) => {
        if (!cancelled) setError(e.message || 'Could not load saved searches.');
      })
      .finally(() => {
        if (!cancelled) setHistoryLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [isHistory]);

  useEffect(() => {
    if (!isMessage) return undefined;
    let cancelled = false;
    fetchMarketMessage()
      .then((data) => {
        if (cancelled) return;
        setTplSubject(String(data.subject || ''));
        setTplHtml(String(data.html || ''));
        setTplSendMode(data.sendMode === 'automatic' ? 'automatic' : 'manual');
      })
      .catch((e) => {
        if (!cancelled) setError(e.message || 'Could not load message template.');
      });
    return () => {
      cancelled = true;
    };
  }, [isMessage]);

  useEffect(() => {
    if (!isSettings) return undefined;
    let cancelled = false;
    fetchMarketSettings()
      .then((data) => {
        if (cancelled) return;
        setSetHost(String(data.host || ''));
        setSetLimit(Number(data.limit || 50));
        setSetRegion(String(data.region || 'tz'));
        setSetLanguage(String(data.language || 'en'));
        setSetKeyMasked(String(data.keyMasked || ''));
        setSetHasKey(Boolean(data.hasKey));
        setSetKey('');
      })
      .catch((e) => {
        if (!cancelled) setError(e.message || 'Could not load settings.');
      });
    return () => {
      cancelled = true;
    };
  }, [isSettings]);

  const toggleOne = (id) => {
    setSelected((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const toggleAll = () => {
    const importable = leads.filter((l) => !l.imported);
    const allOn = importable.length > 0 && importable.every((l) => selected[l.id]);
    if (allOn) {
      setSelected({});
      return;
    }
    const next = {};
    importable.forEach((l) => {
      next[l.id] = true;
    });
    setSelected(next);
  };

  const onImportOne = async (lead) => {
    setBusyId(lead.id);
    setError('');
    setMessage('');
    try {
      const data = await importMarketLead(lead.id);
      setMessage(data?.created === false ? 'Already in My Customers.' : 'Added to My Customers.');
      setSearchRows((prev) => prev.map((r) => (r.id === lead.id ? { ...r, imported: true } : r)));
      if (isImport || isHome) await refresh();
      setSelected((prev) => {
        const next = { ...prev };
        delete next[lead.id];
        return next;
      });
    } catch (e) {
      setError(e.message || 'Import failed.');
    } finally {
      setBusyId('');
    }
  };

  const onImportSelected = async () => {
    if (selectedIds.length === 0) return;
    setBulkBusy(true);
    setError('');
    setMessage('');
    try {
      const data = await importMarketLeadsBulk(selectedIds);
      setMessage(
        `Imported ${data.created || 0} lead(s)` +
          (data.skipped ? `, ${data.skipped} already present` : '') +
          '.'
      );
      setSelected({});
      await refresh();
    } catch (e) {
      setError(e.message || 'Bulk import failed.');
    } finally {
      setBulkBusy(false);
    }
  };

  const onRunSearch = async (e) => {
    e.preventDefault();
    setSearchBusy(true);
    setError('');
    setMessage('');
    try {
      const data = await runMarketSearch(searchQ, searchLocation);
      setSearchRows(Array.isArray(data.results) ? data.results : []);
      setMessage(
        `Saved ${data.inserted || 0} new prospect(s). ${data.skipped || 0} already stored.`
      );
    } catch (err) {
      setError(err.message || 'Search failed.');
    } finally {
      setSearchBusy(false);
    }
  };

  const onSaveMessage = async (e) => {
    e.preventDefault();
    setTplBusy(true);
    setError('');
    setMessage('');
    try {
      await saveMarketMessage({ subject: tplSubject, html: tplHtml, sendMode: tplSendMode });
      setMessage('Message template saved.');
    } catch (err) {
      setError(err.message || 'Could not save message.');
    } finally {
      setTplBusy(false);
    }
  };

  const onSaveSettings = async (e) => {
    e.preventDefault();
    setSetBusy(true);
    setError('');
    setMessage('');
    try {
      const data = await saveMarketSettings({
        host: setHost,
        key: setKey,
        limit: setLimit,
        region: setRegion,
        language: setLanguage,
      });
      setSetKeyMasked(String(data.keyMasked || ''));
      setSetHasKey(Boolean(data.hasKey));
      setSetKey('');
      setMessage('Settings saved.');
    } catch (err) {
      setError(err.message || 'Could not save settings.');
    } finally {
      setSetBusy(false);
    }
  };

  if (isHome) {
    const recent = leads.slice(0, 8);
    return (
      <div className="crm-desk-page crm-market-page">
        <header className="crm-market-hero crm-market-hero--compact">
          <div>
            <p className="crm-market-eyebrow">CRM Market</p>
            <h1 className="crm-market-title">Home</h1>
            <p className="crm-market-lead">Find businesses, save searches, and import prospects into CRM — no separate Node server required.</p>
          </div>
        </header>
        <section className="crm-market-status" aria-live="polite">
          <div className={`crm-market-pill ${status.connected ? 'is-ok' : 'is-warn'}`}>
            {status.connected ? 'Database connected' : 'Setup needed'}
          </div>
          <p>{status.message || 'Loading…'}</p>
          <p className="crm-market-meta">
            {Number(status.lead_count || leads.length || 0)} leads in the market store
            {status.database ? ` · ${status.database}` : ''}
          </p>
        </section>
        <section className="crm-market-home-grid">
          <a className="crm-market-home-card" href={marketViewHref('search')}>
            <h2>Search</h2>
            <p>Look up businesses by keyword and country. Results are saved as prospects.</p>
          </a>
          <a className="crm-market-home-card" href={marketViewHref('history')}>
            <h2>Saved search</h2>
            <p>Re-open previous search runs and the companies they returned.</p>
          </a>
          <a className="crm-market-home-card" href={marketViewHref('message')}>
            <h2>Message</h2>
            <p>Edit the outreach email subject and body used for market leads.</p>
          </a>
          <a className="crm-market-home-card" href={marketViewHref('settings')}>
            <h2>Settings</h2>
            <p>Configure the RapidAPI host, key, region, and result limit.</p>
          </a>
        </section>
        <section className="crm-market-table-wrap">
          <h2 className="crm-market-section-title">Recent leads</h2>
          {recent.length === 0 ? (
            <div className="crm-market-empty">
              <h2>No leads yet</h2>
              <p>Run a Search to collect prospects. They will appear here and in My Customers after import.</p>
            </div>
          ) : (
            <table className="crm-desk-table crm-market-table">
              <thead>
                <tr>
                  <th>Prospect</th>
                  <th>Location</th>
                  <th>Assigned to</th>
                  <th>Contact</th>
                </tr>
              </thead>
              <tbody>
                {recent.map((lead) => (
                  <tr key={lead.id}>
                    <td>
                      <div className="crm-market-name">{lead.name || lead.username || '—'}</div>
                      <div className="crm-market-sub">{lead.category || lead.source || ''}</div>
                    </td>
                    <td>{lead.location || '—'}</td>
                    <td>{lead.assigned_user_name || 'Unassigned'}</td>
                    <td>
                      <div className="crm-market-sub">{lead.email || '—'}</div>
                      <div className="crm-market-sub">{lead.phone || ''}</div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </section>
      </div>
    );
  }

  if (isMessage) {
    return (
      <div className="crm-desk-page crm-market-page">
        <header className="crm-market-hero crm-market-hero--compact">
          <div>
            <p className="crm-market-eyebrow">CRM Market</p>
            <h1 className="crm-market-title">Message</h1>
            <p className="crm-market-lead">Placeholders: {'{{BusinessName}}'}, {'{{Category}}'}, {'{{Location}}'}.</p>
          </div>
        </header>
        {(message || error) && (
          <div className={`crm-market-flash ${error ? 'is-error' : 'is-ok'}`} role="status">
            {error || message}
          </div>
        )}
        <form className="crm-market-form" onSubmit={(e) => void onSaveMessage(e)}>
          <label className="crm-market-field">
            <span>Subject</span>
            <input type="text" value={tplSubject} onChange={(e) => setTplSubject(e.target.value)} required />
          </label>
          <label className="crm-market-field">
            <span>Send mode</span>
            <select value={tplSendMode} onChange={(e) => setTplSendMode(e.target.value)}>
              <option value="manual">Manual</option>
              <option value="automatic">Automatic</option>
            </select>
          </label>
          <label className="crm-market-field">
            <span>HTML body</span>
            <textarea rows={14} value={tplHtml} onChange={(e) => setTplHtml(e.target.value)} />
          </label>
          <button type="submit" className="crm-desk-btn crm-desk-btn-primary" disabled={tplBusy}>
            {tplBusy ? 'Saving…' : 'Save message'}
          </button>
        </form>
      </div>
    );
  }

  if (isSettings) {
    return (
      <div className="crm-desk-page crm-market-page">
        <header className="crm-market-hero crm-market-hero--compact">
          <div>
            <p className="crm-market-eyebrow">CRM Market</p>
            <h1 className="crm-market-title">Settings</h1>
            <p className="crm-market-lead">Search API credentials used by CRM Market on this server.</p>
          </div>
        </header>
        {(message || error) && (
          <div className={`crm-market-flash ${error ? 'is-error' : 'is-ok'}`} role="status">
            {error || message}
          </div>
        )}
        <form className="crm-market-form" onSubmit={(e) => void onSaveSettings(e)}>
          <label className="crm-market-field">
            <span>RapidAPI host</span>
            <input type="text" value={setHost} onChange={(e) => setSetHost(e.target.value)} />
          </label>
          <label className="crm-market-field">
            <span>API key {setHasKey ? `(saved: ${setKeyMasked})` : '(not set)'}</span>
            <input
              type="password"
              value={setKey}
              onChange={(e) => setSetKey(e.target.value)}
              placeholder={setHasKey ? 'Leave blank to keep the current key' : 'Paste RapidAPI key'}
              autoComplete="off"
            />
          </label>
          <label className="crm-market-field">
            <span>Result limit</span>
            <input type="number" min="1" max="100" value={setLimit} onChange={(e) => setSetLimit(Number(e.target.value) || 50)} />
          </label>
          <label className="crm-market-field">
            <span>Region</span>
            <input type="text" value={setRegion} onChange={(e) => setSetRegion(e.target.value)} />
          </label>
          <label className="crm-market-field">
            <span>Language</span>
            <input type="text" value={setLanguage} onChange={(e) => setSetLanguage(e.target.value)} />
          </label>
          <button type="submit" className="crm-desk-btn crm-desk-btn-primary" disabled={setBusy}>
            {setBusy ? 'Saving…' : 'Save settings'}
          </button>
        </form>
      </div>
    );
  }

  if (isSearch) {
    return (
      <div className="crm-desk-page crm-market-page">
        <header className="crm-market-hero crm-market-hero--compact">
          <div>
            <p className="crm-market-eyebrow">CRM Market</p>
            <h1 className="crm-market-title">Search</h1>
          </div>
        </header>
        <form
          className="crm-market-toolbar"
          onSubmit={(e) => {
            void onRunSearch(e);
          }}
        >
          <div className="crm-desk-search">
            <IconSearch />
            <input
              type="search"
              value={searchQ}
              onChange={(e) => setSearchQ(e.target.value)}
              placeholder="Keyword or business name…"
              aria-label="Search"
            />
          </div>
          <select
            className="crm-desk-btn crm-desk-btn-secondary"
            value={searchLocation}
            onChange={(e) => setSearchLocation(e.target.value)}
            aria-label="Location"
          >
            {COUNTRIES.map((c) => (
              <option key={c} value={c}>{c}</option>
            ))}
          </select>
          <button type="submit" className="crm-desk-btn crm-desk-btn-primary" disabled={searchBusy}>
            {searchBusy ? 'Searching…' : 'Search'}
          </button>
        </form>
        {(message || error) && (
          <div className={`crm-market-flash ${error ? 'is-error' : 'is-ok'}`} role="status">
            {error || message}
          </div>
        )}
        <section className="crm-market-table-wrap">
          {searchRows.length === 0 ? (
            <div className="crm-market-empty">
              <h2>{searchBusy ? 'Searching…' : 'No results yet'}</h2>
              <p>Enter a keyword and location, then Search. Prospects are saved and assigned to sales users.</p>
            </div>
          ) : (
            <table className="crm-desk-table crm-market-table">
              <thead>
                <tr>
                  <th scope="col">Prospect</th>
                  <th scope="col">Category</th>
                  <th scope="col">Location</th>
                  <th scope="col">Assigned to</th>
                  <th scope="col">Contact</th>
                  <th scope="col">Action</th>
                </tr>
              </thead>
              <tbody>
                {searchRows.map((lead) => (
                  <tr key={lead.id} className={lead.imported ? 'is-imported' : ''}>
                    <td>
                      <div className="crm-market-name">{lead.name || lead.username || '—'}</div>
                      {lead.username ? <div className="crm-market-sub">@{lead.username}</div> : null}
                    </td>
                    <td>{lead.category || '—'}</td>
                    <td>{lead.location || '—'}</td>
                    <td>
                      <span className="crm-desk-badge crm-desk-badge-lead">
                        {lead.assigned_user_name || 'Unassigned'}
                      </span>
                    </td>
                    <td>
                      <div className="crm-market-sub">{lead.email || '—'}</div>
                      <div className="crm-market-sub">{lead.phone || ''}</div>
                    </td>
                    <td>
                      {lead.imported ? (
                        <span className="crm-market-sub">In CRM</span>
                      ) : (
                        <button
                          type="button"
                          className="crm-desk-btn crm-desk-btn-secondary crm-market-import-btn"
                          disabled={busyId === lead.id}
                          onClick={() => onImportOne(lead)}
                        >
                          {busyId === lead.id ? 'Adding…' : 'Add to CRM'}
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </section>
      </div>
    );
  }

  if (isHistory) {
    const openResults = async (row) => {
      setHistoryOpen(row);
      setHistoryBusy(true);
      setHistoryResults([]);
      try {
        const data = await fetchMarketHistoryResults(row.id);
        setHistoryResults(Array.isArray(data.rows) ? data.rows : []);
      } catch (err) {
        setError(err.message || 'Could not load results.');
      } finally {
        setHistoryBusy(false);
      }
    };

    return (
      <div className="crm-desk-page crm-market-page">
        <header className="crm-market-hero crm-market-hero--compact">
          <div>
            <p className="crm-market-eyebrow">CRM Market</p>
            <h1 className="crm-market-title">Saved search</h1>
          </div>
        </header>
        {error ? (
          <div className="crm-market-flash is-error" role="status">{error}</div>
        ) : null}
        {historyOpen ? (
          <section className="crm-market-table-wrap">
            <p className="crm-market-meta">
              <button type="button" className="crm-desk-btn crm-desk-btn-secondary" onClick={() => { setHistoryOpen(null); setHistoryResults([]); }}>
                Back to saved searches
              </button>
              {' '}
              {historyBusy ? 'Loading results...' : `${historyResults.length} result(s) — ${historyOpen.query || '-'}`}
            </p>
            <table className="crm-desk-table crm-market-table">
              <thead>
                <tr>
                  <th>No</th>
                  <th>Name</th>
                  <th>Type</th>
                  <th>City</th>
                  <th>Phone</th>
                  <th>Assigned to</th>
                  <th>Website</th>
                  <th>Email</th>
                </tr>
              </thead>
              <tbody>
                {historyBusy ? (
                  <tr><td colSpan={8}>Loading companies for this search...</td></tr>
                ) : historyResults.length === 0 ? (
                  <tr><td colSpan={8}>No companies stored for this search.</td></tr>
                ) : (
                  historyResults.map((r, i) => (
                    <tr key={r.id || i}>
                      <td>{i + 1}</td>
                      <td>{r.name || '—'}</td>
                      <td>{r.type || '—'}</td>
                      <td>{r.city || '—'}</td>
                      <td>{r.phone || '—'}</td>
                      <td>{r.assignedToName || 'Unassigned'}</td>
                      <td>
                        {r.website ? (
                          <a href={String(r.website).startsWith('http') ? r.website : `https://${r.website}`} target="_blank" rel="noreferrer">
                            {String(r.website).replace(/^https?:\/\//i, '')}
                          </a>
                        ) : '—'}
                      </td>
                      <td>{r.email || '—'}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </section>
        ) : (
          <section className="crm-market-table-wrap">
            {historyLoading ? (
              <div className="crm-market-empty"><h2>Loading saved searches…</h2></div>
            ) : historyRows.length === 0 ? (
              <div className="crm-market-empty">
                <h2>No saved searches yet</h2>
                <p>Run a Search in CRM Market. Each run is stored here.</p>
              </div>
            ) : (
              <table className="crm-desk-table crm-market-table">
                <thead>
                  <tr>
                    <th>Search</th>
                    <th>Location</th>
                    <th>Results</th>
                    <th>Saved</th>
                    <th>When</th>
                    <th></th>
                  </tr>
                </thead>
                <tbody>
                  {historyRows.map((row) => (
                    <tr key={row.id}>
                      <td>{row.query || '—'}</td>
                      <td>{row.location || '—'}</td>
                      <td>{row.resultCount ?? 0}</td>
                      <td>{row.insertedCount ?? 0}</td>
                      <td>{row.createdAt ? new Date(row.createdAt).toLocaleString() : '—'}</td>
                      <td>
                        <button type="button" className="crm-desk-btn crm-desk-btn-secondary" onClick={() => void openResults(row)}>
                          Open
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </section>
        )}
      </div>
    );
  }

  return (
    <div className="crm-desk-page crm-market-page">
      <header className="crm-market-hero crm-market-hero--compact">
        <div>
          <p className="crm-market-eyebrow">CRM Market</p>
          <h1 className="crm-market-title">Import to CRM</h1>
        </div>
        <div className="crm-market-actions">
          <a href={customersUrl} className="crm-desk-btn crm-desk-btn-secondary">
            My Customers
          </a>
        </div>
      </header>

      <section className="crm-market-status" aria-live="polite">
        <div className={`crm-market-pill ${status.connected ? 'is-ok' : 'is-warn'}`}>
          {status.connected ? 'Database connected' : 'Setup needed'}
        </div>
        <p>{status.message || 'Loading…'}</p>
        <p className="crm-market-meta">
          {Number(status.lead_count || 0)} leads ready to import
          {status.database ? ` · ${status.database}` : ''}
        </p>
      </section>

      {(message || error) && (
        <div className={`crm-market-flash ${error ? 'is-error' : 'is-ok'}`} role="status">
          {error || message}
        </div>
      )}

      <section className="crm-market-toolbar">
        <form
          className="crm-desk-search"
          onSubmit={(e) => {
            e.preventDefault();
            refresh(search);
          }}
        >
          <IconSearch />
          <input
            type="search"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search name, @username, email, location…"
            aria-label="Search market leads"
          />
        </form>
        <div className="crm-market-toolbar-actions">
          <button type="button" className="crm-desk-btn crm-desk-btn-secondary" onClick={() => refresh()}>
            Refresh
          </button>
          <button
            type="button"
            className="crm-desk-btn crm-desk-btn-primary"
            disabled={bulkBusy || selectedIds.length === 0}
            onClick={onImportSelected}
          >
            {bulkBusy ? 'Importing…' : `Import selected (${selectedIds.length})`}
          </button>
        </div>
      </section>

      <section className="crm-market-table-wrap">
        {leads.length === 0 ? (
          <div className="crm-market-empty">
            <h2>No leads yet</h2>
            <p>Use Search from the ERP sidebar, then return here to import into My Customers.</p>
          </div>
        ) : (
          <table className="crm-desk-table crm-market-table">
            <thead>
              <tr>
                <th scope="col" className="crm-market-check">
                  <input
                    type="checkbox"
                    aria-label="Select all importable leads"
                    onChange={toggleAll}
                    checked={
                      leads.some((l) => !l.imported) &&
                      leads.filter((l) => !l.imported).every((l) => selected[l.id])
                    }
                  />
                </th>
                <th scope="col">Prospect</th>
                <th scope="col">Category</th>
                <th scope="col">Location</th>
                <th scope="col">Assigned to</th>
                <th scope="col">Score</th>
                <th scope="col">Contact</th>
                <th scope="col">Status</th>
                <th scope="col">Action</th>
              </tr>
            </thead>
            <tbody>
              {leads.map((lead) => (
                <tr key={lead.id} className={lead.imported ? 'is-imported' : ''}>
                  <td className="crm-market-check">
                    <input
                      type="checkbox"
                      disabled={!!lead.imported}
                      checked={!!selected[lead.id]}
                      onChange={() => toggleOne(lead.id)}
                      aria-label={`Select ${lead.name || lead.username}`}
                    />
                  </td>
                  <td>
                    <div className="crm-market-name">{lead.name || lead.username || '—'}</div>
                    {lead.username ? <div className="crm-market-sub">@{lead.username}</div> : null}
                    {lead.source ? <div className="crm-market-sub">{lead.source}</div> : null}
                  </td>
                  <td>{lead.category || '—'}</td>
                  <td>{lead.location || '—'}</td>
                  <td>
                    <span className="crm-desk-badge crm-desk-badge-lead">
                      {lead.assigned_user_name || 'Unassigned'}
                    </span>
                  </td>
                  <td>
                    <span className="crm-market-score">{lead.score ?? 0}</span>
                    {lead.level ? <span className="crm-market-sub"> {lead.level}</span> : null}
                  </td>
                  <td>
                    <div className="crm-market-sub">{lead.email || '—'}</div>
                    <div className="crm-market-sub">{lead.phone || ''}</div>
                  </td>
                  <td>
                    {lead.imported ? (
                      <span className="crm-desk-badge crm-desk-badge-customer">In CRM</span>
                    ) : (
                      <span className="crm-desk-badge crm-desk-badge-lead">New</span>
                    )}
                  </td>
                  <td>
                    {lead.imported ? (
                      <span className="crm-market-sub">Imported</span>
                    ) : (
                      <button
                        type="button"
                        className="crm-desk-btn crm-desk-btn-secondary crm-market-import-btn"
                        disabled={busyId === lead.id}
                        onClick={() => onImportOne(lead)}
                      >
                        {busyId === lead.id ? 'Adding…' : 'Add to CRM'}
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </section>
    </div>
  );
}
