<?php
/**
 * Bridge between CRM Market and the Client Market (Ultimate Online Platform) MySQL store.
 */
declare(strict_types=1);

/**
 * @return array{host:string,port:int,user:string,password:string,database:string}
 */
function crmMarketMysqlConfig(): array
{
    $fallback = [
        'host' => '127.0.0.1',
        'port' => 3306,
        'user' => 'root',
        'password' => '',
        'database' => 'ultimate_online_platform',
    ];

    $configFile = dirname(__DIR__) . DIRECTORY_SEPARATOR . 'client Market'
        . DIRECTORY_SEPARATOR . 'frontend' . DIRECTORY_SEPARATOR . 'data'
        . DIRECTORY_SEPARATOR . 'mysql-config.json';

    if (is_file($configFile)) {
        $raw = @file_get_contents($configFile);
        $decoded = is_string($raw) ? json_decode($raw, true) : null;
        if (is_array($decoded)) {
            return array_merge($fallback, [
                'host' => (string) ($decoded['host'] ?? $fallback['host']),
                'port' => (int) ($decoded['port'] ?? $fallback['port']),
                'user' => (string) ($decoded['user'] ?? $fallback['user']),
                'password' => (string) ($decoded['password'] ?? $fallback['password']),
                'database' => (string) ($decoded['database'] ?? $fallback['database']),
            ]);
        }
    }

    return $fallback;
}

function crmMarketIsLoopbackUrl(string $url): bool
{
    $host = strtolower((string) (parse_url($url, PHP_URL_HOST) ?: ''));
    return $host === 'localhost' || $host === '127.0.0.1' || $host === '::1';
}

function crmMarketPublicEmbedUrl(): string
{
    if (function_exists('crmDeskPublicUrl')) {
        $path = rtrim(crmDeskPublicUrl('market-app/proxy.php'), '/');
    } else {
        $script = str_replace('\\', '/', (string) ($_SERVER['SCRIPT_NAME'] ?? ''));
        $path = '/modules/crm/market-app/proxy.php';
        if (preg_match('#^(.*?/modules/crm)(?:/|$)#i', $script, $m)) {
            $path = rtrim($m[1], '/') . '/market-app/proxy.php';
        }
    }
    if (str_starts_with($path, 'http://') || str_starts_with($path, 'https://')) {
        return rtrim($path, '/');
    }
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || ((string) ($_SERVER['SERVER_PORT'] ?? '') === '443')
        || (strtolower((string) ($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '')) === 'https');
    $host = trim(explode(',', (string) ($_SERVER['HTTP_X_FORWARDED_HOST'] ?? $_SERVER['HTTP_HOST'] ?? 'localhost'))[0]);
    return ($https ? 'https' : 'http') . '://' . $host . $path;
}

function crmMarketAppUrl(): string
{
    $url = '';
    try {
        global $pdo;
        if ($pdo instanceof PDO) {
            $stmt = $pdo->prepare("SELECT setting_value FROM system_settings WHERE setting_key = 'crm_market_app_url' LIMIT 1");
            $stmt->execute();
            $url = trim((string) ($stmt->fetchColumn() ?: ''));
        }
    } catch (Throwable $e) {
        $url = '';
    }

    if ($url !== '' && !crmMarketIsLoopbackUrl($url)) {
        return rtrim($url, '/');
    }

    return rtrim(crmMarketPublicEmbedUrl(), '/');
}

/**
 * @return PDO|null
 */
function crmMarketPdo(bool $ensureSchema = true): ?PDO
{
    static $cached = null;
    static $failed = false;

    if ($failed) {
        return null;
    }
    if ($cached instanceof PDO) {
        return $cached;
    }

    $cfg = crmMarketMysqlConfig();

    try {
        $admin = new PDO(
            sprintf('mysql:host=%s;port=%d;charset=utf8mb4', $cfg['host'], $cfg['port']),
            $cfg['user'],
            $cfg['password'],
            [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            ]
        );

        if ($ensureSchema) {
            $dbName = preg_replace('/[^a-zA-Z0-9_]/', '', $cfg['database']) ?: 'ultimate_online_platform';
            $admin->exec(
                "CREATE DATABASE IF NOT EXISTS `{$dbName}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci"
            );
            $admin->exec("USE `{$dbName}`");
            $admin->exec("
                CREATE TABLE IF NOT EXISTS customers (
                  id VARCHAR(191) PRIMARY KEY,
                  username VARCHAR(191) NOT NULL,
                  name VARCHAR(255) NOT NULL,
                  category VARCHAR(191) NOT NULL,
                  location VARCHAR(191) NULL,
                  email VARCHAR(191) NULL,
                  phone VARCHAR(64) NULL,
                  website VARCHAR(255) NULL,
                  score INT NOT NULL DEFAULT 0,
                  level VARCHAR(32) NOT NULL,
                  source VARCHAR(191) NOT NULL,
                  keyword VARCHAR(191) NULL,
                  found_at DATETIME NOT NULL,
                  channel VARCHAR(32) NOT NULL DEFAULT 'apify',
                  emailed_at DATETIME NULL,
                  assigned_to INT NULL,
                  assigned_user_name VARCHAR(191) NULL,
                  UNIQUE KEY uq_channel_user (channel, username)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            ");
        }

        try {
            $admin->exec("ALTER TABLE customers ADD COLUMN assigned_to INT NULL");
        } catch (Throwable $e) {}
        try {
            $admin->exec("ALTER TABLE customers ADD COLUMN assigned_user_name VARCHAR(191) NULL");
        } catch (Throwable $e) {}
        try {
            $admin->exec("
                CREATE TABLE IF NOT EXISTS search_history (
                  id VARCHAR(191) PRIMARY KEY,
                  search_text VARCHAR(255) NOT NULL,
                  location VARCHAR(191) NULL,
                  category VARCHAR(191) NULL,
                  result_count INT NOT NULL DEFAULT 0,
                  inserted_count INT NOT NULL DEFAULT 0,
                  skipped_count INT NOT NULL DEFAULT 0,
                  created_at DATETIME NOT NULL
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            ");
            $admin->exec("
                CREATE TABLE IF NOT EXISTS search_results (
                  id VARCHAR(191) NOT NULL,
                  history_id VARCHAR(191) NOT NULL,
                  sort_order INT NOT NULL DEFAULT 0,
                  name VARCHAR(255) NOT NULL,
                  type VARCHAR(191) NULL,
                  city VARCHAR(191) NULL,
                  address TEXT NULL,
                  phone VARCHAR(64) NULL,
                  website VARCHAR(255) NULL,
                  email VARCHAR(191) NULL,
                  rating DECIMAL(4,2) NULL,
                  assigned_to INT NULL,
                  assigned_user_name VARCHAR(191) NULL,
                  PRIMARY KEY (history_id, id),
                  KEY idx_search_results_history (history_id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            ");
        } catch (Throwable $e) {}

        $cached = new PDO(
            sprintf(
                'mysql:host=%s;port=%d;dbname=%s;charset=utf8mb4',
                $cfg['host'],
                $cfg['port'],
                $cfg['database']
            ),
            $cfg['user'],
            $cfg['password'],
            [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            ]
        );

        return $cached;
    } catch (Throwable $e) {
        $failed = true;
        return null;
    }
}

/**
 * @return array{connected:bool,database:string,app_url:string,lead_count:int,message:string}
 */
function crmMarketStatus(): array
{
    $cfg = crmMarketMysqlConfig();
    $pdo = crmMarketPdo(true);
    $count = 0;
    $connected = $pdo instanceof PDO;
    $message = $connected
        ? 'Client Market database is ready.'
        : 'Could not connect to Client Market MySQL. Start XAMPP MySQL, then open Client Market once to finish setup.';

    if ($connected) {
        try {
            $count = (int) $pdo->query('SELECT COUNT(*) FROM customers')->fetchColumn();
        } catch (Throwable $e) {
            $connected = false;
            $message = 'Client Market tables are missing. Open Client Market to initialize them.';
        }
    }

    return [
        'connected' => $connected,
        'database' => $cfg['database'],
        'app_url' => crmMarketAppUrl(),
        'lead_count' => $count,
        'message' => $message,
    ];
}

/**
 * @return array{assigned_to:int,assigned_user_name:string}|null
 */
function crmMarketLookupAssignment(PDO $erpPdo, string $name, string $email = '', string $phone = ''): ?array
{
    $norm = static function (string $value): string {
        $value = strtolower(trim($value));
        $value = preg_replace('/[^a-z0-9]+/', ' ', $value) ?? '';
        return trim(preg_replace('/\s+/', ' ', $value) ?? '');
    };

    $keys = array_values(array_filter([
        $norm($name),
        strtolower(trim($email)),
        preg_replace('/\D/', '', $phone) ?: '',
    ]));

    if (empty($keys)) {
        return null;
    }

    try {
        $stmt = $erpPdo->query("
            SELECT c.company_name, c.created_by, u.full_name, u.username
            FROM customers c
            INNER JOIN users u ON u.id = c.created_by
            WHERE c.company_name IS NOT NULL AND TRIM(c.company_name) <> ''
              AND LOWER(TRIM(u.department)) = 'sales'
        ");
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $companyKey = $norm((string) ($row['company_name'] ?? ''));
            foreach ($keys as $key) {
                if ($key !== '' && ($companyKey === $key || str_contains($companyKey, $key) || str_contains($key, $companyKey))) {
                    $owner = trim((string) ($row['full_name'] ?? ''));
                    if ($owner === '') {
                        $owner = (string) ($row['username'] ?? '');
                    }
                    if ($owner !== '' && (int) ($row['created_by'] ?? 0) > 0) {
                        return [
                            'assigned_to' => (int) $row['created_by'],
                            'assigned_user_name' => $owner,
                        ];
                    }
                }
            }
        }

        $stmt = $erpPdo->query("
            SELECT cc.organization, cc.name, cc.email, cc.phone, cc.created_by, u.full_name, u.username
            FROM crm_contacts cc
            INNER JOIN users u ON u.id = cc.created_by
            WHERE LOWER(TRIM(u.department)) = 'sales'
        ");
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $candidates = [
                $norm((string) ($row['organization'] ?? '')),
                $norm((string) ($row['name'] ?? '')),
                strtolower(trim((string) ($row['email'] ?? ''))),
                preg_replace('/\D/', '', (string) ($row['phone'] ?? '')) ?: '',
            ];
            foreach ($keys as $key) {
                foreach ($candidates as $candidate) {
                    if ($candidate === '' || $key === '') {
                        continue;
                    }
                    if ($candidate === $key || str_contains($candidate, $key) || str_contains($key, $candidate)) {
                        $owner = trim((string) ($row['full_name'] ?? ''));
                        if ($owner === '') {
                            $owner = (string) ($row['username'] ?? '');
                        }
                        if ($owner !== '' && (int) ($row['created_by'] ?? 0) > 0) {
                            return [
                                'assigned_to' => (int) $row['created_by'],
                                'assigned_user_name' => $owner,
                            ];
                        }
                    }
                }
            }
        }
    } catch (Throwable $e) {
        return null;
    }

    return null;
}

/**
 * Assign unassigned market leads round-robin to active ERP sales reps / users.
 */
function crmMarketAllocateLeadsRoundRobin(): int
{
    $marketPdo = crmMarketPdo(true);
    if (!($marketPdo instanceof PDO)) {
        return 0;
    }

    global $pdo;
    $erpPdo = $pdo;
    if (!($erpPdo instanceof PDO)) {
        return 0;
    }

    try {
        $stmt = $erpPdo->query("
            SELECT id, full_name, username
            FROM users
            WHERE COALESCE(is_active, 1) = 1
              AND LOWER(TRIM(department)) = 'sales'
            ORDER BY id ASC
        ");
        $users = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
        if (empty($users)) {
            return 0;
        }

        $salesIds = array_map(static fn(array $u): int => (int) ($u['id'] ?? 0), $users);
        $salesIds = array_values(array_filter($salesIds, static fn(int $id): bool => $id > 0));
        $inList = implode(',', $salesIds);

        $counts = [];
        foreach ($users as $u) {
            $counts[(int) $u['id']] = 0;
        }
        $countStmt = $marketPdo->query("SELECT assigned_to, COUNT(*) AS c FROM customers WHERE assigned_to IS NOT NULL GROUP BY assigned_to");
        while ($row = $countStmt->fetch(PDO::FETCH_ASSOC)) {
            $uid = (int) ($row['assigned_to'] ?? 0);
            if ($uid > 0 && in_array($uid, $salesIds, true)) {
                $counts[$uid] = (int) ($row['c'] ?? 0);
            }
        }

        $unassigned = $marketPdo->query("
            SELECT id, name, email, phone
            FROM customers
            WHERE assigned_to IS NULL
               OR assigned_user_name IS NULL
               OR TRIM(assigned_user_name) = ''
               OR assigned_to NOT IN ($inList)
            ORDER BY found_at ASC
        ")->fetchAll(PDO::FETCH_ASSOC) ?: [];
        if (empty($unassigned)) {
            return 0;
        }

        $assignedCount = 0;
        $updateStmt = $marketPdo->prepare("UPDATE customers SET assigned_to = ?, assigned_user_name = ? WHERE id = ?");

        foreach ($unassigned as $lead) {
            $matched = crmMarketLookupAssignment(
                $erpPdo,
                (string) ($lead['name'] ?? ''),
                (string) ($lead['email'] ?? ''),
                (string) ($lead['phone'] ?? '')
            );

            if ($matched !== null) {
                $uid = (int) $matched['assigned_to'];
                $counts[$uid] = ($counts[$uid] ?? 0) + 1;
                $updateStmt->execute([
                    $uid,
                    (string) $matched['assigned_user_name'],
                    (string) $lead['id'],
                ]);
                $assignedCount++;
                continue;
            }

            $pick = $users[0];
            $min = $counts[(int) $pick['id']] ?? 0;
            foreach ($users as $u) {
                $uid = (int) $u['id'];
                $c = $counts[$uid] ?? 0;
                if ($c < $min) {
                    $min = $c;
                    $pick = $u;
                }
            }
            $uid = (int) $pick['id'];
            $counts[$uid] = ($counts[$uid] ?? 0) + 1;
            $dispName = trim((string) ($pick['full_name'] ?? ''));
            if ($dispName === '') {
                $dispName = (string) ($pick['username'] ?? ('User #' . $uid));
            }
            $updateStmt->execute([$uid, $dispName, (string) $lead['id']]);
            $assignedCount++;
        }

        return $assignedCount;
    } catch (Throwable $e) {
        return 0;
    }
}

/**
 * @return list<array<string, mixed>>
 */
function crmMarketListLeads(int $limit = 100, string $search = '', ?int $assignedTo = null): array
{
    crmMarketAllocateLeadsRoundRobin();

    $pdo = crmMarketPdo(true);
    if (!($pdo instanceof PDO)) {
        return [];
    }

    $limit = max(1, min(500, $limit));
    $search = trim($search);
    $params = [];
    $where = [];
    $sql = '
        SELECT id, username, name, category, location, email, phone, website,
               score, level, source, keyword, found_at, channel, emailed_at,
               assigned_to, assigned_user_name
        FROM customers
    ';
    if ($assignedTo !== null && $assignedTo > 0) {
        $where[] = 'assigned_to = ?';
        $params[] = $assignedTo;
    }
    if ($search !== '') {
        $where[] = '(name LIKE ? OR username LIKE ? OR email LIKE ? OR phone LIKE ? OR category LIKE ? OR location LIKE ? OR assigned_user_name LIKE ?)';
        $like = '%' . $search . '%';
        array_push($params, $like, $like, $like, $like, $like, $like, $like);
    }
    if ($where) {
        $sql .= ' WHERE ' . implode(' AND ', $where);
    }
    $sql .= ' ORDER BY found_at DESC LIMIT ' . $limit;

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];

    return array_map(static function (array $row): array {
        $clean = static function ($value): string {
            $text = (string) ($value ?? '');
            $text = str_replace("\xEF\xBF\xBD", '', $text);
            $text = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F]/', '', $text) ?? $text;
            $text = trim(preg_replace('/\s+/', ' ', $text) ?? $text);
            if ($text === '?' || $text === '') {
                return '';
            }
            return $text;
        };

        return [
            'id' => (string) ($row['id'] ?? ''),
            'username' => $clean($row['username'] ?? ''),
            'name' => $clean($row['name'] ?? '') ?: 'Unknown',
            'category' => $clean($row['category'] ?? ''),
            'location' => $clean($row['location'] ?? ''),
            'email' => $clean($row['email'] ?? ''),
            'phone' => $clean($row['phone'] ?? ''),
            'website' => $clean($row['website'] ?? ''),
            'score' => (int) ($row['score'] ?? 0),
            'level' => (string) ($row['level'] ?? ''),
            'source' => $clean($row['source'] ?? ''),
            'keyword' => $clean($row['keyword'] ?? ''),
            'found_at' => (string) ($row['found_at'] ?? ''),
            'channel' => (string) ($row['channel'] ?? ''),
            'emailed_at' => $row['emailed_at'] !== null ? (string) $row['emailed_at'] : '',
            'assigned_to' => $row['assigned_to'] !== null ? (int) $row['assigned_to'] : null,
            'assigned_user_name' => $clean($row['assigned_user_name'] ?? '') ?: 'Unassigned',
        ];
    }, $rows);
}

/**
 * Prospects for the logged-in account: assigned_to user id or matching display name / username.
 *
 * @return list<array<string, mixed>>
 */
function crmMarketListLeadsForUser(int $userId, int $limit = 100, string $search = ''): array
{
    crmMarketAllocateLeadsRoundRobin();

    if ($userId <= 0) {
        return [];
    }

    $pdo = crmMarketPdo(true);
    if (!($pdo instanceof PDO)) {
        return [];
    }

    $aliases = [];
    foreach (['full_name', 'name', 'username', 'user_name'] as $key) {
        $value = strtolower(trim((string) ($_SESSION[$key] ?? '')));
        if ($value !== '') {
            $aliases[$value] = true;
        }
    }
    $names = array_keys($aliases);

    $limit = max(1, min(500, $limit));
    $search = trim($search);
    $params = [$userId];
    $nameSql = '';
    if ($names) {
        $placeholders = implode(',', array_fill(0, count($names), '?'));
        $nameSql = " OR LOWER(TRIM(assigned_user_name)) IN ({$placeholders})";
        foreach ($names as $name) {
            $params[] = $name;
        }
    }

    $sql = '
        SELECT id, username, name, category, location, email, phone, website,
               score, level, source, keyword, found_at, channel, emailed_at,
               assigned_to, assigned_user_name
        FROM customers
        WHERE (assigned_to = ?' . $nameSql . ')
    ';
    if ($search !== '') {
        $sql .= ' AND (name LIKE ? OR username LIKE ? OR email LIKE ? OR phone LIKE ? OR category LIKE ? OR location LIKE ? OR assigned_user_name LIKE ?)';
        $like = '%' . $search . '%';
        array_push($params, $like, $like, $like, $like, $like, $like, $like);
    }
    $sql .= ' ORDER BY found_at DESC LIMIT ' . $limit;

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];

    return array_map(static function (array $row): array {
            $clean = static function ($value): string {
                $text = (string) ($value ?? '');
                $text = str_replace("\xEF\xBF\xBD", '', $text);
                $text = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F]/', '', $text) ?? $text;
                $text = trim(preg_replace('/\s+/', ' ', $text) ?? $text);
                if ($text === '?' || $text === '') {
                    return '';
                }
                return $text;
            };

            return [
                'id' => (string) ($row['id'] ?? ''),
                'username' => $clean($row['username'] ?? ''),
                'name' => $clean($row['name'] ?? '') ?: 'Unknown',
                'category' => $clean($row['category'] ?? ''),
                'location' => $clean($row['location'] ?? ''),
                'email' => $clean($row['email'] ?? ''),
                'phone' => $clean($row['phone'] ?? ''),
                'website' => $clean($row['website'] ?? ''),
                'score' => (int) ($row['score'] ?? 0),
                'level' => (string) ($row['level'] ?? ''),
                'source' => $clean($row['source'] ?? ''),
                'keyword' => $clean($row['keyword'] ?? ''),
                'found_at' => (string) ($row['found_at'] ?? ''),
                'channel' => (string) ($row['channel'] ?? ''),
                'emailed_at' => $row['emailed_at'] !== null ? (string) $row['emailed_at'] : '',
                'assigned_to' => $row['assigned_to'] !== null ? (int) $row['assigned_to'] : null,
                'assigned_user_name' => $clean($row['assigned_user_name'] ?? '') ?: 'Unassigned',
            ];
        }, $rows);
}

/**
 * @param list<string> $importedIds market lead ids already in CRM for this company
 * @return list<string>
 */
function crmMarketImportedIds(PDO $crmPdo, int $companyId): array
{
    try {
        $stmt = $crmPdo->prepare("
            SELECT notes FROM crm_contacts
            WHERE company_id = ? AND notes LIKE '%market_id:%'
        ");
        $stmt->execute([$companyId]);
        $ids = [];
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $notes = (string) ($row['notes'] ?? '');
            if (preg_match_all('/market_id:([^\s\n]+)/', $notes, $m)) {
                foreach ($m[1] as $id) {
                    $ids[] = (string) $id;
                }
            }
        }
        return array_values(array_unique($ids));
    } catch (Throwable $e) {
        return [];
    }
}

/**
 * @return array<string, mixed>|null
 */
function crmMarketGetLead(string $leadId): ?array
{
    $pdo = crmMarketPdo(true);
    if (!($pdo instanceof PDO) || $leadId === '') {
        return null;
    }

    $stmt = $pdo->prepare('SELECT * FROM customers WHERE id = ? LIMIT 1');
    $stmt->execute([$leadId]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!is_array($row)) {
        return null;
    }

    return [
        'id' => (string) ($row['id'] ?? ''),
        'username' => (string) ($row['username'] ?? ''),
        'name' => (string) ($row['name'] ?? ''),
        'category' => (string) ($row['category'] ?? ''),
        'location' => (string) ($row['location'] ?? ''),
        'email' => $row['email'] !== null ? (string) $row['email'] : '',
        'phone' => $row['phone'] !== null ? (string) $row['phone'] : '',
        'website' => $row['website'] !== null ? (string) $row['website'] : '',
        'score' => (int) ($row['score'] ?? 0),
        'level' => (string) ($row['level'] ?? ''),
        'source' => (string) ($row['source'] ?? ''),
        'keyword' => (string) ($row['keyword'] ?? ''),
        'found_at' => (string) ($row['found_at'] ?? ''),
        'channel' => (string) ($row['channel'] ?? ''),
    ];
}

/**
 * Import a Client Market lead into CRM as a lead contact (My Customers).
 *
 * @return array{contact:array<string,mixed>,created:bool,message:string}
 */
function crmMarketImportLead(PDO $crmPdo, int $companyId, int $userId, string $leadId): array
{
    require_once __DIR__ . '/crm-engine.php';
    crmEngineEnsureSchema($crmPdo);

    $lead = crmMarketGetLead($leadId);
    if ($lead === null) {
        throw new InvalidArgumentException('Market lead not found.');
    }

    $existingIds = crmMarketImportedIds($crmPdo, $companyId);
    if (in_array($leadId, $existingIds, true)) {
        $stmt = $crmPdo->prepare("
            SELECT * FROM crm_contacts
            WHERE company_id = ? AND notes LIKE ?
            ORDER BY id DESC LIMIT 1
        ");
        $stmt->execute([$companyId, '%market_id:' . $leadId . '%']);
        $existing = $stmt->fetch(PDO::FETCH_ASSOC);
        if (is_array($existing)) {
            return [
                'contact' => $existing,
                'created' => false,
                'message' => 'Already in My Customers.',
            ];
        }
    }

    $displayName = trim((string) ($lead['name'] ?? ''));
    if ($displayName === '') {
        $displayName = trim((string) ($lead['username'] ?? ''));
    }
    if ($displayName === '') {
        throw new InvalidArgumentException('Lead has no name.');
    }

    $username = trim((string) ($lead['username'] ?? ''));
    $category = trim((string) ($lead['category'] ?? ''));
    $location = trim((string) ($lead['location'] ?? ''));
    $sourceLabel = trim((string) ($lead['source'] ?? 'Client Market'));
    $notes = implode("\n", array_filter([
        'market_id:' . $leadId,
        $username !== '' ? '@' . $username : '',
        $category !== '' ? 'Category: ' . $category : '',
        $location !== '' ? 'Location: ' . $location : '',
        'Score: ' . (int) ($lead['score'] ?? 0) . ' (' . (string) ($lead['level'] ?? '') . ')',
        !empty($lead['website']) ? 'Website: ' . $lead['website'] : '',
        'Imported from CRM Market / Client Market',
    ]));

    $contact = crmEngineCreateContact($crmPdo, $companyId, $userId, [
        'name' => $displayName,
        'organization' => $category !== '' ? $category : ($username !== '' ? '@' . $username : null),
        'email' => trim((string) ($lead['email'] ?? '')),
        'phone' => trim((string) ($lead['phone'] ?? '')),
        'status' => 'lead',
        'source' => 'CRM Market: ' . ($sourceLabel !== '' ? $sourceLabel : 'Client Market'),
        'notes' => $notes,
    ]);

    return [
        'contact' => $contact,
        'created' => true,
        'message' => 'Added to My Customers.',
    ];
}

/**
 * @return array{host:string,key:string,limit:int,lat:float,lng:float,language:string,region:string}
 */
function crmMarketSearchLabConfig(): array
{
    $fallback = [
        'host' => 'local-business-search.p.rapidapi.com',
        'key' => '',
        'limit' => 50,
        'lat' => -6.369,
        'lng' => 34.889,
        'language' => 'en',
        'region' => 'tz',
    ];
    $file = dirname(__DIR__) . DIRECTORY_SEPARATOR . 'client Market'
        . DIRECTORY_SEPARATOR . 'frontend' . DIRECTORY_SEPARATOR . 'data'
        . DIRECTORY_SEPARATOR . 'search-lab.json';
    if (!is_file($file)) {
        return $fallback;
    }
    $raw = @file_get_contents($file);
    $decoded = is_string($raw) ? json_decode($raw, true) : null;
    if (!is_array($decoded)) {
        return $fallback;
    }
    return array_merge($fallback, [
        'host' => (string) ($decoded['host'] ?? $fallback['host']),
        'key' => (string) ($decoded['key'] ?? ''),
        'limit' => (int) ($decoded['limit'] ?? $fallback['limit']),
        'lat' => (float) ($decoded['lat'] ?? $fallback['lat']),
        'lng' => (float) ($decoded['lng'] ?? $fallback['lng']),
        'language' => (string) ($decoded['language'] ?? 'en'),
        'region' => (string) ($decoded['region'] ?? 'tz'),
    ]);
}

/**
 * @return array{lat:float,lng:float,code:string}|null
 */
function crmMarketCountryMeta(string $location): ?array
{
    static $centers = [
        'tanzania' => [-6.369, 34.889, 'tz'],
        'kenya' => [-0.024, 37.906, 'ke'],
        'uganda' => [1.373, 32.29, 'ug'],
        'rwanda' => [-1.94, 29.874, 'rw'],
        'south africa' => [-30.56, 22.938, 'za'],
        'united arab emirates' => [23.424, 53.848, 'ae'],
        'india' => [20.594, 78.963, 'in'],
        'united kingdom' => [55.378, -3.436, 'gb'],
        'united states' => [37.09, -95.713, 'us'],
        'china' => [35.862, 104.195, 'cn'],
    ];
    $key = strtolower(trim($location));
    if (!isset($centers[$key])) {
        return null;
    }
    [$lat, $lng, $code] = $centers[$key];
    return ['lat' => (float) $lat, 'lng' => (float) $lng, 'code' => $code];
}

/**
 * @return list<array<string, mixed>>
 */
function crmMarketNormalizeSearchPayload(mixed $payload): array
{
    if (!is_array($payload)) {
        return [];
    }
    $list = null;
    foreach (['data', 'results', 'businesses', 'items', 'suggestions', 'places'] as $k) {
        if (isset($payload[$k]) && is_array($payload[$k])) {
            $list = $payload[$k];
            break;
        }
    }
    if (!is_array($list)) {
        return [];
    }
    $out = [];
    foreach ($list as $i => $item) {
        if (!is_array($item)) {
            continue;
        }
        $types = [];
        if (isset($item['types']) && is_array($item['types'])) {
            $types = array_map('strval', $item['types']);
        }
        $name = trim((string) ($item['name'] ?? $item['title'] ?? $item['description'] ?? ''));
        if ($name === '' || strcasecmp($name, 'Unknown') === 0) {
            continue;
        }
        $out[] = [
            'id' => (string) ($item['business_id'] ?? $item['google_id'] ?? $item['place_id'] ?? $item['id'] ?? $i),
            'name' => $name,
            'phone' => $item['phone_number'] ?? $item['phone'] ?? '',
            'address' => (string) ($item['full_address'] ?? $item['address'] ?? $item['formatted_address'] ?? ''),
            'website' => (string) ($item['website'] ?? $item['site'] ?? ''),
            'email' => (string) ($item['email'] ?? ''),
            'rating' => isset($item['rating']) ? (float) $item['rating'] : null,
            'type' => (string) ($item['type'] ?? $item['category'] ?? ($types[0] ?? '')),
            'city' => (string) ($item['city'] ?? $item['locality'] ?? ''),
        ];
    }
    return $out;
}

/**
 * @return array{ok:bool,rows:list<array<string,mixed>>,error:string}
 */
function crmMarketRapidSearch(string $query, string $location): array
{
    $cfg = crmMarketSearchLabConfig();
    if (trim($cfg['key']) === '') {
        return ['ok' => false, 'rows' => [], 'error' => 'Search API key is missing in Client Market settings.'];
    }
    $meta = crmMarketCountryMeta($location);
    $lat = $meta['lat'] ?? $cfg['lat'];
    $lng = $meta['lng'] ?? $cfg['lng'];
    $region = $meta['code'] ?? $cfg['region'];
    $host = preg_replace('/^https?:\/\//', '', $cfg['host']) ?: $cfg['host'];
    $params = http_build_query([
        'query' => $query,
        'region' => $region,
        'language' => $cfg['language'],
        'lat' => $lat,
        'lng' => $lng,
        'coordinates' => $lat . ',' . $lng,
        'limit' => (string) min(100, max(20, (int) $cfg['limit'])),
    ]);
    $url = 'https://' . $host . '/search?' . $params;
    $ch = curl_init($url);
    if ($ch === false) {
        return ['ok' => false, 'rows' => [], 'error' => 'Could not start search request.'];
    }
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 45,
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/json',
            'x-rapidapi-host: ' . $host,
            'x-rapidapi-key: ' . $cfg['key'],
        ],
    ]);
    $raw = curl_exec($ch);
    $errno = curl_errno($ch);
    $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($raw === false || $errno) {
        return ['ok' => false, 'rows' => [], 'error' => 'Search request failed.'];
    }
    $payload = json_decode((string) $raw, true);
    if ($code >= 400) {
        $msg = is_array($payload) ? (string) ($payload['message'] ?? $payload['error'] ?? 'Search failed') : 'Search failed';
        return ['ok' => false, 'rows' => [], 'error' => $msg];
    }
    return ['ok' => true, 'rows' => crmMarketNormalizeSearchPayload(is_array($payload) ? $payload : []), 'error' => ''];
}

/**
 * @param array<string, mixed> $row
 * @return array{lead:array<string,mixed>,inserted:bool}
 */
function crmMarketSaveSearchRow(array $row, string $keyword, string $location): array
{
    $pdo = crmMarketPdo(true);
    if (!($pdo instanceof PDO)) {
        throw new RuntimeException('Client Market database is not available.');
    }
    $id = 'search-' . preg_replace('/[^a-zA-Z0-9_-]+/', '-', (string) ($row['id'] ?? uniqid('r', true)));
    $username = 's-' . strtolower(preg_replace('/[^a-z0-9]+/', '-', (string) ($row['id'] ?: $row['name']))) ;
    $username = substr($username, 0, 60) ?: ('s-' . substr(sha1($id), 0, 12));
    $name = trim((string) ($row['name'] ?? ''));
    $email = trim((string) ($row['email'] ?? '')) ?: null;
    $phone = trim((string) ($row['phone'] ?? '')) ?: null;
    $website = trim((string) ($row['website'] ?? '')) ?: null;
    $category = trim((string) ($row['type'] ?? '')) ?: 'Search lead';
    $loc = trim((string) ($row['city'] ?? $row['address'] ?? $location));
    $score = $email ? 70 : 50;
    $foundAt = date('Y-m-d H:i:s');

    $exists = $pdo->prepare('SELECT id FROM customers WHERE channel = ? AND username = ? LIMIT 1');
    $exists->execute(['search', $username]);
    $already = (string) ($exists->fetchColumn() ?: '');
    if ($already !== '') {
        $get = $pdo->prepare('SELECT * FROM customers WHERE id = ? LIMIT 1');
        $get->execute([$already]);
        $saved = $get->fetch(PDO::FETCH_ASSOC) ?: [];
        return ['lead' => crmMarketFormatLeadRow($saved), 'inserted' => false];
    }

    $pdo->prepare('
        INSERT INTO customers (
            id, username, name, category, location, email, phone, website,
            score, level, source, keyword, found_at, channel
        ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)
    ')->execute([
        $id,
        $username,
        $name,
        $category,
        $loc !== '' ? $loc : null,
        $email,
        $phone,
        $website,
        $score,
        $score >= 70 ? 'hot' : 'warm',
        'Search',
        $keyword,
        $foundAt,
        'search',
    ]);

    return ['lead' => crmMarketFormatLeadRow([
        'id' => $id,
        'username' => $username,
        'name' => $name,
        'category' => $category,
        'location' => $loc,
        'email' => $email,
        'phone' => $phone,
        'website' => $website,
        'score' => $score,
        'level' => $score >= 70 ? 'hot' : 'warm',
        'source' => 'Search',
        'keyword' => $keyword,
        'found_at' => $foundAt,
        'channel' => 'search',
        'emailed_at' => null,
        'assigned_to' => null,
        'assigned_user_name' => '',
    ]), 'inserted' => true];
}

/**
 * @param array<string, mixed> $row
 * @return array<string, mixed>
 */
function crmMarketFormatLeadRow(array $row): array
{
    return [
        'id' => (string) ($row['id'] ?? ''),
        'username' => (string) ($row['username'] ?? ''),
        'name' => (string) ($row['name'] ?? 'Unknown'),
        'category' => (string) ($row['category'] ?? ''),
        'location' => (string) ($row['location'] ?? ''),
        'email' => (string) ($row['email'] ?? ''),
        'phone' => (string) ($row['phone'] ?? ''),
        'website' => (string) ($row['website'] ?? ''),
        'score' => (int) ($row['score'] ?? 0),
        'level' => (string) ($row['level'] ?? ''),
        'source' => (string) ($row['source'] ?? ''),
        'keyword' => (string) ($row['keyword'] ?? ''),
        'found_at' => (string) ($row['found_at'] ?? ''),
        'channel' => (string) ($row['channel'] ?? ''),
        'emailed_at' => $row['emailed_at'] !== null ? (string) $row['emailed_at'] : '',
        'assigned_to' => isset($row['assigned_to']) && $row['assigned_to'] !== null ? (int) $row['assigned_to'] : null,
        'assigned_user_name' => trim((string) ($row['assigned_user_name'] ?? '')) ?: 'Unassigned',
    ];
}

/**
 * @return array{results:list<array<string,mixed>>,inserted:int,skipped:int}
 */
function crmMarketRunSearch(string $q, string $location): array
{
    $q = trim($q);
    $location = trim($location) ?: 'Tanzania';
    $query = trim($q . ' ' . $location);
    if ($query === '') {
        throw new InvalidArgumentException('Enter a search term.');
    }
    $found = crmMarketRapidSearch($query, $location);
    if (!$found['ok']) {
        throw new InvalidArgumentException($found['error'] !== '' ? $found['error'] : 'Search failed.');
    }
    $inserted = 0;
    $skipped = 0;
    $results = [];
    foreach ($found['rows'] as $row) {
        $saved = crmMarketSaveSearchRow($row, $query, $location);
        $results[] = $saved['lead'];
        if ($saved['inserted']) {
            $inserted++;
        } else {
            $skipped++;
        }
    }
    crmMarketAllocateLeadsRoundRobin();
    crmMarketRecordSearchHistory($query, $location, '', count($results), $inserted, $skipped, $found['rows']);
    return [
        'results' => $results,
        'inserted' => $inserted,
        'skipped' => $skipped,
    ];
}

function crmMarketRecordSearchHistory(
    string $query,
    string $location,
    string $category,
    int $resultCount,
    int $insertedCount,
    int $skippedCount,
    array $rows = []
): void {
    $pdo = crmMarketPdo(true);
    if (!($pdo instanceof PDO)) {
        return;
    }
    $id = 'hist-' . dechex(time()) . '-' . bin2hex(random_bytes(3));
    try {
        $pdo->prepare('
            INSERT INTO search_history
              (id, search_text, location, category, result_count, inserted_count, skipped_count, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, NOW())
        ')->execute([
            $id,
            substr($query !== '' ? $query : '(empty)', 0, 255),
            $location !== '' ? substr($location, 0, 191) : null,
            $category !== '' ? substr($category, 0, 191) : null,
            $resultCount,
            $insertedCount,
            $skippedCount,
        ]);
    } catch (Throwable $e) {
        return;
    }
    foreach ($rows as $i => $row) {
        if (!is_array($row)) {
            continue;
        }
        try {
            $pdo->prepare('
                INSERT INTO search_results
                  (id, history_id, sort_order, name, type, city, address, phone, website, email, rating, assigned_to, assigned_user_name)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ')->execute([
                substr((string) ($row['id'] ?? ('r' . $i)), 0, 191),
                $id,
                (int) $i,
                substr((string) ($row['name'] ?? 'Unknown'), 0, 255),
                substr((string) ($row['type'] ?? $row['category'] ?? ''), 0, 191) ?: null,
                substr((string) ($row['city'] ?? ''), 0, 191) ?: null,
                (string) ($row['address'] ?? ''),
                substr((string) ($row['phone'] ?? ''), 0, 64) ?: null,
                substr((string) ($row['website'] ?? ''), 0, 255) ?: null,
                substr((string) ($row['email'] ?? ''), 0, 191) ?: null,
                isset($row['rating']) && $row['rating'] !== '' && $row['rating'] !== null ? (float) $row['rating'] : null,
                isset($row['assignedTo']) ? (int) $row['assignedTo'] : null,
                isset($row['assignedToName']) ? (string) $row['assignedToName'] : null,
            ]);
        } catch (Throwable $e) {
            /* skip one row */
        }
    }
}

/**
 * @return list<array<string, mixed>>
 */
function crmMarketListSearchHistory(int $limit = 200): array
{
    $pdo = crmMarketPdo(true);
    $out = [];
    if ($pdo instanceof PDO) {
        try {
            $limit = max(1, min(500, $limit));
            $stmt = $pdo->query("
                SELECT id, search_text AS q, location, category,
                       result_count, inserted_count, skipped_count, created_at
                FROM search_history
                ORDER BY created_at DESC
                LIMIT {$limit}
            ");
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                $out[] = [
                    'id' => (string) ($row['id'] ?? ''),
                    'query' => (string) ($row['q'] ?? ''),
                    'location' => (string) ($row['location'] ?? ''),
                    'category' => (string) ($row['category'] ?? ''),
                    'resultCount' => (int) ($row['result_count'] ?? 0),
                    'insertedCount' => (int) ($row['inserted_count'] ?? 0),
                    'skippedCount' => (int) ($row['skipped_count'] ?? 0),
                    'createdAt' => (string) ($row['created_at'] ?? ''),
                ];
            }
        } catch (Throwable $e) {
            $out = [];
        }
    }
    if ($out) {
        return $out;
    }

    $file = dirname(__DIR__) . DIRECTORY_SEPARATOR . 'client Market'
        . DIRECTORY_SEPARATOR . 'frontend' . DIRECTORY_SEPARATOR . 'data'
        . DIRECTORY_SEPARATOR . 'search-history.json';
    if (!is_file($file)) {
        return [];
    }
    $raw = @file_get_contents($file);
    $decoded = is_string($raw) ? json_decode($raw, true) : null;
    if (!is_array($decoded)) {
        return [];
    }
    $records = [];
    foreach ($decoded as $row) {
        if (!is_array($row)) {
            continue;
        }
        $records[] = [
            'id' => (string) ($row['id'] ?? ''),
            'query' => (string) ($row['query'] ?? ''),
            'location' => (string) ($row['location'] ?? ''),
            'category' => (string) ($row['category'] ?? ''),
            'resultCount' => (int) ($row['resultCount'] ?? 0),
            'insertedCount' => (int) ($row['insertedCount'] ?? 0),
            'skippedCount' => (int) ($row['skippedCount'] ?? 0),
            'createdAt' => (string) ($row['createdAt'] ?? ''),
        ];
    }
    return $records;
}

/**
 * @return list<array<string, mixed>>
 */
function crmMarketListSearchHistoryResults(string $historyId): array
{
    $historyId = trim($historyId);
    if ($historyId === '') {
        return [];
    }
    $pdo = crmMarketPdo(true);
    if ($pdo instanceof PDO) {
        try {
            $stmt = $pdo->prepare('
                SELECT id, name, type, city, address, phone, website, email, rating,
                       assigned_to, assigned_user_name
                FROM search_results
                WHERE history_id = ?
                ORDER BY sort_order ASC
            ');
            $stmt->execute([$historyId]);
            $rows = [];
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                $rows[] = [
                    'id' => (string) ($row['id'] ?? ''),
                    'name' => (string) ($row['name'] ?? ''),
                    'type' => (string) ($row['type'] ?? ''),
                    'city' => (string) ($row['city'] ?? ''),
                    'address' => (string) ($row['address'] ?? ''),
                    'phone' => (string) ($row['phone'] ?? ''),
                    'website' => (string) ($row['website'] ?? ''),
                    'email' => (string) ($row['email'] ?? ''),
                    'rating' => $row['rating'] !== null ? (float) $row['rating'] : null,
                    'assignedTo' => $row['assigned_to'] !== null ? (int) $row['assigned_to'] : null,
                    'assignedToName' => (string) ($row['assigned_user_name'] ?? ''),
                ];
            }
            if ($rows) {
                return $rows;
            }
            $meta = $pdo->prepare('SELECT search_text FROM search_history WHERE id = ? LIMIT 1');
            $meta->execute([$historyId]);
            $keyword = trim((string) ($meta->fetchColumn() ?: ''));
            if ($keyword !== '') {
                $leads = crmMarketListLeads(100, $keyword);
                return array_map(static function (array $lead): array {
                    return [
                        'id' => $lead['id'],
                        'name' => $lead['name'],
                        'type' => $lead['category'],
                        'city' => $lead['location'],
                        'address' => $lead['location'],
                        'phone' => $lead['phone'],
                        'website' => $lead['website'],
                        'email' => $lead['email'],
                        'rating' => null,
                        'assignedTo' => $lead['assigned_to'],
                        'assignedToName' => $lead['assigned_user_name'],
                    ];
                }, $leads);
            }
        } catch (Throwable $e) {
            return [];
        }
    }
    return [];
}

function crmMarketFrontendDataDir(): string
{
    return dirname(__DIR__) . DIRECTORY_SEPARATOR . 'client Market'
        . DIRECTORY_SEPARATOR . 'frontend' . DIRECTORY_SEPARATOR . 'data';
}

function crmMarketMessageTemplatePath(): string
{
    $data = dirname(__DIR__) . DIRECTORY_SEPARATOR . 'client Market'
        . DIRECTORY_SEPARATOR . 'frontend' . DIRECTORY_SEPARATOR . 'data';
    if (!is_dir($data)) {
        @mkdir($data, 0775, true);
    }
    return $data . DIRECTORY_SEPARATOR . 'message-template.json';
}

/**
 * @return array{subject:string,html:string,logoUrl:?string,sendMode:string}
 */
function crmMarketDefaultMessageTemplate(): array
{
    return [
        'subject' => 'Construction materials for your next project',
        'html' => '<p>Hello {{BusinessName}},</p>
<p>We supply construction materials and can support your work in <strong>{{Category}}</strong> in {{Location}}.</p>
<p>Cement, steel, roofing, tiles and other building materials — delivered to keep your site moving.</p>
<p style="margin-top:20px">Best regards,<br/><strong>Ultimate General Trading</strong><br/>Construction Materials Sales Team</p>',
        'logoUrl' => null,
        'sendMode' => 'manual',
    ];
}

/**
 * @return array{subject:string,html:string,logoUrl:?string,sendMode:string}
 */
function crmMarketGetMessageTemplate(): array
{
    $fallback = crmMarketDefaultMessageTemplate();
    $file = crmMarketMessageTemplatePath();
    if (!is_file($file)) {
        return $fallback;
    }
    $raw = @file_get_contents($file);
    $decoded = is_string($raw) ? json_decode($raw, true) : null;
    if (!is_array($decoded)) {
        return $fallback;
    }
    $subject = trim((string) ($decoded['subject'] ?? $fallback['subject']));
    $html = trim((string) ($decoded['html'] ?? $fallback['html']));
    $sendMode = strtolower((string) ($decoded['sendMode'] ?? 'manual')) === 'automatic' ? 'automatic' : 'manual';
    $logo = $decoded['logoUrl'] ?? $decoded['logo_url'] ?? null;
    return [
        'subject' => $subject !== '' ? $subject : $fallback['subject'],
        'html' => $html !== '' ? $html : $fallback['html'],
        'logoUrl' => is_string($logo) && $logo !== '' ? $logo : null,
        'sendMode' => $sendMode,
    ];
}

/**
 * @param array<string, mixed> $input
 * @return array{subject:string,html:string,logoUrl:?string,sendMode:string}
 */
function crmMarketSaveMessageTemplate(array $input): array
{
    $current = crmMarketGetMessageTemplate();
    $next = [
        'subject' => trim((string) ($input['subject'] ?? $current['subject'])),
        'html' => (string) ($input['html'] ?? $current['html']),
        'logoUrl' => array_key_exists('logoUrl', $input)
            ? (is_string($input['logoUrl']) && $input['logoUrl'] !== '' ? $input['logoUrl'] : null)
            : $current['logoUrl'],
        'sendMode' => strtolower((string) ($input['sendMode'] ?? $current['sendMode'])) === 'automatic'
            ? 'automatic'
            : 'manual',
    ];
    if ($next['subject'] === '') {
        $next['subject'] = $current['subject'];
    }
    if (trim($next['html']) === '') {
        $next['html'] = $current['html'];
    }
    @file_put_contents(crmMarketMessageTemplatePath(), json_encode($next, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
    return $next;
}

/**
 * @return array<string, mixed>
 */
function crmMarketGetSearchSettingsPublic(): array
{
    $cfg = crmMarketSearchLabConfig();
    $file = dirname(__DIR__) . DIRECTORY_SEPARATOR . 'client Market'
        . DIRECTORY_SEPARATOR . 'frontend' . DIRECTORY_SEPARATOR . 'data'
        . DIRECTORY_SEPARATOR . 'search-lab.json';
    $extra = [];
    if (is_file($file)) {
        $decoded = json_decode((string) file_get_contents($file), true);
        if (is_array($decoded)) {
            $extra = $decoded;
        }
    }
    $key = (string) ($cfg['key'] ?? '');
    $masked = $key === '' ? '' : (str_repeat('•', max(0, strlen($key) - 4)) . substr($key, -4));
    return [
        'host' => (string) ($cfg['host'] ?? ''),
        'limit' => (int) ($cfg['limit'] ?? 50),
        'lat' => (float) ($cfg['lat'] ?? 0),
        'lng' => (float) ($cfg['lng'] ?? 0),
        'language' => (string) ($cfg['language'] ?? 'en'),
        'region' => (string) ($cfg['region'] ?? 'tz'),
        'mode' => (string) ($extra['mode'] ?? 'manual'),
        'hasKey' => $key !== '',
        'keyMasked' => $masked,
    ];
}

/**
 * @param array<string, mixed> $input
 * @return array<string, mixed>
 */
function crmMarketSaveSearchSettings(array $input): array
{
    $file = dirname(__DIR__) . DIRECTORY_SEPARATOR . 'client Market'
        . DIRECTORY_SEPARATOR . 'frontend' . DIRECTORY_SEPARATOR . 'data'
        . DIRECTORY_SEPARATOR . 'search-lab.json';
    $current = [];
    if (is_file($file)) {
        $decoded = json_decode((string) file_get_contents($file), true);
        if (is_array($decoded)) {
            $current = $decoded;
        }
    }
    $next = array_merge($current, [
        'host' => trim((string) ($input['host'] ?? ($current['host'] ?? 'local-business-search.p.rapidapi.com'))),
        'limit' => max(1, min(100, (int) ($input['limit'] ?? ($current['limit'] ?? 50)))),
        'lat' => isset($input['lat']) ? (float) $input['lat'] : (float) ($current['lat'] ?? -6.369),
        'lng' => isset($input['lng']) ? (float) $input['lng'] : (float) ($current['lng'] ?? 34.889),
        'language' => trim((string) ($input['language'] ?? ($current['language'] ?? 'en'))) ?: 'en',
        'region' => trim((string) ($input['region'] ?? ($current['region'] ?? 'tz'))) ?: 'tz',
        'mode' => strtolower((string) ($input['mode'] ?? ($current['mode'] ?? 'manual'))) === 'automatic' ? 'automatic' : 'manual',
    ]);
    $newKey = trim((string) ($input['key'] ?? $input['apiKey'] ?? ''));
    if ($newKey !== '') {
        $next['key'] = $newKey;
    } elseif (!isset($next['key'])) {
        $next['key'] = (string) ($current['key'] ?? '');
    }
    $dir = dirname($file);
    if (!is_dir($dir)) {
        @mkdir($dir, 0775, true);
    }
    @file_put_contents($file, json_encode($next, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
    return crmMarketGetSearchSettingsPublic();
}
