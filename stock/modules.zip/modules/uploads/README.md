# Stock uploads module � tenant isolation

Company users only see and delete files under **`storage/tenant_{company_id}/`**.  
Shared legacy `stock/uploads/products/` is **not** scanned or deleted unless a super admin opens debug mode.

---

## URLs

`/roadmaster/stock/modules/uploads/index.php?folder=products&images=1`  
? rewritten to `stock/modules/uploads/index.php?company_slug=roadmaster&...`

---

## Storage layout

| Scope | Path | Who sees it |
|--------|------|-------------|
| **Tenant (default)** | `public_html/storage/tenant_{id}/products/{product_id}/{variant}/{file}` | Logged-in company only |
| **Tenant categories** | `storage/tenant_{id}/categories/...` | Same |
| **Scoped legacy** | `stock/uploads/companies/{slug}/products/` or `stock/uploads/{slug}/products/` | Super admin + `?legacy=1` only |
| **Shared legacy (flat)** | `stock/uploads/products/{id}/...` | Super admin + `?legacy=1` or `folder=shared` only |

New uploads (`ajax_upload.php`) always use `UploadHelper` ? **tenant storage only**.

---

## Listing (`index.php`)

1. Resolve `company_id` via `stock_uploads_resolve_company_id()`.
2. `uploads_scan_roots_for_folder(..., $includeLegacy)`:
   - **Company user:** `$includeLegacy = false` ? scans **only** `storage/tenant_{id}/products` (or categories / full tenant for other folders).
   - **Super admin:** `$includeLegacy = true` when `?legacy=1` or `folder=shared`.
3. Each file card:
   - `data-source="tenant"` (or `legacy` in debug mode)
   - `data-rel="products/{id}/{variant}/{file}"` (normalized for tenant rows)
4. Never falls back to flat `stock/uploads/products/` for company-scoped pages.

---

## Delete (`ajax_delete.php`)

Payload:

```json
{ "paths": [{ "rel": "products/12/medium/foo.jpg", "source": "tenant" }], "folder": "products" }
```

1. Company users: **`source` must be `tenant`**; legacy deletes rejected.
2. `stock_uploads_resolve_delete_base_dir()` ? `storage/tenant_{company_id}` for tenant.
3. `stock_uploads_validate_delete_target()` ensures:
   - Session `company_id` matches target tenant
   - Resolved file is under that tenant tree
   - Not under shared flat `stock/uploads/products/` unless super-admin debug
4. `stock_uploads_delete_one_relative()` runs DB/recycle cleanup on the **tenant** PDO.

---

## Super-admin debug

- `?legacy=1` on the uploads index (super admin only): may list/delete scoped + shared legacy.
- `folder=shared`: shared legacy tree (super admin only).
- Normal Roadmaster/Ultimate users never get these flags.

---

## Helpers

| Function | File |
|----------|------|
| `stock_uploads_resolve_company_id()` | `auth_helper.php` |
| `stock_uploads_allow_shared_legacy()` | `auth_helper.php` |
| `stock_uploads_validate_delete_target()` | `auth_helper.php` |
| `stock_uploads_tenant_dir_for_company()` | `auth_helper.php` |
| `stock_uploads_legacy_products_dir()` | `stock/config/functions.php` � no flat fallback when slug set |
| `stock_uploads_resolve_delete_base_dir()` | `stock/config/functions.php` |

---

## Migrating old shared files

**Tool:** `stock/modules/uploads/migrate_tenant_uploads.php` or `admin/migrate-tenant-uploads.php` (super admin).

```bash
php stock/modules/uploads/migrate_tenant_uploads.php ultimate --dry-run
php stock/modules/uploads/migrate_tenant_uploads.php ultimate
```

Copies legacy `stock/uploads/products/{id}/` to `storage/tenant_{id}/products/{id}/` for all product IDs in that tenant DB. Legacy files are not deleted. Log: `storage/logs/migrate_tenant_*`.

**Ultimate (local, 2026-05-22):** 314 folders, 1308 files (~210 MB) ? `storage/tenant_1/products/`.

Run `php ... migrate_tenant_uploads.php roadmaster` for Roadmaster ? `tenant_2`.
