<?php
// stock/modules/uploads/ajax_delete.php
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../config/functions.php';
require_once __DIR__ . '/auth_helper.php';
require_once __DIR__ . '/uploads_delete_one.inc.php';
requireLogin();

header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);
$paths = $data['paths'] ?? [];
$folder = strtolower(trim((string) ($data['folder'] ?? 'products')));

if (empty($paths)) {
    echo json_encode(['success' => false, 'message' => 'No files selected.']);
    exit;
}

$companySlug = strtolower(trim((string) ($_SESSION['company_slug'] ?? '')));
$companyId = stock_uploads_resolve_company_id();

$deletedCount = 0;
$errors = [];

foreach ($paths as $item) {
    $relPath = '';
    $source = 'tenant';
    if (is_array($item)) {
        $relPath = (string) ($item['rel'] ?? $item['path'] ?? '');
        $source = strtolower(trim((string) ($item['source'] ?? 'tenant')));
    } else {
        $relPath = (string) $item;
    }
    $relPath = str_replace(['../', './'], '', $relPath);
    $relPath = ltrim($relPath, '/');

    if (!stock_uploads_allow_shared_legacy() && $source !== 'tenant') {
        $errors[] = 'Access denied: only tenant storage deletes are allowed — ' . $relPath;
        continue;
    }

    $baseDir = function_exists('stock_uploads_resolve_delete_base_dir')
        ? stock_uploads_resolve_delete_base_dir($source, $companyId, $companySlug, $folder)
        : stock_uploads_tenant_dir_for_company($companyId);
    if (!$baseDir) {
        $errors[] = 'Uploads directory not found — ' . $relPath;
        continue;
    }

    $deny = stock_uploads_validate_delete_target($baseDir, $relPath, $companyId, $companySlug, $source);
    if ($deny !== null) {
        $errors[] = $deny . ' — ' . $relPath;
        continue;
    }

    $res = stock_uploads_delete_one_relative($pdo, $baseDir, $relPath);
    if (!empty($res['ok'])) {
        $deletedCount++;
    } else {
        $errors[] = ($res['message'] ?? 'Delete failed') . ' — ' . $relPath;
    }
}

echo json_encode([
    'success' => $deletedCount > 0,
    'deletedCount' => $deletedCount,
    'errors' => $errors,
]);
