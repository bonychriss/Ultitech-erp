<?php
// stock/modules/uploads/ajax_delete_duplicates.php - delete extras: SHA-1 match or same-basename (verified) match
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../config/functions.php';
require_once __DIR__ . '/auth_helper.php';
require_once __DIR__ . '/uploads_delete_one.inc.php';
require_once __DIR__ . '/uploads_rel_usage_score.inc.php';
requireLogin();

header('Content-Type: application/json');

$raw = json_decode(file_get_contents('php://input'), true);
$groups = $raw['groups'] ?? null;
if (!is_array($groups) || !$groups) {
    echo json_encode(['ok' => false, 'message' => 'No groups payload.']);
    exit;
}

$companyId = stock_uploads_resolve_company_id();
$baseDir = stock_uploads_tenant_dir_for_company($companyId);
$prodDir = $baseDir ? ($baseDir . DIRECTORY_SEPARATOR . 'products') : null;
if (!$baseDir || !$prodDir || !is_dir($prodDir)) {
    echo json_encode(['ok' => false, 'message' => 'Tenant uploads path invalid.']);
    exit;
}
$prodDir = realpath($prodDir) ?: $prodDir;

$deleted = 0;
$errors = [];

foreach ($groups as $g) {
    $match = isset($g['match']) ? strtolower(trim((string) $g['match'])) : 'hash';
    $keep = isset($g['keep']) ? trim((string) $g['keep']) : '';
    $deleteList = $g['delete'] ?? [];
    if ($keep === '' || !is_array($deleteList) || !$deleteList) {
        $errors[] = 'Invalid group entry.';
        continue;
    }
    $keep = str_replace(['../', './'], '', $keep);
    $keep = ltrim($keep, '/');
    $keepFull = realpath($prodDir . '/' . $keep);
    if (!$keepFull || strpos($keepFull, $prodDir) !== 0 || !is_file($keepFull)) {
        $errors[] = 'Keep path invalid: ' . $keep;
        continue;
    }

    $baseKeep = strtolower(basename($keep));

    if ($match === 'name') {
        $keepUsage = stock_upload_rel_usage_score($pdo, $keep);
        $keepScore = (int) $keepUsage['score'];

        foreach ($deleteList as $del) {
            $del = str_replace(['../', './'], '', trim((string) $del));
            $del = ltrim($del, '/');
            if ($del === $keep) {
                $errors[] = 'Cannot delete keeper path.';
                continue;
            }
            if (strtolower(basename($del)) !== $baseKeep) {
                $errors[] = 'Filename mismatch (name-mode): ' . $del;
                continue;
            }
            $delUsage = stock_upload_rel_usage_score($pdo, $del);
            if ((int) $delUsage['score'] > $keepScore) {
                $errors[] = 'Refusing to delete a more-linked copy than the keeper: ' . $del . ' (increase keeper link or pick another keeper)';
                continue;
            }
            $delFull = realpath($prodDir . '/' . $del);
            if (!$delFull || strpos($delFull, $prodDir) !== 0 || !is_file($delFull)) {
                $errors[] = 'Missing file: ' . $del;
                continue;
            }
            $relKeep = 'products/' . $keep;
            $relDel = 'products/' . $del;
            $res = stock_uploads_delete_duplicate_candidate($pdo, $baseDir, $relKeep, $relDel);
            if (!empty($res['ok'])) {
                $deleted++;
            } else {
                $errors[] = ($res['message'] ?? 'Delete failed') . ' - ' . $del;
            }
        }
        continue;
    }

    $hash = isset($g['hash']) ? (string) $g['hash'] : '';
    if ($hash === '') {
        $errors[] = 'Invalid hash group entry.';
        continue;
    }
    $keepHash = sha1_file($keepFull);
    if ($keepHash !== $hash) {
        $errors[] = 'Hash mismatch for keeper: ' . $keep;
        continue;
    }

    $keepUsage = stock_upload_rel_usage_score($pdo, $keep);
    $keepScore = (int) $keepUsage['score'];

    foreach ($deleteList as $del) {
        $del = str_replace(['../', './'], '', trim((string) $del));
        $del = ltrim($del, '/');
        if ($del === $keep) {
            $errors[] = 'Cannot delete keeper path.';
            continue;
        }
        $delFull = realpath($prodDir . '/' . $del);
        if (!$delFull || strpos($delFull, $prodDir) !== 0 || !is_file($delFull)) {
            $errors[] = 'Missing duplicate file: ' . $del;
            continue;
        }
        if (sha1_file($delFull) !== $hash) {
            $errors[] = 'Hash mismatch, skip: ' . $del;
            continue;
        }
        $delUsage = stock_upload_rel_usage_score($pdo, $del);
        if ((int) $delUsage['score'] > $keepScore) {
            $errors[] = 'Refusing to delete a more-linked copy than the keeper: ' . $del;
            continue;
        }
        $relKeep = 'products/' . $keep;
        $relDel = 'products/' . $del;
        $res = stock_uploads_delete_duplicate_candidate($pdo, $baseDir, $relKeep, $relDel);
        if (!empty($res['ok'])) {
            $deleted++;
        } else {
            $errors[] = ($res['message'] ?? 'Delete failed') . ' - ' . $del;
        }
    }
}

echo json_encode([
    'ok' => $deleted > 0 || empty($errors),
    'deleted' => $deleted,
    'errors' => $errors,
], JSON_UNESCAPED_UNICODE);
