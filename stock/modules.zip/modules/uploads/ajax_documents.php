<?php
// stock/modules/uploads/ajax_documents.php � async document list for Documents tab
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../config/functions.php';
requireLogin();
require_once __DIR__ . '/auth_helper.php';
require_once __DIR__ . '/uploads_documents_collect.inc.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

if (!function_exists('human_size')) {
    function human_size($bytes)
    {
        $bytes = (float) $bytes;
        $units = ['B', 'KB', 'MB', 'GB', 'TB'];
        $i = 0;
        while ($bytes >= 1024 && $i < count($units) - 1) {
            $bytes /= 1024;
            $i++;
        }
        return ($i === 0 ? number_format($bytes, 0) : number_format($bytes, 1)) . ' ' . $units[$i];
    }
}
if (!function_exists('is_image_ext')) {
    function is_image_ext($name)
    {
        $ext = strtolower(pathinfo((string) $name, PATHINFO_EXTENSION));
        return in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp', 'svg'], true);
    }
}

$companyId = stock_uploads_resolve_company_id();
$max = (int) ($_GET['limit'] ?? 2500);
$max = max(50, min(5000, $max));

$files = [];
try {
    $files = uploads_collect_system_documents($pdo, $companyId, $max);
} catch (Throwable $e) {
    echo json_encode(['ok' => false, 'error' => 'Could not load documents.', 'files' => []]);
    exit;
}

usort($files, static function ($a, $b) {
    return ((int) ($b['mtime'] ?? 0)) <=> ((int) ($a['mtime'] ?? 0));
});

echo json_encode([
    'ok' => true,
    'count' => count($files),
    'files' => uploads_documents_to_payload($files),
], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
exit;
