<?php
// stock/modules/uploads/ajax_duplicate_scan.php - SHA-1 duplicates + same-filename groups (uploads/products)
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../config/functions.php';
require_once __DIR__ . '/uploads_rel_usage_score.inc.php';
requireLogin();
require_once __DIR__ . '/auth_helper.php';

$companyId = stock_uploads_resolve_company_id();

header('Content-Type: application/json');

@set_time_limit(120);

$imgExt = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp', 'svg'];
$isImage = static function (string $name) use ($imgExt): bool {
    $e = strtolower(pathinfo($name, PATHINFO_EXTENSION));
    return in_array($e, $imgExt, true);
};

$tenantBase = stock_uploads_tenant_dir_for_company($companyId);
$root = $tenantBase ? ($tenantBase . DIRECTORY_SEPARATOR . 'products') : null;
$root = ($root && is_dir($root)) ? (realpath($root) ?: $root) : null;
if (!$root) {
    echo json_encode(['ok' => false, 'message' => 'Tenant products folder not found.']);
    exit;
}

$maxFiles = 2800;
$filesMeta = [];

$it = new RecursiveIteratorIterator(
    new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS),
    RecursiveIteratorIterator::SELF_FIRST
);

foreach ($it as $f) {
    /** @var SplFileInfo $f */
    if (!$f->isFile()) {
        continue;
    }
    $name = $f->getFilename();
    if ($name === '.htaccess' || $name === 'php.ini') {
        continue;
    }
    if (!$isImage($name)) {
        continue;
    }
    $rel = str_replace('\\', '/', substr($f->getPathname(), strlen($root)));
    $rel = ltrim($rel, '/');
    if (!stock_uploads_is_path_allowed($rel, 'tenant', 'products', $pdo, $companyId)) {
        continue;
    }
    $size = (int) $f->getSize();
    $mtime = (int) $f->getMTime();
    $filesMeta[] = ['rel' => $rel, 'size' => $size, 'mtime' => $mtime, 'path' => $f->getPathname()];
    if (count($filesMeta) >= $maxFiles) {
        break;
    }
}

$bySize = [];
foreach ($filesMeta as $row) {
    $bySize[$row['size']][] = $row;
}

$duplicateGroups = [];
$totalDupBytes = 0;

foreach ($bySize as $size => $group) {
    if ($size < 1 || count($group) < 2) {
        continue;
    }
    $byHash = [];
    foreach ($group as $row) {
        $h = @sha1_file($row['path']);
        if ($h === false) {
            continue;
        }
        $byHash[$h][] = $row;
    }
    foreach ($byHash as $hash => $same) {
        if (count($same) < 2) {
            continue;
        }
        usort($same, static function ($a, $b) {
            return ($b['mtime'] <=> $a['mtime']);
        });
        $waste = 0;
        foreach (array_slice($same, 1) as $x) {
            $waste += (int) $x['size'];
        }
        $totalDupBytes += $waste;
        $outFiles = [];
        foreach ($same as $x) {
            $outFiles[] = ['rel' => $x['rel'], 'size' => $x['size'], 'mtime' => $x['mtime']];
        }
        $duplicateGroups[] = [
            'hash' => $hash,
            'size' => $size,
            'count' => count($same),
            'files' => $outFiles,
        ];
    }
}

// Same basename (case-insensitive), different paths - may differ from SHA-1 groups (different pixels, same name)
$byBasename = [];
foreach ($filesMeta as $row) {
    $key = strtolower(basename($row['rel']));
    $byBasename[$key][] = $row;
}
$nameGroupsRaw = [];
foreach ($byBasename as $key => $list) {
    if (count($list) < 2) {
        continue;
    }
    usort($list, static function ($a, $b) {
        return ($b['mtime'] <=> $a['mtime']);
    });
    $outFiles = [];
    foreach ($list as $x) {
        $outFiles[] = ['rel' => $x['rel'], 'size' => $x['size'], 'mtime' => $x['mtime']];
    }
    $nameGroupsRaw[] = [
        'basename' => basename($list[0]['rel']),
        'basename_key' => $key,
        'count' => count($list),
        'files' => $outFiles,
    ];
}

$sortedRels = static function (array $files): array {
    $r = array_column($files, 'rel');
    sort($r, SORT_STRING);
    return $r;
};
$hashRelSets = [];
foreach ($duplicateGroups as $hg) {
    $hashRelSets[] = $sortedRels($hg['files']);
}
$nameGroups = [];
foreach ($nameGroupsRaw as $ng) {
    $nr = $sortedRels($ng['files']);
    $sameAsHashGroup = false;
    foreach ($hashRelSets as $hr) {
        if ($nr === $hr) {
            $sameAsHashGroup = true;
            break;
        }
    }
    if (!$sameAsHashGroup) {
        $nameGroups[] = $ng;
    }
}

$usageCache = [];
$enrichDuplicateFiles = static function (array $files) use ($pdo, &$usageCache): array {
    $out = [];
    foreach ($files as $f) {
        $rel = $f['rel'];
        if (!isset($usageCache[$rel])) {
            $usageCache[$rel] = stock_upload_rel_usage_score($pdo, $rel);
        }
        $u = $usageCache[$rel];
        $f['usage_score'] = $u['score'];
        $f['usage_hints'] = $u['hints'];
        $out[] = $f;
    }
    return $out;
};

foreach ($duplicateGroups as $i => $g) {
    $duplicateGroups[$i]['files'] = $enrichDuplicateFiles($g['files']);
}
foreach ($nameGroups as $i => $g) {
    $nameGroups[$i]['files'] = $enrichDuplicateFiles($g['files']);
}

echo json_encode([
    'ok' => true,
    'scanned' => count($filesMeta),
    'groups' => $duplicateGroups,
    'group_count' => count($duplicateGroups),
    'name_groups' => $nameGroups,
    'name_group_count' => count($nameGroups),
    'wasted_bytes' => $totalDupBytes,
    'capped' => count($filesMeta) >= $maxFiles,
], JSON_UNESCAPED_UNICODE);
