<?php
// stock/modules/uploads/ajax_files.php — tenant-scoped file list for pickers
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../config/functions.php';
require_once __DIR__ . '/auth_helper.php';
requireLogin();

$folder = strtolower(trim((string) ($_GET['folder'] ?? 'uploads')));
$companyId = stock_uploads_resolve_company_id();
$tenantBase = stock_uploads_tenant_dir_for_company($companyId);

$targetDir = $tenantBase;
if ($folder === 'products' && $tenantBase) {
    $targetDir = $tenantBase . DIRECTORY_SEPARATOR . 'products';
} elseif ($folder === 'categories' && $tenantBase) {
    $targetDir = $tenantBase . DIRECTORY_SEPARATOR . 'categories';
}

$files = [];
if ($targetDir && is_dir($targetDir)) {
    $it = new DirectoryIterator($targetDir);
    foreach ($it as $f) {
        if ($f->isDot() || !$f->isFile()) {
            continue;
        }
        $name = $f->getFilename();
        if (in_array(strtolower(pathinfo($name, PATHINFO_EXTENSION)), ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg'], true)) {
            $files[] = $name;
        }
    }
}

header('Content-Type: application/json');
echo json_encode($files);
