<?php
// stock/modules/uploads/ajax_image_usage.php � where a product upload image is referenced + delete impact
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../config/functions.php';
requireLogin();
require_once __DIR__ . '/auth_helper.php';

header('Content-Type: application/json');

$raw = json_decode(file_get_contents('php://input'), true);
$rel = isset($raw['rel']) ? trim((string) $raw['rel']) : '';
$rel = str_replace(['../', './'], '', $rel);
$rel = ltrim($rel, '/');

if ($rel === '') {
    echo json_encode(['ok' => false, 'message' => 'Missing rel path.']);
    exit;
}

$companyId = stock_uploads_resolve_company_id();
$tenantBase = stock_uploads_tenant_dir_for_company($companyId);
if (!$tenantBase) {
    echo json_encode(['ok' => false, 'message' => 'Tenant storage not found.']);
    exit;
}

if (!stock_uploads_is_path_allowed($rel, 'tenant', 'products', $pdo, $companyId)) {
    echo json_encode(['ok' => false, 'message' => 'Access denied: Unauthorized file path.']);
    exit;
}

$deny = stock_uploads_validate_delete_target($tenantBase, $rel, $companyId, '', 'tenant');
if ($deny !== null) {
    echo json_encode(['ok' => false, 'message' => $deny]);
    exit;
}

$full = realpath($tenantBase . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $rel));
if (!$full || !stock_uploads_path_is_under($full, $tenantBase) || !is_file($full)) {
    echo json_encode(['ok' => false, 'message' => 'File not found under tenant product uploads.']);
    exit;
}

$basename = basename($rel);
$productIdFromPath = null;
$inner = $rel;
if (strpos($inner, 'products/') === 0) {
    $inner = substr($inner, strlen('products/'));
}
$firstSeg = explode('/', $inner, 2)[0] ?? '';
if ($firstSeg !== '' && ctype_digit($firstSeg)) {
    $productIdFromPath = (int) $firstSeg;
}

$refs = [
    'product_images' => [],
    'main_image_products' => [],
    'legacy_image_products' => [],
];
$hasProductImages = false;
$hasMainImage = false;
$hasLegacyImage = false;

try {
    $pdo->query('SELECT 1 FROM product_images LIMIT 1');
    $hasProductImages = true;
} catch (Throwable $e) {
}

try {
    $pdo->query('SELECT main_image FROM products LIMIT 1');
    $hasMainImage = true;
} catch (Throwable $e) {
}

try {
    $pdo->query('SELECT image FROM products LIMIT 1');
    $hasLegacyImage = true;
} catch (Throwable $e) {
}

if ($hasProductImages) {
    try {
        if ($productIdFromPath) {
            $stmt = $pdo->prepare(
                'SELECT pi.product_id, pi.image_name, pi.is_primary, p.name AS product_name, p.product_code
                 FROM product_images pi
                 INNER JOIN products p ON p.id = pi.product_id
                 WHERE pi.product_id = ? AND pi.image_name = ?'
            );
            $stmt->execute([$productIdFromPath, $basename]);
        } else {
            $stmt = $pdo->prepare(
                'SELECT pi.product_id, pi.image_name, pi.is_primary, p.name AS product_name, p.product_code
                 FROM product_images pi
                 INNER JOIN products p ON p.id = pi.product_id
                 WHERE pi.image_name = ?'
            );
            $stmt->execute([$basename]);
        }
        $refs['product_images'] = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
    } catch (Throwable $e) {
        $refs['product_images'] = [];
    }
}

if ($hasMainImage) {
    try {
        $stmt = $pdo->prepare(
            'SELECT id, name, product_code FROM products WHERE NULLIF(TRIM(main_image), \'\') IS NOT NULL AND (main_image = ? OR main_image LIKE ?)'
        );
        $stmt->execute([$basename, '%/' . $basename]);
        $refs['main_image_products'] = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
    } catch (Throwable $e) {
        $refs['main_image_products'] = [];
    }
}

if ($hasLegacyImage) {
    try {
        $stmt = $pdo->prepare(
            'SELECT id, name, product_code FROM products WHERE NULLIF(TRIM(image), \'\') IS NOT NULL AND (image = ? OR image LIKE ?)'
        );
        $stmt->execute([$basename, '%/' . $basename]);
        $refs['legacy_image_products'] = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
    } catch (Throwable $e) {
        $refs['legacy_image_products'] = [];
    }
}

$primaryRisk = false;
foreach ($refs['product_images'] as $row) {
    if (!empty($row['is_primary'])) {
        $primaryRisk = true;
        break;
    }
}

$mainRisk = count($refs['main_image_products']) > 0;
$legacyRisk = count($refs['legacy_image_products']) > 0;

$anyUse = count($refs['product_images']) > 0 || $mainRisk || $legacyRisk;

$impact = 'none';
if ($primaryRisk || $mainRisk) {
    $impact = 'high';
} elseif ($anyUse) {
    $impact = 'medium';
}

$lines = [];
if (!$anyUse) {
    $lines[] = 'Not referenced in product_images, products.main_image, or products.image for this filename.';
} else {
    if ($primaryRisk) {
        $lines[] = 'Used as a primary gallery image for at least one product � removing the file will remove that DB row.';
    }
    if ($mainRisk) {
        $lines[] = 'Referenced as main_image on one or more products � delete will clear main_image (and may pick another gallery image if available).';
    }
    if ($legacyRisk) {
        $lines[] = 'Referenced on legacy products.image column � clearing or broken image links may result.';
    }
    if (!$primaryRisk && !$mainRisk && count($refs['product_images']) > 0) {
        $lines[] = 'Referenced in product gallery (non-primary only) � delete removes those gallery rows.';
    }
}

echo json_encode([
    'ok' => true,
    'rel' => $rel,
    'basename' => $basename,
    'refs' => $refs,
    'impact' => $impact,
    'any_use' => $anyUse,
    'summary_lines' => $lines,
], JSON_UNESCAPED_UNICODE);
