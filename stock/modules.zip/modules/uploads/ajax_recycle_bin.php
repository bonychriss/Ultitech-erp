<?php
// stock/modules/uploads/ajax_recycle_bin.php
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../config/functions.php';
require_once __DIR__ . '/uploads_recycle_bin.inc.php';
requireLogin();

header('Content-Type: application/json');

$baseDir = realpath(__DIR__ . '/../../uploads');
if (!$baseDir) {
    echo json_encode(['ok' => false, 'message' => 'Uploads directory not found.']);
    exit;
}

$raw = json_decode(file_get_contents('php://input'), true);
if (!is_array($raw)) {
    $raw = [];
}
$action = isset($raw['action']) ? strtolower(trim((string) $raw['action'])) : '';

stock_uploads_recycle_ensure_schema($pdo);

if ($action === 'restore') {
    $id = isset($raw['id']) ? (int) $raw['id'] : 0;
    if ($id < 1) {
        echo json_encode(['ok' => false, 'message' => 'Invalid id.']);
        exit;
    }
    $res = stock_uploads_recycle_restore($pdo, $baseDir, $id);
    echo json_encode($res, JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'purge') {
    $id = isset($raw['id']) ? (int) $raw['id'] : 0;
    if ($id < 1) {
        echo json_encode(['ok' => false, 'message' => 'Invalid id.']);
        exit;
    }
    $res = stock_uploads_recycle_purge($pdo, $baseDir, $id);
    echo json_encode($res, JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'restore_all') {
    $st = $pdo->query('SELECT id FROM upload_recycle_bin ORDER BY id ASC');
    $ids = $st ? $st->fetchAll(PDO::FETCH_COLUMN) : [];
    $n = 0;
    $errors = [];
    foreach ($ids as $bid) {
        $bid = (int) $bid;
        $r = stock_uploads_recycle_restore($pdo, $baseDir, $bid);
        if (!empty($r['ok'])) {
            $n++;
        } else {
            $errors[] = 'id ' . $bid . ': ' . ($r['message'] ?? 'failed');
        }
    }
    echo json_encode([
        'ok' => $n > 0 || (count($ids) === 0 && empty($errors)),
        'restored' => $n,
        'total' => count($ids),
        'errors' => $errors,
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'purge_all') {
    $st = $pdo->query('SELECT id FROM upload_recycle_bin ORDER BY id ASC');
    $ids = $st ? $st->fetchAll(PDO::FETCH_COLUMN) : [];
    $n = 0;
    $errors = [];
    foreach ($ids as $bid) {
        $bid = (int) $bid;
        $r = stock_uploads_recycle_purge($pdo, $baseDir, $bid);
        if (!empty($r['ok'])) {
            $n++;
        } else {
            $errors[] = 'id ' . $bid . ': ' . ($r['message'] ?? 'failed');
        }
    }
    echo json_encode(['ok' => $n > 0 || empty($errors), 'purged' => $n, 'errors' => $errors], JSON_UNESCAPED_UNICODE);
    exit;
}

echo json_encode(['ok' => false, 'message' => 'Unknown action.']);
