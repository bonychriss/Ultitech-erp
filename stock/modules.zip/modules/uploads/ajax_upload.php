<?php
// stock/modules/uploads/ajax_upload.php
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../config/functions.php';
requireLogin();

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method.']);
    exit;
}

$folder = strtolower(preg_replace('/[^a-z0-9_]/', '', (string)($_POST['folder'] ?? 'products')));
if ($folder === '') {
    $folder = 'products';
}

require_once __DIR__ . '/auth_helper.php';

$companyId = stock_uploads_resolve_company_id();
if ($companyId <= 0) {
    echo json_encode(['success' => false, 'message' => 'Company context required for uploads.']);
    exit;
}

// Map folder type to centralized submodule
$submodule = $folder;
if ($submodule === 'uploads') {
    $submodule = 'general';
}

$uploadedFiles = [];
$errors = [];

if (isset($_FILES['files'])) {
    $files = $_FILES['files'];
    
    // Support both single file array and multiple files arrays
    $fileCount = is_array($files['name']) ? count($files['name']) : 1;
    
    for ($i = 0; $i < $fileCount; $i++) {
        $errorVal = is_array($files['error']) ? $files['error'][$i] : $files['error'];
        if ($errorVal === 0) {
            $fileArray = [
                'name'     => is_array($files['name']) ? $files['name'][$i] : $files['name'],
                'tmp_name' => is_array($files['tmp_name']) ? $files['tmp_name'][$i] : $files['tmp_name'],
                'type'     => is_array($files['type']) ? $files['type'][$i] : $files['type'],
                'size'     => is_array($files['size']) ? $files['size'][$i] : $files['size'],
                'error'    => $errorVal
            ];

            // Define specific prefixes
            $prefix = 'prod';
            $allowedGroups = ['images'];
            if ($submodule === 'categories') {
                $prefix = 'cat';
            } elseif ($submodule === 'general') {
                $prefix = 'upload';
            } elseif ($submodule === 'documents') {
                $prefix = 'doc';
                $allowedGroups = ['images', 'documents', 'spreadsheets'];
            }

            // Perform secure upload via multi-tenant UploadHelper
            $res = UploadHelper::upload($fileArray, $companyId, $submodule, [
                'prefix'         => $prefix,
                'allowed_groups' => $allowedGroups,
                'optimize_image' => $submodule !== 'documents',
            ]);

            if ($res['ok']) {
                // Return basename of the newly saved, secured path to AJAX consumer
                $uploadedFiles[] = basename($res['stored_path']);
            } else {
                $errors[] = "File '" . $fileArray['name'] . "' failed: " . $res['error'];
            }
        } else {
            $errors[] = "PHP upload error code: " . $errorVal;
        }
    }
}

echo json_encode([
    'success' => count($uploadedFiles) > 0,
    'uploaded' => $uploadedFiles,
    'errors' => $errors
]);
exit;
