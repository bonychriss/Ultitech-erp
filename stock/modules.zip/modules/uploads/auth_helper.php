<?php
// stock/modules/uploads/auth_helper.php

if (!function_exists('stock_uploads_resolve_company_id')) {
    function stock_uploads_resolve_company_id()
    {
        $companyId = (int) ($_SESSION['company_id'] ?? 0);
        if ($companyId <= 0 && function_exists('currentCompanyId')) {
            $companyId = (int) currentCompanyId();
        }
        if ($companyId <= 0) {
            $slug = strtolower(trim((string) ($_SESSION['company_slug'] ?? '')));
            if ($slug === 'ultimate') {
                $companyId = 1;
            } elseif ($slug === 'roadmaster') {
                $companyId = 2;
            }
        }

        return $companyId;
    }
}

if (!function_exists('stock_uploads_allow_shared_legacy')) {
    /**
     * Super-admin debug: shared stock/uploads tree (flat products/, etc.).
     */
    function stock_uploads_allow_shared_legacy()
    {
        if (!function_exists('isSuperAdmin') || !isSuperAdmin()) {
            return false;
        }
        if (isset($_GET['legacy']) && (string) $_GET['legacy'] === '1') {
            return true;
        }
        $folder = strtolower(trim((string) ($_GET['folder'] ?? '')));

        return ($folder === 'shared');
    }
}

if (!function_exists('stock_uploads_allow_scoped_legacy')) {
    /** Company-scoped legacy under stock/uploads/companies/{slug}/ or stock/uploads/{slug}/ */
    function stock_uploads_allow_scoped_legacy()
    {
        return stock_uploads_allow_shared_legacy();
    }
}

if (!function_exists('stock_uploads_tenant_dir_for_company')) {
    function stock_uploads_tenant_dir_for_company($companyId = 0)
    {
        $companyId = (int) ($companyId > 0 ? $companyId : stock_uploads_resolve_company_id());
        if ($companyId <= 0) {
            return null;
        }
        $path = dirname(__DIR__, 3) . DIRECTORY_SEPARATOR . 'storage' . DIRECTORY_SEPARATOR . 'tenant_' . $companyId;
        if (!is_dir($path)) {
            @mkdir($path, 0755, true);
        }

        return (is_dir($path) ? (realpath($path) ?: $path) : null);
    }
}

if (!function_exists('stock_uploads_path_is_under')) {
    function stock_uploads_path_is_under($childPath, $parentPath)
    {
        $child = str_replace('\\', '/', strtolower(realpath($childPath) ?: $childPath));
        $parent = str_replace('\\', '/', strtolower(realpath($parentPath) ?: $parentPath));
        if ($child === '' || $parent === '') {
            return false;
        }
        $child = rtrim($child, '/');
        $parent = rtrim($parent, '/');
        if ($child === $parent) {
            return true;
        }

        return (strpos($child, $parent . '/') === 0);
    }
}

if (!function_exists('stock_uploads_is_shared_flat_products_path')) {
    function stock_uploads_is_shared_flat_products_path($absolutePath)
    {
        if (!function_exists('stock_uploads_shared_legacy_products_dir')) {
            return false;
        }
        $shared = stock_uploads_shared_legacy_products_dir();
        if (!$shared) {
            return false;
        }

        return stock_uploads_path_is_under($absolutePath, $shared);
    }
}

if (!function_exists('stock_uploads_normalize_card_rel')) {
    /**
     * Card/delete rel path (always products/… or categories/… for tenant rows).
     */
    function stock_uploads_normalize_card_rel($rel, $sourceLabel, $folder)
    {
        $rel = ltrim(str_replace('\\', '/', (string) $rel), '/');
        $folder = strtolower(trim((string) $folder));
        $sourceLabel = strtolower(trim((string) $sourceLabel));

        if ($sourceLabel === 'tenant') {
            if ($folder === 'products' && strpos($rel, 'products/') !== 0) {
                $rel = 'products/' . $rel;
            } elseif ($folder === 'categories' && strpos($rel, 'categories/') !== 0) {
                $rel = 'categories/' . $rel;
            } elseif ($folder === 'documents' && strpos($rel, 'documents/') !== 0) {
                $rel = 'documents/' . $rel;
            }
        }

        return $rel;
    }
}

if (!function_exists('stock_uploads_public_href')) {
    /** Build browser URL from base_url + card rel (avoids double products/ segment). */
    function stock_uploads_public_href($baseUrl, $rel)
    {
        $baseUrl = rtrim((string) $baseUrl, '/');
        $rel = ltrim(str_replace('\\', '/', (string) $rel), '/');
        if (substr($baseUrl, -9) === '/products' && strpos($rel, 'products/') === 0) {
            $rel = substr($rel, strlen('products/'));
        } elseif (substr($baseUrl, -11) === '/categories' && strpos($rel, 'categories/') === 0) {
            $rel = substr($rel, strlen('categories/'));
        } elseif (substr($baseUrl, -10) === '/documents' && strpos($rel, 'documents/') === 0) {
            $rel = substr($rel, strlen('documents/'));
        }

        return $baseUrl . '/' . $rel;
    }
}

if (!function_exists('stock_uploads_validate_delete_target')) {
    /**
     * @return string|null Error message, or null if allowed
     */
    function stock_uploads_validate_delete_target($baseDir, $relPath, $companyId, $companySlug, $source)
    {
        $companyId = (int) ($companyId > 0 ? $companyId : stock_uploads_resolve_company_id());
        $sessionCompanyId = stock_uploads_resolve_company_id();
        if ($companyId <= 0 || $sessionCompanyId <= 0 || $companyId !== $sessionCompanyId) {
            return 'Access denied: invalid company context.';
        }

        $source = strtolower(trim((string) $source));
        $allowShared = stock_uploads_allow_shared_legacy();
        $tenantBase = stock_uploads_tenant_dir_for_company($companyId);

        if ($source !== 'tenant' && !$allowShared) {
            return 'Access denied: legacy deletes are disabled for company users.';
        }

        if ($source === 'tenant') {
            if (!$tenantBase) {
                return 'Tenant storage not available.';
            }
            if (!stock_uploads_path_is_under($baseDir, $tenantBase)) {
                return 'Access denied: delete target is outside your tenant storage.';
            }
        } else {
            if (function_exists('stock_uploads_shared_legacy_products_dir')) {
                $shared = stock_uploads_shared_legacy_products_dir();
                if ($shared && stock_uploads_path_is_under($baseDir, $shared)) {
                    if (!$allowShared) {
                        return 'Access denied: cannot delete from shared legacy products folder.';
                    }
                }
            }
            $scoped = function_exists('stock_uploads_legacy_products_dir')
                ? stock_uploads_legacy_products_dir($companySlug)
                : null;
            $legacyRoot = realpath(dirname(__DIR__, 2) . '/uploads');
            $allowedLegacy = array_filter(array($scoped, $legacyRoot));
            $ok = false;
            foreach ($allowedLegacy as $allowed) {
                if ($allowed && stock_uploads_path_is_under($baseDir, $allowed)) {
                    $ok = true;
                    break;
                }
            }
            if (!$ok) {
                return 'Access denied: legacy path is not in an allowed company-scoped folder.';
            }
            if ($scoped && stock_uploads_path_is_under($baseDir, $scoped)) {
                // scoped OK
            } elseif (!$allowShared) {
                return 'Access denied: only company-scoped legacy folders may be used.';
            }
        }

        $relPath = ltrim(str_replace(['../', './'], '', (string) $relPath), '/');
        $fullPath = realpath(rtrim($baseDir, '/\\') . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $relPath));
        if (!$fullPath || !is_file($fullPath)) {
            return 'File not found.';
        }

        if ($source === 'tenant' && $tenantBase && !stock_uploads_path_is_under($fullPath, $tenantBase)) {
            return 'Access denied: file is outside your tenant storage.';
        }

        if (!$allowShared && stock_uploads_is_shared_flat_products_path($fullPath)) {
            return 'Access denied: cannot delete files from shared legacy products folder.';
        }

        return null;
    }
}

if (!function_exists('stock_uploads_is_path_allowed')) {
    /**
     * Check if a relative file path belongs to the active company (not the other tenant).
     *
     * @param string $rel Path relative to the scan root
     * @param string $sourceLabel "legacy" or "tenant"
     * @param string $folder The folder parameter (e.g. "products", "uploads")
     * @param PDO|null $pdo Active company PDO
     * @param int $companyId Active company ID
     * @return bool
     */
    function stock_uploads_is_path_allowed($rel, $sourceLabel, $folder, $pdo, $companyId)
    {
        $companyId = (int) $companyId;
        $sessionCompanyId = stock_uploads_resolve_company_id();
        if ($sessionCompanyId <= 0 || $companyId !== $sessionCompanyId) {
            return false;
        }

        if ($sourceLabel === 'tenant') {
            return true;
        }

        if (!stock_uploads_allow_scoped_legacy()) {
            return false;
        }

        if (!($pdo instanceof PDO)) {
            if (function_exists('stock_company_pdo')) {
                $pdo = stock_company_pdo();
            }
        }

        $validProductIds = function_exists('stock_uploads_company_product_ids')
            ? stock_uploads_company_product_ids($pdo)
            : array();

        static $otherCompanySlugsByTenant = array();

        if (!isset($otherCompanySlugsByTenant[$companyId])) {
            $otherCompanySlugsByTenant[$companyId] = array();
            try {
                $metaPdo = (isset($GLOBALS['control_pdo']) && $GLOBALS['control_pdo'] instanceof PDO)
                    ? $GLOBALS['control_pdo']
                    : $pdo;
                if ($metaPdo instanceof PDO) {
                    $st = $metaPdo->prepare('SELECT company_slug FROM companies WHERE id != ?');
                    $st->execute(array($companyId));
                    foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $slug) {
                        $s = strtolower(trim((string) $slug));
                        if ($s !== '') {
                            $otherCompanySlugsByTenant[$companyId][] = $s;
                        }
                    }
                }
            } catch (Throwable $e) {
            }
        }

        $rel = str_replace('\\', '/', (string) $rel);
        $parts = explode('/', $rel);

        foreach ($parts as $part) {
            $p = strtolower(trim($part));
            if ($p !== '' && in_array($p, $otherCompanySlugsByTenant[$companyId], true)) {
                return false;
            }
        }

        $productId = null;
        if (count($parts) > 2 && $parts[0] === 'companies' && is_numeric($parts[2])) {
            $productId = (int) $parts[2];
        } elseif (count($parts) > 1 && $parts[0] === 'products' && is_numeric($parts[1])) {
            $productId = (int) $parts[1];
        } elseif (count($parts) > 0 && is_numeric($parts[0]) && in_array($folder, array('products', 'shared', 'uploads'), true)) {
            $productId = (int) $parts[0];
        }

        if ($productId !== null && $productId > 0) {
            if (empty($validProductIds) || !isset($validProductIds[$productId])) {
                return false;
            }
        }

        return true;
    }
}
