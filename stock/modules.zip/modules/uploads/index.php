<?php
// stock/modules/uploads/index.php — React uploads desk
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../config/functions.php';
requireLogin();
require_once __DIR__ . '/../../config/paths.php';
require_once __DIR__ . '/auth_helper.php';
require_once __DIR__ . '/uploads_documents_collect.inc.php';

$active_module = 'stocks';
$page_title = 'Uploaded Files';

$folder = strtolower(trim((string) ($_GET['folder'] ?? 'uploads')));
if (!in_array($folder, ['uploads', 'products', 'categories', 'shared', 'documents'], true)) {
    $folder = 'uploads';
}
$mode = strtolower(trim((string) ($_GET['mode'] ?? 'view')));
$mode = ($mode === 'select') ? 'select' : 'view';
// Browse UI is All files + Documents only; map legacy product/category tabs to all files.
if ($mode !== 'select' && in_array($folder, ['products', 'categories', 'shared'], true)) {
    $folder = 'uploads';
}
$imagesOnly = isset($_GET['images']) && (string) $_GET['images'] === '1';
// Images-only filter removed from browse UI.
if ($mode !== 'select') {
    $imagesOnly = false;
}
$companySlug = strtolower(trim((string) ($_SESSION['company_slug'] ?? '')));
if ($companySlug === '' && !empty($_GET['company_slug'])) {
    $companySlug = strtolower(trim((string) $_GET['company_slug']));
}
$companyId = stock_uploads_resolve_company_id();
$allowSharedLegacy = stock_uploads_allow_shared_legacy();
$includeLegacy = $allowSharedLegacy;

$legacyBaseDir = $allowSharedLegacy ? realpath(__DIR__ . '/../../uploads') : null;
$legacyProductsDir = ($includeLegacy && function_exists('stock_uploads_legacy_products_dir'))
    ? stock_uploads_legacy_products_dir($companySlug)
    : null;

$companyDir = stock_uploads_tenant_dir_for_company($companyId);
if (!$companyDir) {
    $tenantBasePath = __DIR__ . '/../../../storage/tenant_' . $companyId;
    @mkdir($tenantBasePath . DIRECTORY_SEPARATOR . 'products', 0755, true);
    $companyDir = stock_uploads_tenant_dir_for_company($companyId) ?: $tenantBasePath;
}
@mkdir($companyDir . DIRECTORY_SEPARATOR . 'products', 0755, true);
@mkdir($companyDir . DIRECTORY_SEPARATOR . 'categories', 0755, true);
@mkdir($companyDir . DIRECTORY_SEPARATOR . 'documents', 0755, true);

if ($folder === 'shared' && !$allowSharedLegacy) {
    $folder = 'uploads';
}

$sb = isset($stockBasePath) ? str_replace('\\', '/', (string) $stockBasePath) : '/stock/';
$sb = rtrim($sb, '/');
if ($sb !== '' && $sb[0] === '/') {
    $uploadsUrl = $sb . '/uploads';
} else {
    $uploadsUrl = '../../uploads';
}
$uploadsUrl = rtrim($uploadsUrl, '/');

if (!function_exists('human_size')) {
    function human_size($bytes)
    {
        $bytes = (float) $bytes;
        $units = ['B', 'KB', 'MB', 'GB', 'TB'];
        $i = 0;
        while ($bytes >= 1024 && $i < count($units) - 1) {
            $bytes /= 1024;
            $i++;
        }
        return ($i === 0 ? number_format($bytes, 0) : number_format($bytes, 1)) . ' ' . $units[$i];
    }
}
if (!function_exists('get_dir_size')) {
    function get_dir_size($dir)
    {
        $size = 0;
        if (!is_dir($dir)) {
            return 0;
        }
        foreach (new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS)) as $file) {
            $size += $file->getSize();
        }
        return $size;
    }
}
if (!function_exists('is_image_ext')) {
    function is_image_ext($name)
    {
        $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
        return in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp', 'svg'], true);
    }
}
if (!function_exists('uploads_scan_roots_for_folder')) {
    /**
     * @return list<array{dir:string,base_url:string,label:string}>
     */
    function uploads_scan_roots_for_folder($folder, $companyId, $companyDir, $legacyBaseDir, $legacyProductsDir, $uploadsUrl, $companySlug = '', $includeLegacy = false)
    {
        $roots = [];
        $tenantStorageUrl = '/storage/tenant_' . (int) $companyId;
        if (function_exists('app_url')) {
            $tenantStorageUrl = rtrim((string) app_url($tenantStorageUrl), '/');
        }
        $legacyBaseUrl = rtrim((string) $uploadsUrl, '/');
        $slug = strtolower(trim((string) $companySlug));
        $scopedLegacyUrl = ($slug !== '') ? $legacyBaseUrl . '/companies/' . rawurlencode($slug) . '/products' : '';
        $legacyProductsUrl = $legacyBaseUrl . '/products';
        if ($scopedLegacyUrl !== '' && $legacyProductsDir && is_dir($legacyProductsDir)) {
            $scopedDir = realpath(__DIR__ . '/../../uploads/companies/' . $slug . '/products');
            if ($scopedDir && strpos(str_replace('\\', '/', $legacyProductsDir), str_replace('\\', '/', $scopedDir)) === 0) {
                $legacyProductsUrl = $scopedLegacyUrl;
            }
        }

        if ($folder === 'shared') {
            if ($includeLegacy && $legacyBaseDir && is_dir($legacyBaseDir)) {
                $roots[] = ['dir' => $legacyBaseDir, 'base_url' => $legacyBaseUrl, 'label' => 'legacy'];
            }
            return $roots;
        }

        if ($folder === 'categories') {
            $catDir = rtrim((string) $companyDir, '/\\') . DIRECTORY_SEPARATOR . 'categories';
            if (is_dir($catDir)) {
                $roots[] = ['dir' => $catDir, 'base_url' => $tenantStorageUrl . '/categories', 'label' => 'tenant'];
            }
            if ($includeLegacy && $legacyBaseDir) {
                $legacyCat = $legacyBaseDir . DIRECTORY_SEPARATOR . 'categories';
                if (is_dir($legacyCat)) {
                    $roots[] = ['dir' => $legacyCat, 'base_url' => $legacyBaseUrl . '/categories', 'label' => 'legacy'];
                }
            }
            return $roots;
        }

        if ($folder === 'documents') {
            $docDir = rtrim((string) $companyDir, '/\\') . DIRECTORY_SEPARATOR . 'documents';
            if (is_dir($docDir)) {
                $roots[] = ['dir' => $docDir, 'base_url' => $tenantStorageUrl . '/documents', 'label' => 'tenant'];
            }
            foreach (['invoices', 'vouchers', 'general'] as $sub) {
                $subDir = rtrim((string) $companyDir, '/\\') . DIRECTORY_SEPARATOR . $sub;
                if (is_dir($subDir)) {
                    $roots[] = ['dir' => $subDir, 'base_url' => $tenantStorageUrl . '/' . $sub, 'label' => 'tenant'];
                }
            }
            return $roots;
        }

        if ($folder === 'products') {
            $tenantProducts = rtrim((string) $companyDir, '/\\') . DIRECTORY_SEPARATOR . 'products';
            if (is_dir($tenantProducts)) {
                $roots[] = ['dir' => $tenantProducts, 'base_url' => $tenantStorageUrl . '/products', 'label' => 'tenant'];
            }
            if ($includeLegacy) {
                if ($legacyProductsDir && is_dir($legacyProductsDir)) {
                    $roots[] = ['dir' => $legacyProductsDir, 'base_url' => $legacyProductsUrl, 'label' => 'legacy'];
                }
                if (function_exists('stock_uploads_shared_legacy_products_dir')) {
                    $sharedLegacy = stock_uploads_shared_legacy_products_dir();
                    if ($sharedLegacy && is_dir($sharedLegacy)) {
                        $roots[] = ['dir' => $sharedLegacy, 'base_url' => $legacyProductsUrl, 'label' => 'legacy'];
                    }
                }
            }
            return $roots;
        }

        if ($folder === 'uploads') {
            if (is_dir($companyDir)) {
                $roots[] = ['dir' => $companyDir, 'base_url' => $tenantStorageUrl, 'label' => 'tenant'];
            }
            if ($includeLegacy && $legacyBaseDir && is_dir($legacyBaseDir)) {
                $roots[] = ['dir' => $legacyBaseDir, 'base_url' => $legacyBaseUrl, 'label' => 'legacy'];
            }
            return $roots;
        }

        return $roots;
    }
}
if (!function_exists('uploads_scan_directory')) {
    /**
     * @return list<array<string,mixed>>
     */
    function uploads_scan_directory($rootDir, $webBaseUrl, $sourceLabel, $maxFiles, array &$seenKeys)
    {
        $found = [];
        $rootDir = (string) $rootDir;
        $webBaseUrl = rtrim((string) $webBaseUrl, '/');
        if ($rootDir === '' || !is_dir($rootDir)) {
            return $found;
        }
        $rootLen = strlen($rootDir);
        try {
            $it = new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator($rootDir, FilesystemIterator::SKIP_DOTS),
                RecursiveIteratorIterator::SELF_FIRST
            );
            foreach ($it as $f) {
                if (!($f instanceof SplFileInfo) || !$f->isFile()) {
                    continue;
                }
                $name = $f->getFilename();
                if ($name === '.htaccess' || $name === 'php.ini') {
                    continue;
                }
                $rel = str_replace('\\', '/', substr($f->getPathname(), $rootLen));
                $rel = ltrim($rel, '/');
                if (strpos($rel, 'recycle_bin/') === 0) {
                    continue;
                }
                global $pdo, $companyId, $folder;
                if (!stock_uploads_is_path_allowed($rel, $sourceLabel, $folder, $pdo, $companyId)) {
                    continue;
                }
                $dedupeKey = $webBaseUrl . '|' . $rel;
                if (isset($seenKeys[$dedupeKey])) {
                    continue;
                }
                $seenKeys[$dedupeKey] = true;
                $cardRel = function_exists('stock_uploads_normalize_card_rel')
                    ? stock_uploads_normalize_card_rel($rel, $sourceLabel, $folder)
                    : $rel;
                $found[] = [
                    'name' => $name,
                    'rel' => $cardRel,
                    'size' => (int) $f->getSize(),
                    'mtime' => (int) $f->getMTime(),
                    'is_image' => is_image_ext($name),
                    'ext' => strtolower(pathinfo($name, PATHINFO_EXTENSION)),
                    'base_url' => $webBaseUrl,
                    'source' => $sourceLabel,
                ];
                if (count($seenKeys) >= $maxFiles) {
                    break;
                }
            }
        } catch (Throwable $e) {
            error_log('uploads index.php scan (' . $sourceLabel . '): ' . $e->getMessage());
            if (isset($_GET['debug']) && $_GET['debug'] === '1') {
                die('File scan failed (' . htmlspecialchars($sourceLabel) . '): ' . htmlspecialchars($e->getMessage()));
            }
        }

        return $found;
    }
}

$scanRoots = uploads_scan_roots_for_folder($folder, $companyId, $companyDir, $legacyBaseDir, $legacyProductsDir, $uploadsUrl, $companySlug, $includeLegacy);
$seenFileKeys = [];
$files = [];
$maxFilesTotal = 1000;
foreach ($scanRoots as $scanRoot) {
    $chunk = uploads_scan_directory(
        $scanRoot['dir'],
        $scanRoot['base_url'],
        $scanRoot['label'],
        $maxFilesTotal,
        $seenFileKeys
    );
    foreach ($chunk as $row) {
        $files[] = $row;
    }
    if (count($seenFileKeys) >= $maxFilesTotal) {
        break;
    }
}

// Documents tab loads system attachments via ajax (avoids long page hang).
$loadDocumentsAsync = ($folder === 'documents' && $mode !== 'select');

$legacyFileCount = 0;
foreach ($files as $fRow) {
    if (($fRow['source'] ?? '') === 'legacy') {
        $legacyFileCount++;
    }
}

usort($files, static function ($a, $b) {
    return ($b['mtime'] <=> $a['mtime']);
});

if ($imagesOnly) {
    $files = array_values(array_filter($files, static function ($f) {
        return !empty($f['is_image']);
    }));
}

if ($allowSharedLegacy && $legacyBaseDir && is_dir($legacyBaseDir) && $folder === 'shared') {
    $uploadsBase = $legacyBaseDir;
} elseif (is_dir($companyDir)) {
    $uploadsBase = $companyDir;
} else {
    $uploadsBase = false;
}
$usedSpace = 0;
$totalSpace = 0;
$usedPercent = 0;
if ($uploadsBase && is_dir($uploadsBase)) {
    try {
        $usedSpace = get_dir_size($uploadsBase);
        $totalSpace = disk_total_space($uploadsBase);
        $usedPercent = ($totalSpace > 0) ? ($usedSpace / $totalSpace) * 100 : 0;
    } catch (Throwable $e) {
        error_log('uploads index.php disk stats: ' . $e->getMessage());
    }
}

$folderLabel = 'Files';
if ($folder === 'uploads') {
    $folderLabel = 'All uploads';
} elseif ($folder === 'products') {
    $folderLabel = 'Product uploads';
} elseif ($folder === 'categories') {
    $folderLabel = 'Category uploads';
} elseif ($folder === 'documents') {
    $folderLabel = 'Documents';
} elseif ($folder === 'shared') {
    $folderLabel = 'Shared / legacy';
}

$baseUrl = '';
if ($folder === 'shared') {
    $baseUrl = $uploadsUrl;
} else {
    $tenantUrl = '/storage/tenant_' . (int) $companyId;
    if (function_exists('app_url')) {
        $baseUrl = rtrim((string) app_url($tenantUrl), '/');
    } else {
        $baseUrl = $tenantUrl;
    }
    if ($folder === 'products') {
        $baseUrl .= '/products';
    } elseif ($folder === 'categories') {
        $baseUrl .= '/categories';
    } elseif ($folder === 'documents') {
        $baseUrl .= '/documents';
    }
}

$showProductsImageTools = ($imagesOnly && $mode !== 'select' && in_array($folder, ['products', 'uploads', 'shared'], true));

$filePayload = [];
foreach ($files as $f) {
    $fileBase = isset($f['base_url']) ? (string) $f['base_url'] : (string) $baseUrl;
    $rel = (string) ($f['rel'] ?? '');
    if (!empty($f['url_override'])) {
        $url = (string) $f['url_override'];
    } else {
        $url = function_exists('stock_uploads_public_href')
            ? stock_uploads_public_href($fileBase, $rel)
            : (rtrim($fileBase, '/') . '/' . ltrim($rel, '/'));
    }
    $filePayload[] = [
        'name' => (string) ($f['name'] ?? ''),
        'rel' => $rel,
        'size' => (int) ($f['size'] ?? 0),
        'size_label' => human_size($f['size'] ?? 0),
        'mtime' => (int) ($f['mtime'] ?? 0),
        'is_image' => !empty($f['is_image']),
        'ext' => (string) ($f['ext'] ?? ''),
        'url' => $url,
        'source' => (string) ($f['source'] ?? 'tenant'),
    ];
}

$uploadNavQuery = ['folder' => $folder];
if ($imagesOnly) {
    $uploadNavQuery['images'] = '1';
}

$assetBase = isset($stockBasePath) && $stockBasePath !== ''
    ? rtrim((string) $stockBasePath, '/') . '/'
    : (function_exists('app_url') ? rtrim(app_url('/stock'), '/') . '/' : '/stock/');
if (function_exists('app_url')) {
    $assetBase = rtrim(app_url('/stock'), '/') . '/';
} else {
    $assetBase = preg_replace('#/([A-Za-z0-9-]+)/stock/#', '/stock/', $assetBase) ?: $assetBase;
}
if (strpos($assetBase, '/stock/') === false) {
    $assetBase = '/stock/';
}

$employeeHeaderTitle = $mode === 'select' ? 'Select file' : 'Uploaded files';
$hideHeaderCompanyBranding = true;
$employeeHeaderExtraClass = 'employee-header--products-desk';
$bodyExtraClass = 'page-products-desk' . ($mode === 'select' ? ' page-uploads-select' : '');

$assetVersion = max(
    (int) (@filemtime(__DIR__ . '/../../stock-ui/dist/assets/stock-ui.js') ?: 0),
    (int) (@filemtime(__DIR__ . '/../../stock-ui/dist/assets/stock-ui.css') ?: 0),
    time()
);

include __DIR__ . '/../../includes/header.php';
?>
<style>
body.page-products-desk.dashboard .layout-main-wrapper { align-items: stretch; }
body.page-products-desk.dashboard .layout-main-wrapper > .flex-grow-1 {
    min-height: 0;
    display: flex;
    flex-direction: column;
}
body.page-products-desk,
body.page-products-desk.dashboard,
body.page-products-desk .layout-main-wrapper,
body.page-products-desk .layout-main-wrapper > .flex-grow-1 {
    background: #f8fafc !important;
}
body.page-products-desk .employee-header.employee-header--products-desk {
    background: #f8fafc !important;
    border: none !important;
    box-shadow: none !important;
    padding: 0 1.25rem !important;
    margin-bottom: 0;
    height: auto !important;
    min-height: 0;
    position: sticky !important;
    top: 0 !important;
    z-index: 1020 !important;
    align-items: stretch !important;
}
body.page-products-desk .employee-header--products-desk::after { display: none !important; }
body.page-products-desk .employee-header--products-desk .header-content {
    display: flex !important;
    flex-wrap: nowrap !important;
    align-items: center !important;
    padding: 0.75rem 0 0.5rem !important;
    min-height: 0;
    width: 100%;
    background: transparent !important;
    gap: 0.5rem 1rem;
}
body.page-products-desk .employee-header--products-desk .employee-header-page-heading {
    margin-left: 0 !important;
    min-width: 0;
    flex: 1 1 auto;
}
body.page-products-desk .employee-header--products-desk .employee-header-page-title {
    font-size: clamp(1.05rem, 2vw, 1.35rem) !important;
    font-weight: 700 !important;
    color: #0f172a !important;
    letter-spacing: -0.02em;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    max-width: min(42rem, 70vw);
}
body.page-products-desk .employee-header--products-desk .header-right.header-actions-tray {
    display: flex !important;
    align-items: center !important;
    justify-content: flex-end !important;
    margin-left: auto !important;
    flex: 0 0 auto !important;
    gap: 0.5rem !important;
}
main.main-content.products-desk-react-root {
    flex: 1 1 auto;
    width: 100% !important;
    max-width: none !important;
    padding: 0 1.25rem 2rem !important;
    overflow: auto !important;
    box-sizing: border-box;
    background: #f8fafc !important;
}
main.main-content.products-desk-react-root #root {
    width: 100%;
    max-width: none;
    margin: 0;
    min-height: 320px;
}
@media (max-width: 767.98px) {
    body.page-products-desk .employee-header.employee-header--products-desk { padding: 0 0.75rem !important; }
    main.main-content.products-desk-react-root { padding: 0 0.75rem 1.5rem !important; }
}
body.page-uploads-select #native-sidebar,
body.page-uploads-select .sidebar,
body.page-uploads-select .header,
body.page-uploads-select .admin-header,
body.page-uploads-select .employee-header,
body.page-uploads-select #sidebar-overlay {
    display: none !important;
}
body.page-uploads-select .main-content,
body.page-uploads-select .content-wrapper,
body.page-uploads-select main {
    margin-left: 0 !important;
    width: 100% !important;
    padding-top: 0 !important;
}
html[data-theme="dark"] body.page-products-desk,
html[data-theme="dark"] body.page-products-desk.dashboard,
html[data-theme="dark"] body.page-products-desk .layout-main-wrapper,
html[data-theme="dark"] body.page-products-desk .layout-main-wrapper > .flex-grow-1,
html[data-theme="dark"] body.page-products-desk main.main-content.products-desk-react-root {
    background: #0f172a !important;
}
html[data-theme="dark"] body.page-products-desk .employee-header.employee-header--products-desk {
    background: #0f172a !important;
}
html[data-theme="dark"] body.page-products-desk .employee-header--products-desk .employee-header-page-title {
    color: #f8fafc !important;
}
</style>
<main class="main-content products-desk-react-root<?= $mode === 'select' ? ' uploads-select-root' : '' ?>">
    <noscript>
        <div class="alert alert-warning m-3">JavaScript is required to browse uploads.</div>
    </noscript>
    <script>
        window.__STOCK_PAGE__ = <?= json_encode([
            'page' => 'uploads-list',
            'data' => [
                'mode' => $mode,
                'folder' => $folder,
                'folderLabel' => $folderLabel,
                'imagesOnly' => $imagesOnly,
                'files' => $filePayload,
                'companyId' => (int) $companyId,
                'companySlug' => $companySlug,
                'usedSpace' => (int) $usedSpace,
                'usedSpaceLabel' => human_size($usedSpace),
                'usedPercent' => round((float) $usedPercent, 2),
                'showProductsImageTools' => (bool) $showProductsImageTools,
                'allowSharedLegacy' => (bool) $allowSharedLegacy,
                'legacyFileCount' => (int) $legacyFileCount,
                'loadDocumentsAsync' => !empty($loadDocumentsAsync),
                'productsBaseUrl' => rtrim((string) $baseUrl, '/') . '/',
                'urls' => [
                    'upload' => 'upload.php?' . http_build_query($uploadNavQuery),
                    'recycleBin' => 'recycle_bin.php',
                    'delete' => 'ajax_delete.php',
                    'imageUsage' => 'ajax_image_usage.php',
                    'duplicateScan' => 'ajax_duplicate_scan.php',
                    'deleteDuplicates' => 'ajax_delete_duplicates.php',
                    'documents' => 'ajax_documents.php',
                    'self' => 'index.php',
                ],
            ],
        ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | (defined('JSON_INVALID_UTF8_SUBSTITUTE') ? JSON_INVALID_UTF8_SUBSTITUTE : 0)) ?: '{"page":"uploads-list","data":{"files":[]}}' ?>;
    </script>
    <link rel="stylesheet" href="<?= htmlspecialchars($assetBase, ENT_QUOTES, 'UTF-8') ?>stock-ui/dist/assets/stock-ui.css?v=<?= (int) $assetVersion ?>">
    <div id="root"></div>
    <script type="module" src="<?= htmlspecialchars($assetBase, ENT_QUOTES, 'UTF-8') ?>stock-ui/dist/assets/stock-ui.js?v=<?= (int) $assetVersion ?>"></script>
</main>
<?php include __DIR__ . '/../../includes/footer.php'; ?>
