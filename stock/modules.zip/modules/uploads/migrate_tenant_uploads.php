<?php
/**
 * Copy company product uploads from legacy stock/uploads/products/{id}/ to storage/tenant_{id}/products/.
 *
 * CLI:
 *   php stock/modules/uploads/migrate_tenant_uploads.php ultimate
 *   php stock/modules/uploads/migrate_tenant_uploads.php ultimate --dry-run
 */
$isCli = (PHP_SAPI === 'cli');

if (!defined('MIGRATE_TENANT_UPLOADS_ROOT')) {
    define('MIGRATE_TENANT_UPLOADS_ROOT', dirname(dirname(dirname(__DIR__))));
}

function migrate_tenant_uploads_app_root()
{
    return MIGRATE_TENANT_UPLOADS_ROOT;
}

if ($isCli) {
    $_SERVER['HTTP_HOST'] = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : 'localhost';
    require_once migrate_tenant_uploads_app_root() . '/includes/functions.php';
}

if (!function_exists('migrate_tenant_uploads_company_map')) {

function migrate_tenant_uploads_company_map()
{
    $map = array();
    $ultimateDb = defined('DATA_DB_NAME') ? (string) DATA_DB_NAME : '';
    $roadDb = defined('ROADMASTER_DB_NAME') ? (string) ROADMASTER_DB_NAME : '';

    try {
        $pdo = isset($GLOBALS['control_pdo']) ? $GLOBALS['control_pdo'] : null;
        if ($pdo instanceof PDO) {
            $cols = array('id', 'company_slug', 'db_name');
            if (function_exists('columnExists')) {
                if (columnExists('companies', 'db_host', $pdo)) {
                    $cols[] = 'db_host';
                }
                if (columnExists('companies', 'db_user', $pdo)) {
                    $cols[] = 'db_user';
                }
                if (columnExists('companies', 'db_pass', $pdo)) {
                    $cols[] = 'db_pass';
                }
            }
            $sql = 'SELECT ' . implode(', ', $cols) . ' FROM companies';
            if (function_exists('columnExists') && columnExists('companies', 'status', $pdo)) {
                $sql .= " WHERE status = 'active' OR status IS NULL";
            }
            $st = $pdo->query($sql);
            foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $row) {
                $slug = strtolower(trim((string) (isset($row['company_slug']) ? $row['company_slug'] : '')));
                if ($slug === '') {
                    continue;
                }
                $map[$slug] = array(
                    'id' => (int) (isset($row['id']) ? $row['id'] : 0),
                    'slug' => $slug,
                    'db_name' => trim((string) (isset($row['db_name']) ? $row['db_name'] : '')),
                    'db_host' => trim((string) (isset($row['db_host']) ? $row['db_host'] : '')),
                    'db_user' => trim((string) (isset($row['db_user']) ? $row['db_user'] : '')),
                    'db_pass' => isset($row['db_pass']) ? (string) $row['db_pass'] : '',
                );
            }
        }
    } catch (Throwable $e) {
        // env fallbacks below
    } catch (Exception $e) {
    }

    if (!isset($map['ultimate'])) {
        $map['ultimate'] = array('id' => 1, 'slug' => 'ultimate', 'db_name' => $ultimateDb, 'db_host' => '', 'db_user' => '', 'db_pass' => '');
    }
    if (!isset($map['roadmaster'])) {
        $map['roadmaster'] = array('id' => 2, 'slug' => 'roadmaster', 'db_name' => $roadDb, 'db_host' => '', 'db_user' => '', 'db_pass' => '');
    }

    foreach ($map as $slug => $row) {
        migrate_tenant_uploads_apply_env_defaults($slug, $map[$slug]);
    }

    return $map;
}

function migrate_tenant_uploads_apply_env_defaults($slug, array &$company)
{
    $slug = strtolower(trim((string) $slug));
    if ($slug === 'roadmaster') {
        if ($company['db_name'] === '' && defined('ROADMASTER_DB_NAME') && ROADMASTER_DB_NAME !== '') {
            $company['db_name'] = (string) ROADMASTER_DB_NAME;
        }
        if ($company['db_host'] === '' && defined('ROADMASTER_DB_HOST') && ROADMASTER_DB_HOST !== '') {
            $company['db_host'] = (string) ROADMASTER_DB_HOST;
        }
    }
    if ($slug === 'ultimate' && $company['db_name'] === '' && defined('DATA_DB_NAME') && DATA_DB_NAME !== '') {
        $company['db_name'] = (string) DATA_DB_NAME;
    }
}

function migrate_tenant_uploads_pdo_for_company(array $company)
{
    $dbName = trim((string) (isset($company['db_name']) ? $company['db_name'] : ''));
    if ($dbName === '') {
        return null;
    }

    $host = trim((string) (isset($company['db_host']) ? $company['db_host'] : ''));
    $user = trim((string) (isset($company['db_user']) ? $company['db_user'] : ''));
    $pass = null;
    if (isset($company['db_pass'])) {
        $raw = trim((string) $company['db_pass']);
        $pass = $raw !== '' ? $raw : null;
    }

    if (function_exists('connectToTenantDatabase')) {
        $pdo = connectToTenantDatabase($dbName, $host !== '' ? $host : null, $user !== '' ? $user : null, $pass);
        if ($pdo instanceof PDO) {
            return $pdo;
        }
    }

    $fallbackHost = defined('DB_HOST') ? DB_HOST : 'localhost';
    $fallbackUser = defined('DB_USER') ? DB_USER : 'root';
    $fallbackPass = defined('DB_PASS') ? DB_PASS : '';
    $hosts = array($host, $fallbackHost, 'localhost');
    if ($company['slug'] === 'roadmaster' && defined('ROADMASTER_DB_HOST') && ROADMASTER_DB_HOST !== '') {
        array_unshift($hosts, (string) ROADMASTER_DB_HOST);
    }
    $hosts = array_values(array_unique(array_filter($hosts, function ($h) {
        return trim((string) $h) !== '';
    })));
    $users = array($user, $fallbackUser);
    $users = array_values(array_unique(array_filter($users, function ($u) {
        return trim((string) $u) !== '';
    })));
    if (!$users) {
        $users = array($fallbackUser);
    }

    foreach ($hosts as $tryHost) {
        foreach ($users as $tryUser) {
            try {
                $pdo = new PDO(
                    'mysql:host=' . $tryHost . ';dbname=' . $dbName . ';charset=utf8mb4',
                    $tryUser,
                    $pass !== null ? $pass : $fallbackPass,
                    array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_TIMEOUT => 5)
                );
                return $pdo;
            } catch (Throwable $e) {
            } catch (Exception $e) {
            }
        }
    }

    return null;
}

function migrate_tenant_uploads_product_ids(PDO $pdo)
{
    $ids = array();
    try {
        foreach ($pdo->query('SELECT id FROM products')->fetchAll(PDO::FETCH_COLUMN) as $pid) {
            $ids[(int) $pid] = true;
        }
        $st = $pdo->query('SELECT DISTINCT product_id FROM product_images');
        if ($st) {
            foreach ($st->fetchAll(PDO::FETCH_COLUMN) as $pid) {
                $ids[(int) $pid] = true;
            }
        }
    } catch (Throwable $e) {
        throw new RuntimeException('Failed to load product IDs: ' . $e->getMessage());
    } catch (Exception $e) {
        throw new RuntimeException('Failed to load product IDs: ' . $e->getMessage());
    }

    return $ids;
}

function migrate_tenant_uploads_copy_tree($srcDir, $dstDir, $dryRun)
{
    $files = 0;
    $bytes = 0;
    if (!is_dir($srcDir)) {
        return array('files' => 0, 'bytes' => 0);
    }
    if (!$dryRun && !is_dir($dstDir)) {
        @mkdir($dstDir, 0755, true);
    }
    $it = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($srcDir, FilesystemIterator::SKIP_DOTS),
        RecursiveIteratorIterator::SELF_FIRST
    );
    foreach ($it as $item) {
        if (!($item instanceof SplFileInfo)) {
            continue;
        }
        $srcNorm = str_replace('\\', '/', $srcDir);
        $rel = substr(str_replace('\\', '/', $item->getPathname()), strlen($srcNorm) + 1);
        $target = $dstDir . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $rel);
        if ($item->isDir()) {
            if (!$dryRun && !is_dir($target)) {
                @mkdir($target, 0755, true);
            }
            continue;
        }
        $files++;
        $bytes += (int) $item->getSize();
        if ($dryRun) {
            continue;
        }
        $parent = dirname($target);
        if (!is_dir($parent)) {
            @mkdir($parent, 0755, true);
        }
        if (is_file($target) && filesize($target) === $item->getSize() && filemtime($target) >= $item->getMTime()) {
            continue;
        }
        if (!@copy($item->getPathname(), $target)) {
            throw new RuntimeException('Copy failed: ' . $item->getPathname());
        }
        @touch($target, $item->getMTime());
    }

    return array('files' => $files, 'bytes' => $bytes);
}

function migrate_tenant_uploads_run($companySlug, $dryRun = false)
{
    $root = migrate_tenant_uploads_app_root();
    $companySlug = strtolower(trim((string) $companySlug));
    $map = migrate_tenant_uploads_company_map();
    if (!isset($map[$companySlug])) {
        throw new InvalidArgumentException('Unknown company slug: ' . $companySlug);
    }
    $company = $map[$companySlug];
    $companyId = (int) $company['id'];
    if ($companyId <= 0) {
        throw new RuntimeException('Invalid company id for ' . $companySlug);
    }

    $pdo = migrate_tenant_uploads_pdo_for_company($company);
    if (!($pdo instanceof PDO)) {
        $hostHint = trim((string) (isset($company['db_host']) ? $company['db_host'] : ''));
        $userHint = trim((string) (isset($company['db_user']) ? $company['db_user'] : ''));
        throw new RuntimeException(
            'Could not connect to tenant DB: ' . $company['db_name']
            . ($hostHint !== '' ? ' @ ' . $hostHint : '')
            . ($userHint !== '' ? ' (user ' . $userHint . ')' : '')
            . '. Set companies.db_host / db_user / db_pass for Roadmaster in Admin ? Companies, or ROADMASTER_DB_HOST in env.php.'
        );
    }

    $productIds = migrate_tenant_uploads_product_ids($pdo);
    ksort($productIds);

    $legacyProducts = migrate_tenant_uploads_app_root() . DIRECTORY_SEPARATOR . 'stock' . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . 'products';
    $legacyProducts = is_dir($legacyProducts) ? (realpath($legacyProducts) ?: $legacyProducts) : null;
    if (!$legacyProducts) {
        throw new RuntimeException('Legacy folder not found: stock/uploads/products');
    }

    $tenantProducts = $root . DIRECTORY_SEPARATOR . 'storage' . DIRECTORY_SEPARATOR . 'tenant_' . $companyId . DIRECTORY_SEPARATOR . 'products';
    if (!$dryRun) {
        @mkdir($tenantProducts, 0755, true);
    }
    $tenantProducts = is_dir($tenantProducts) ? (realpath($tenantProducts) ?: $tenantProducts) : $tenantProducts;

    $stats = array(
        'company' => $companySlug,
        'company_id' => $companyId,
        'db_name' => $company['db_name'],
        'dry_run' => $dryRun ? true : false,
        'legacy_root' => $legacyProducts,
        'tenant_root' => $tenantProducts,
        'product_ids_in_db' => count($productIds),
        'folders_copied' => 0,
        'folders_missing_legacy' => 0,
        'files_copied' => 0,
        'bytes_copied' => 0,
        'errors' => array(),
    );

    foreach (array_keys($productIds) as $productId) {
        $src = $legacyProducts . DIRECTORY_SEPARATOR . $productId;
        if (!is_dir($src)) {
            $stats['folders_missing_legacy']++;
            continue;
        }
        $dst = $tenantProducts . DIRECTORY_SEPARATOR . $productId;
        try {
            $copy = migrate_tenant_uploads_copy_tree($src, $dst, $dryRun);
            $stats['folders_copied']++;
            $stats['files_copied'] += $copy['files'];
            $stats['bytes_copied'] += $copy['bytes'];
        } catch (Throwable $e) {
            $stats['errors'][] = 'product ' . $productId . ': ' . $e->getMessage();
        } catch (Exception $e) {
            $stats['errors'][] = 'product ' . $productId . ': ' . $e->getMessage();
        }
    }

    $logDir = $root . DIRECTORY_SEPARATOR . 'storage' . DIRECTORY_SEPARATOR . 'logs';
    if (!is_dir($logDir)) {
        @mkdir($logDir, 0755, true);
    }
    $logFile = $logDir . DIRECTORY_SEPARATOR . 'migrate_tenant_' . $companyId . '_' . $companySlug . '_' . date('Ymd_His') . '.json';
    @file_put_contents($logFile, json_encode($stats, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
    $stats['log_file'] = $logFile;

    return $stats;
}

} // end function_exists guard

if (defined('MIGRATE_TENANT_UPLOADS_SKIP_ENTRY') && MIGRATE_TENANT_UPLOADS_SKIP_ENTRY) {
    return;
}

$companySlug = 'ultimate';
$dryRun = false;

if ($isCli) {
    global $argv;
    $companySlug = strtolower(trim((string) (isset($argv[1]) ? $argv[1] : 'ultimate')));
    $dryRun = is_array($argv) && (in_array('--dry-run', $argv, true) || in_array('-n', $argv, true));
} else {
    require_once migrate_tenant_uploads_app_root() . '/includes/functions.php';
    if (!function_exists('isLoggedIn') || !isLoggedIn() || !function_exists('isSuperAdmin') || !isSuperAdmin()) {
        http_response_code(403);
        die('Super admin login required.');
    }
    $companySlug = strtolower(trim((string) (isset($_GET['company']) ? $_GET['company'] : 'ultimate')));
    $dryRun = isset($_GET['dry_run']) && (string) $_GET['dry_run'] === '1';
    if (!isset($_GET['run']) || (string) $_GET['run'] !== '1') {
        header('Location: ' . (function_exists('app_url') ? app_url('/admin/migrate-tenant-uploads.php') : '/admin/migrate-tenant-uploads.php'));
        exit;
    }
    @set_time_limit(0);
    header('Content-Type: application/json; charset=utf-8');
}

try {
    $result = migrate_tenant_uploads_run($companySlug, $dryRun);
    echo json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) . ($isCli ? PHP_EOL : '');
    exit(empty($result['errors']) ? 0 : 1);
} catch (Throwable $e) {
    $err = array('ok' => false, 'error' => $e->getMessage());
    if ($isCli) {
        fwrite(STDERR, json_encode($err) . PHP_EOL);
        exit(1);
    }
    http_response_code(500);
    echo json_encode($err);
    exit(1);
} catch (Exception $e) {
    $err = array('ok' => false, 'error' => $e->getMessage());
    http_response_code(500);
    echo json_encode($err);
    exit(1);
}
