<?php
// stock/modules/uploads/recycle_bin.php
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../config/functions.php';
require_once __DIR__ . '/uploads_recycle_bin.inc.php';
requireLogin();

$active_module = 'stocks';
$page_title = 'Upload recycle bin';

$items = array();
$recycleBinError = '';
try {
    stock_uploads_recycle_ensure_schema($pdo);
    $st = $pdo->query('SELECT id, created_at, kind, label, product_id, image_name, user_id FROM upload_recycle_bin ORDER BY id DESC LIMIT 500');
    $items = $st ? $st->fetchAll(PDO::FETCH_ASSOC) : array();
} catch (Throwable $e) {
    error_log('recycle_bin.php: ' . $e->getMessage());
    $recycleBinError = $e->getMessage();
    if (isset($_GET['debug']) && $_GET['debug'] === '1') {
        die('Recycle bin error: ' . htmlspecialchars($e->getMessage()));
    }
}

$totalItems = count($items);
$perPage = 20;
$page = max(1, (int) ($_GET['page'] ?? 1));
$totalPages = max(1, (int) ceil($totalItems / $perPage));
if ($page > $totalPages) {
    $page = $totalPages;
}
$offset = ($page - 1) * $perPage;
$pageItems = $totalItems > 0 ? array_slice($items, $offset, $perPage) : array();
$rangeFrom = $totalItems > 0 ? $offset + 1 : 0;
$rangeTo = $totalItems > 0 ? min($offset + $perPage, $totalItems) : 0;

/**
 * @param array<string,mixed> $row
 */
function recycle_bin_row_description(array $row)
{
    $label = trim((string) ($row['label'] ?? ''));
    if ($label !== '') {
        return $label;
    }
    if (!empty($row['image_name'])) {
        $pid = (int) ($row['product_id'] ?? 0);
        if ($pid > 0) {
            return 'products/' . $pid . '/…/' . (string) $row['image_name'];
        }
        return (string) $row['image_name'];
    }

    return '#' . (int) ($row['id'] ?? 0);
}

/**
 * @param array<string,mixed> $row
 */
function recycle_bin_has_preview(array $row)
{
    global $recycleUploadsBaseDir;
    if (!$recycleUploadsBaseDir || !function_exists('stock_uploads_recycle_preview_file_path')) {
        return false;
    }
    $binId = (int) ($row['id'] ?? 0);

    return $binId > 0 && stock_uploads_recycle_preview_file_path($recycleUploadsBaseDir, $binId) !== null;
}

/**
 * @param array<string,mixed> $row
 */
function recycle_bin_preview_src(array $row)
{
    $binId = (int) ($row['id'] ?? 0);
    if ($binId < 1) {
        return '';
    }

    return 'recycle_bin_preview.php?id=' . $binId;
}

$recycleUploadsBaseDir = realpath(__DIR__ . '/../../uploads');

include __DIR__ . '/../../includes/header.php';
?>

<link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">

<style>
    body { font-family: 'Inter', system-ui, -apple-system, sans-serif; }
    .rb-btn-outline {
        display: inline-flex;
        align-items: center;
        gap: 0.5rem;
        padding: 0.5rem 1.25rem;
        border-radius: 0.5rem;
        border: 1px solid #c4b5fd;
        background: #fff;
        color: #6d28d9;
        font-size: 0.875rem;
        font-weight: 600;
        transition: background 0.15s, border-color 0.15s;
    }
    .rb-btn-outline:hover:not(:disabled) { background: #f5f3ff; border-color: #a78bfa; }
    .rb-btn-outline:disabled { opacity: 0.45; cursor: not-allowed; }
    .rb-btn-primary {
        display: inline-flex;
        align-items: center;
        gap: 0.5rem;
        padding: 0.5rem 1.25rem;
        border-radius: 0.5rem;
        border: none;
        background: #7c3aed;
        color: #fff;
        font-size: 0.875rem;
        font-weight: 600;
        box-shadow: 0 1px 2px rgba(124, 58, 237, 0.25);
        transition: background 0.15s;
    }
    .rb-btn-primary:hover:not(:disabled) { background: #6d28d9; }
    .rb-btn-primary:disabled { opacity: 0.45; cursor: not-allowed; }
    .rb-btn-restore {
        display: inline-flex;
        align-items: center;
        gap: 0.35rem;
        padding: 0.35rem 0.75rem;
        border-radius: 0.375rem;
        border: 1px solid #c4b5fd;
        background: #fff;
        color: #6d28d9;
        font-size: 0.8125rem;
        font-weight: 600;
    }
    .rb-btn-restore:hover { background: #f5f3ff; }
    .rb-btn-purge {
        display: inline-flex;
        align-items: center;
        gap: 0.35rem;
        padding: 0.35rem 0.75rem;
        border-radius: 0.375rem;
        border: 1px solid #fecaca;
        background: #fff;
        color: #dc2626;
        font-size: 0.8125rem;
        font-weight: 600;
    }
    .rb-btn-purge:hover { background: #fef2f2; }
    .rb-sort-btn { cursor: pointer; user-select: none; }
    .rb-sort-btn:hover { color: #6d28d9; }
    .rb-row-menu {
        display: none;
        position: absolute;
        right: 0;
        top: 100%;
        margin-top: 4px;
        min-width: 10rem;
        background: #fff;
        border: 1px solid #e5e7eb;
        border-radius: 0.5rem;
        box-shadow: 0 10px 15px -3px rgba(0,0,0,0.08);
        z-index: 40;
        padding: 0.25rem 0;
    }
    .rb-row-menu.show { display: block; }
    .rb-row-menu button {
        display: block;
        width: 100%;
        text-align: left;
        padding: 0.5rem 0.75rem;
        font-size: 0.8125rem;
        color: #374151;
    }
    .rb-row-menu button:hover { background: #f9fafb; }
    .rb-page-btn {
        min-width: 2rem;
        height: 2rem;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        border-radius: 0.375rem;
        font-size: 0.8125rem;
        font-weight: 600;
        color: #6b7280;
        border: 1px solid transparent;
    }
    .rb-page-btn:hover:not(:disabled) { background: #f3f4f6; }
    .rb-page-btn.active {
        background: #7c3aed;
        color: #fff;
        border-color: #7c3aed;
    }
    .rb-page-btn:disabled { opacity: 0.35; cursor: not-allowed; }
    .rb-thumb {
        width: 3rem;
        height: 3rem;
        object-fit: cover;
        border-radius: 0.5rem;
        border: 1px solid #e5e7eb;
        background: #f9fafb;
        display: block;
    }
    .rb-thumb-placeholder {
        width: 3rem;
        height: 3rem;
        border-radius: 0.5rem;
        border: 1px solid #e5e7eb;
        background: #f3f4f6;
        color: #9ca3af;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        font-size: 0.75rem;
    }
    @media (max-width: 992px) {
        .rb-header-grid { flex-direction: column; align-items: stretch !important; }
        .rb-summary-card { width: 100%; }
        .rb-table-wrap { overflow-x: auto; }
    }
</style>

<main class="main-content">
    <div class="bg-gray-50 min-h-screen pb-12">
        <div class="px-6 py-6 max-w-7xl mx-auto">
            <!-- Page header + summary -->
            <div class="rb-header-grid flex flex-col lg:flex-row lg:items-start lg:justify-between gap-6 mb-6">
                <div class="flex-1 min-w-0">
                    <h1 class="text-2xl font-bold text-gray-900 tracking-tight">Upload recycle bin</h1>
                    <p class="text-sm text-gray-500 mt-1 max-w-2xl">
                        Deleted uploads stay here until you restore them or empty the bin permanently.
                    </p>
                    <div class="flex flex-wrap items-center gap-3 mt-5">
                        <a href="index.php" class="rb-btn-outline">
                            <i class="fas fa-arrow-left text-xs" aria-hidden="true"></i>
                            Back to uploads
                        </a>
                        <button type="button" id="restoreAllBtn" class="rb-btn-outline" <?= $totalItems === 0 ? 'disabled' : '' ?>>
                            <i class="fas fa-undo text-xs" aria-hidden="true"></i>
                            Restore all
                        </button>
                        <button type="button" id="purgeAllBtn" class="rb-btn-primary" <?= $totalItems === 0 ? 'disabled' : '' ?>>
                            <i class="fas fa-trash-alt text-xs" aria-hidden="true"></i>
                            Empty bin
                        </button>
                    </div>
                </div>
                <div class="rb-summary-card flex-shrink-0">
                    <div class="bg-white rounded-xl border border-gray-200 shadow-sm px-5 py-4 flex items-center gap-4 min-w-[200px]">
                        <div class="w-12 h-12 rounded-lg bg-purple-100 text-purple-600 flex items-center justify-center flex-shrink-0">
                            <i class="fas fa-trash-restore text-lg" aria-hidden="true"></i>
                        </div>
                        <div>
                            <div class="text-2xl font-bold text-gray-900 leading-none" id="rbItemCount"><?= (int) $totalItems ?></div>
                            <div class="text-xs text-gray-500 mt-1 font-medium">Items in recycle bin</div>
                        </div>
                    </div>
                </div>
            </div>

            <?php if ($recycleBinError !== ''): ?>
                <div class="mb-4 px-4 py-3 rounded-lg bg-red-50 border border-red-200 text-sm text-red-800">
                    Could not load recycle bin metadata. The <code>upload_recycle_bin</code> table may be missing on the active database.
                    <?php if ($pdo instanceof PDO): ?>
                    <?php try { $rbDb = (string) $pdo->query('SELECT DATABASE()')->fetchColumn(); } catch (Throwable $ignored) { $rbDb = ''; } ?>
                    <?php if ($rbDb !== ''): ?>
                    <span class="block mt-1 text-xs">Database: <code><?= htmlspecialchars($rbDb) ?></code></span>
                    <?php endif; ?>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <?php if ($totalItems === 0): ?>
                <div class="bg-white rounded-xl border border-gray-200 shadow-sm p-12 text-center">
                    <div class="w-14 h-14 rounded-full bg-purple-50 text-purple-500 flex items-center justify-center mx-auto mb-4">
                        <i class="fas fa-trash-alt text-xl" aria-hidden="true"></i>
                    </div>
                    <p class="text-gray-600 font-medium">The recycle bin is empty.</p>
                    <p class="text-sm text-gray-400 mt-1">Deleted uploads from the file manager will appear here.</p>
                    <a href="index.php" class="inline-block mt-6 rb-btn-outline">Back to uploads</a>
                </div>
            <?php else: ?>
                <div class="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
                    <div class="rb-table-wrap">
                        <table class="min-w-full text-sm" id="recycleBinTable">
                            <thead>
                                <tr class="border-b border-gray-100 text-left text-xs font-bold text-gray-500 uppercase tracking-wide">
                                    <th class="px-4 py-3 w-16" scope="col">Image</th>
                                    <th class="px-4 py-3 whitespace-nowrap" scope="col">
                                        <button type="button" class="rb-sort-btn inline-flex items-center gap-1 bg-transparent border-0 p-0 font-bold text-gray-500 uppercase tracking-wide" data-sort="when" aria-label="Sort by date">
                                            When
                                            <i class="fas fa-sort text-[10px] text-gray-400" aria-hidden="true"></i>
                                        </button>
                                    </th>
                                    <th class="px-4 py-3" scope="col">Type</th>
                                    <th class="px-4 py-3" scope="col">Description</th>
                                    <th class="px-4 py-3 text-right w-64" scope="col">Actions</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-gray-50" id="recycleBinBody">
                                <?php foreach ($pageItems as $row):
                                    $desc = recycle_bin_row_description($row);
                                    $kind = (string) ($row['kind'] ?? 'file');
                                    $when = (string) ($row['created_at'] ?? '');
                                    $rid = (int) ($row['id'] ?? 0);
                                    $hasPreview = recycle_bin_has_preview($row);
                                    $previewSrc = $hasPreview ? recycle_bin_preview_src($row) : '';
                                ?>
                                <tr class="hover:bg-gray-50/80 transition-colors" data-id="<?= $rid ?>" data-when="<?= htmlspecialchars($when) ?>">
                                    <td class="px-4 py-3 align-middle">
                                        <?php if ($hasPreview && $previewSrc !== ''): ?>
                                            <a href="<?= htmlspecialchars($previewSrc) ?>" target="_blank" rel="noopener" class="block" title="View image">
                                                <img src="<?= htmlspecialchars($previewSrc) ?>" alt="" class="rb-thumb" loading="lazy" width="48" height="48">
                                            </a>
                                        <?php else: ?>
                                            <span class="rb-thumb-placeholder" title="No preview">
                                                <i class="far fa-image" aria-hidden="true"></i>
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="px-4 py-3 text-gray-600 whitespace-nowrap align-middle font-medium"><?= htmlspecialchars($when) ?></td>
                                    <td class="px-4 py-3 text-gray-700 align-middle">
                                        <span class="font-mono text-xs text-gray-600 bg-gray-50 px-2 py-0.5 rounded"><?= htmlspecialchars($kind) ?></span>
                                    </td>
                                    <td class="px-4 py-3 text-gray-800 align-middle break-all max-w-md"><?= htmlspecialchars($desc) ?></td>
                                    <td class="px-4 py-3 text-right align-middle whitespace-nowrap">
                                        <div class="inline-flex items-center justify-end gap-2 relative">
                                            <button type="button" class="js-restore rb-btn-restore" data-id="<?= $rid ?>">
                                                <i class="fas fa-undo text-[10px]" aria-hidden="true"></i>
                                                Restore
                                            </button>
                                            <button type="button" class="js-purge rb-btn-purge" data-id="<?= $rid ?>">
                                                <i class="fas fa-trash-alt text-[10px]" aria-hidden="true"></i>
                                                Delete forever
                                            </button>
                                            <div class="relative inline-block">
                                                <button type="button" class="rb-row-menu-toggle w-8 h-8 rounded-md text-gray-400 hover:bg-gray-100 hover:text-gray-600" aria-label="More actions" data-desc="<?= htmlspecialchars($desc, ENT_QUOTES, 'UTF-8') ?>">
                                                    <i class="fas fa-ellipsis-v" aria-hidden="true"></i>
                                                </button>
                                                <div class="rb-row-menu" role="menu">
                                                    <button type="button" class="js-copy-desc" role="menuitem">Copy description</button>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="px-4 py-3 border-t border-gray-100 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 text-sm text-gray-500">
                        <p>
                            Showing <span class="font-semibold text-gray-700"><?= (int) $rangeFrom ?></span>
                            to <span class="font-semibold text-gray-700"><?= (int) $rangeTo ?></span>
                            of <span class="font-semibold text-gray-700"><?= (int) $totalItems ?></span> items
                        </p>
                        <nav class="inline-flex items-center gap-1" aria-label="Pagination">
                            <?php
                            $prevPage = $page > 1 ? $page - 1 : null;
                            $nextPage = $page < $totalPages ? $page + 1 : null;
                            ?>
                            <a href="<?= $prevPage ? '?page=' . (int) $prevPage : '#' ?>"
                               class="rb-page-btn <?= $prevPage ? '' : 'pointer-events-none' ?>"
                               <?= $prevPage ? '' : 'aria-disabled="true"' ?>>
                                <i class="fas fa-chevron-left text-xs" aria-hidden="true"></i>
                            </a>
                            <?php for ($p = 1; $p <= $totalPages; $p++):
                                if ($totalPages > 7 && $p > 2 && $p < $totalPages - 1 && abs($p - $page) > 1) {
                                    if ($p === 3 || $p === $totalPages - 2) {
                                        echo '<span class="px-1 text-gray-400">…</span>';
                                    }
                                    continue;
                                }
                            ?>
                            <a href="?page=<?= (int) $p ?>"
                               class="rb-page-btn <?= $p === $page ? 'active' : '' ?>"
                               <?= $p === $page ? 'aria-current="page"' : '' ?>><?= (int) $p ?></a>
                            <?php endfor; ?>
                            <a href="<?= $nextPage ? '?page=' . (int) $nextPage : '#' ?>"
                               class="rb-page-btn <?= $nextPage ? '' : 'pointer-events-none' ?>"
                               <?= $nextPage ? '' : 'aria-disabled="true"' ?>>
                                <i class="fas fa-chevron-right text-xs" aria-hidden="true"></i>
                            </a>
                        </nav>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</main>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
(function () {
    function post(action, body) {
        return fetch('ajax_recycle_bin.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(Object.assign({ action: action }, body || {}))
        }).then(function (r) { return r.json(); });
    }

    document.querySelectorAll('.js-restore').forEach(function (btn) {
        btn.addEventListener('click', function () {
            var id = parseInt(btn.getAttribute('data-id'), 10);
            Swal.fire({
                title: 'Restore this item?',
                text: 'Files go back to their original folders; catalog links are recreated when applicable.',
                icon: 'question',
                showCancelButton: true,
                confirmButtonText: 'Restore'
            }).then(function (res) {
                if (!res.isConfirmed) return;
                post('restore', { id: id }).then(function (data) {
                    if (data.ok) {
                        Swal.fire('Restored', '', 'success').then(function () { location.reload(); });
                    } else {
                        Swal.fire('Could not restore', data.message || 'Unknown error', 'error');
                    }
                }).catch(function () {
                    Swal.fire('Error', 'Request failed', 'error');
                });
            });
        });
    });

    document.querySelectorAll('.js-purge').forEach(function (btn) {
        btn.addEventListener('click', function () {
            var id = parseInt(btn.getAttribute('data-id'), 10);
            Swal.fire({
                title: 'Delete forever?',
                text: 'This cannot be undone.',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Delete forever',
                confirmButtonColor: '#dc2626'
            }).then(function (res) {
                if (!res.isConfirmed) return;
                post('purge', { id: id }).then(function (data) {
                    if (data.ok) {
                        Swal.fire('Removed', '', 'success').then(function () { location.reload(); });
                    } else {
                        Swal.fire('Error', data.message || 'Unknown error', 'error');
                    }
                }).catch(function () {
                    Swal.fire('Error', 'Request failed', 'error');
                });
            });
        });
    });

    var restoreAll = document.getElementById('restoreAllBtn');
    if (restoreAll) {
        restoreAll.addEventListener('click', function () {
            Swal.fire({
                title: 'Restore all items?',
                text: 'Every file in the recycle bin will be moved back to its original location. Catalog links are recreated when applicable.',
                icon: 'question',
                showCancelButton: true,
                confirmButtonText: 'Restore all',
                confirmButtonColor: '#7c3aed'
            }).then(function (res) {
                if (!res.isConfirmed) return;
                restoreAll.disabled = true;
                post('restore_all', {}).then(function (data) {
                    if (data.ok) {
                        var msg = (data.restored || 0) + ' item(s) restored.';
                        if (data.errors && data.errors.length) {
                            msg += ' ' + data.errors.length + ' failed.';
                        }
                        Swal.fire('Restore complete', msg, data.errors && data.errors.length ? 'warning' : 'success').then(function () { location.reload(); });
                    } else {
                        restoreAll.disabled = false;
                        Swal.fire('Error', (data.errors && data.errors[0]) || data.message || 'Unknown error', 'error');
                    }
                }).catch(function () {
                    restoreAll.disabled = false;
                    Swal.fire('Error', 'Request failed', 'error');
                });
            });
        });
    }

    var purgeAll = document.getElementById('purgeAllBtn');
    if (purgeAll) {
        purgeAll.addEventListener('click', function () {
            Swal.fire({
                title: 'Empty entire recycle bin?',
                text: 'All items will be permanently deleted.',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Empty bin',
                confirmButtonColor: '#7c3aed'
            }).then(function (res) {
                if (!res.isConfirmed) return;
                post('purge_all', {}).then(function (data) {
                    if (data.ok) {
                        Swal.fire('Bin emptied', (data.purged || 0) + ' item(s) removed.', 'success').then(function () { location.reload(); });
                    } else {
                        Swal.fire('Error', (data.errors && data.errors[0]) || data.message || 'Unknown error', 'error');
                    }
                }).catch(function () {
                    Swal.fire('Error', 'Request failed', 'error');
                });
            });
        });
    }

    document.querySelectorAll('.rb-row-menu-toggle').forEach(function (btn) {
        btn.addEventListener('click', function (e) {
            e.stopPropagation();
            var menu = btn.parentElement.querySelector('.rb-row-menu');
            document.querySelectorAll('.rb-row-menu.show').forEach(function (m) {
                if (m !== menu) m.classList.remove('show');
            });
            if (menu) menu.classList.toggle('show');
        });
    });
    document.addEventListener('click', function () {
        document.querySelectorAll('.rb-row-menu.show').forEach(function (m) { m.classList.remove('show'); });
    });

    document.querySelectorAll('.js-copy-desc').forEach(function (btn) {
        btn.addEventListener('click', function (e) {
            e.stopPropagation();
            var wrap = btn.closest('.relative');
            var toggle = wrap ? wrap.querySelector('.rb-row-menu-toggle') : null;
            var text = toggle ? (toggle.getAttribute('data-desc') || '') : '';
            if (!text) return;
            if (navigator.clipboard && navigator.clipboard.writeText) {
                navigator.clipboard.writeText(text).then(function () {
                    Swal.fire({ toast: true, position: 'top-end', icon: 'success', title: 'Copied', showConfirmButton: false, timer: 1500 });
                });
            }
            var menu = wrap ? wrap.querySelector('.rb-row-menu') : null;
            if (menu) menu.classList.remove('show');
        });
    });

    var sortBtn = document.querySelector('[data-sort="when"]');
    var tbody = document.getElementById('recycleBinBody');
    var sortAsc = false;
    if (sortBtn && tbody) {
        sortBtn.addEventListener('click', function () {
            sortAsc = !sortAsc;
            var rows = Array.prototype.slice.call(tbody.querySelectorAll('tr'));
            rows.sort(function (a, b) {
                var ta = a.getAttribute('data-when') || '';
                var tb = b.getAttribute('data-when') || '';
                if (ta === tb) return 0;
                return sortAsc ? (ta < tb ? -1 : 1) : (ta > tb ? -1 : 1);
            });
            rows.forEach(function (r) { tbody.appendChild(r); });
            var icon = sortBtn.querySelector('i');
            if (icon) {
                icon.className = sortAsc ? 'fas fa-sort-up text-[10px] text-purple-600' : 'fas fa-sort-down text-[10px] text-purple-600';
            }
        });
    }
})();
</script>

<?php include __DIR__ . '/../../includes/footer.php'; ?>
