<?php
// stock/modules/uploads/recycle_bin_preview.php � serve recycle-bin image thumbnails (auth required)
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../config/functions.php';
require_once __DIR__ . '/uploads_recycle_bin.inc.php';
requireLogin();

$binId = isset($_GET['id']) ? (int) $_GET['id'] : 0;
if ($binId < 1) {
    http_response_code(404);
    exit;
}

$baseDir = realpath(__DIR__ . '/../../uploads');
if (!$baseDir) {
    http_response_code(404);
    exit;
}

stock_uploads_recycle_ensure_schema($pdo);
$st = $pdo->prepare('SELECT id FROM upload_recycle_bin WHERE id = ? LIMIT 1');
$st->execute(array($binId));
if (!$st->fetchColumn()) {
    http_response_code(404);
    exit;
}

$filePath = stock_uploads_recycle_preview_file_path($baseDir, $binId);
if ($filePath === null || !is_file($filePath) || !is_readable($filePath)) {
    http_response_code(404);
    exit;
}

$ext = strtolower(pathinfo($filePath, PATHINFO_EXTENSION));
$types = array(
    'jpg' => 'image/jpeg',
    'jpeg' => 'image/jpeg',
    'png' => 'image/png',
    'gif' => 'image/gif',
    'webp' => 'image/webp',
    'bmp' => 'image/bmp',
    'svg' => 'image/svg+xml',
);
$contentType = isset($types[$ext]) ? $types[$ext] : 'application/octet-stream';

header('Content-Type: ' . $contentType);
header('Cache-Control: private, max-age=300');
header('Content-Length: ' . (string) filesize($filePath));
readfile($filePath);
exit;
