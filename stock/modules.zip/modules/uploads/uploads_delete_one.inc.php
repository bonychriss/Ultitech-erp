<?php
/**
 * Delete one file under stock/uploads by path relative to uploads/ (e.g. products/12/medium/foo.jpg).
 * Files go to the upload recycle bin (see uploads_recycle_bin.inc.php). Mirrors ajax_delete.php.
 *
 * @return array{ok:bool,message?:string}
 */
require_once __DIR__ . '/uploads_recycle_bin.inc.php';
require_once __DIR__ . '/auth_helper.php';
require_once __DIR__ . '/../../config/functions.php';

function stock_uploads_norm_products_rel(string $r): string
{
    $r = str_replace(['../', './'], '', trim($r));
    $r = ltrim($r, '/');
    if (strpos($r, 'products/') === 0) {
        return $r;
    }

    return 'products/' . $r;
}

/**
 * Parse products/{id}/{original|thumbnail|medium|large}/{basename} (flat basename, no nested dirs).
 *
 * @return array{product_id:int, variant:string, basename:string}|null
 */
function stock_uploads_parse_product_variant_rel($relPath)
{
    $relPath = stock_uploads_norm_products_rel($relPath);
    if (strpos($relPath, 'products/') !== 0) {
        return null;
    }
    $inner = substr($relPath, strlen('products/'));
    $parts = explode('/', $inner);
    if (count($parts) < 3) {
        return null;
    }
    if (!ctype_digit($parts[0])) {
        return null;
    }
    $variant = strtolower($parts[1]);
    if (!in_array($variant, ['original', 'thumbnail', 'medium', 'large'], true)) {
        return null;
    }
    $basename = implode('/', array_slice($parts, 2));
    if ($basename === '' || strpos($basename, '/') !== false) {
        return null;
    }

    return [
        'product_id' => (int) $parts[0],
        'variant' => $variant,
        'basename' => $basename,
    ];
}

/** Same catalog image: same product id + same filename, different size variant only. */
function stock_uploads_same_product_image_variant_pair(string $relKeep, string $relDelete): bool
{
    $a = stock_uploads_parse_product_variant_rel($relKeep);
    $b = stock_uploads_parse_product_variant_rel($relDelete);
    if ($a === null || $b === null) {
        return false;
    }
    if ($a['product_id'] !== $b['product_id']) {
        return false;
    }

    return strcasecmp($a['basename'], $b['basename']) === 0;
}

/**
 * Remove only one on-disk variant file; does NOT touch product_images or main_image.
 * File is moved to the recycle bin (duplicate cleanup).
 */
function stock_uploads_unlink_product_variant_only(PDO $pdo, string $baseDir, string $relPath): array
{
    $relPath = stock_uploads_norm_products_rel($relPath);
    $companySlug = strtolower(trim((string) ($_SESSION['company_slug'] ?? '')));
    $companyId = (int) ($_SESSION['company_id'] ?? 0);
    if ($companyId <= 0 && function_exists('currentCompanyId')) {
        $companyId = (int) currentCompanyId();
    }
    if ($companyId <= 0) {
        if ($companySlug === 'ultimate') {
            $companyId = 1;
        } elseif ($companySlug === 'roadmaster') {
            $companyId = 2;
        }
    }
    if (function_exists('stock_company_pdo')) {
        $pdo = stock_company_pdo();
    }
    $srcLabel = stock_uploads_delete_source_label_for_base($baseDir);
    if (!stock_uploads_is_path_allowed($relPath, $srcLabel, 'products', $pdo, $companyId)) {
        return ['ok' => false, 'message' => 'Access denied: this file belongs to another company or product.'];
    }
    if (stock_uploads_parse_product_variant_rel($relPath) === null) {
        return ['ok' => false, 'message' => 'Not a standard variant path: ' . $relPath];
    }
    $fullPath = realpath($baseDir . '/' . $relPath);
    if (!$fullPath || strpos(str_replace('\\', '/', $fullPath), str_replace('\\', '/', $baseDir)) !== 0 || !is_file($fullPath)) {
        return ['ok' => false, 'message' => 'Invalid or missing file: ' . $relPath];
    }

    return stock_uploads_recycle_variant_file($pdo, $baseDir, $relPath);
}

/**
 * Duplicate-cleanup delete: if keeper and candidate are the same product image (same basename, standard size variants), recycle only that file.
 * Otherwise full catalog delete (DB + all variants) as in stock_uploads_delete_one_relative.
 *
 * @return array{ok:bool,message?:string}
 */
function stock_uploads_delete_duplicate_candidate(PDO $pdo, string $baseDir, string $relKeep, string $relDelete): array
{
    $relKeep = stock_uploads_norm_products_rel($relKeep);
    $relDelete = stock_uploads_norm_products_rel($relDelete);
    if (stock_uploads_same_product_image_variant_pair($relKeep, $relDelete)) {
        return stock_uploads_unlink_product_variant_only($pdo, $baseDir, $relDelete);
    }

    return stock_uploads_delete_one_relative($pdo, $baseDir, $relDelete);
}

function stock_uploads_delete_source_label_for_base(string $baseDir): string
{
    $norm = str_replace('\\', '/', strtolower($baseDir));

    return (strpos($norm, '/storage/tenant_') !== false) ? 'tenant' : 'legacy';
}

function stock_uploads_delete_one_relative(PDO $pdo, string $baseDir, string $relPath): array
{
    $relPath = str_replace(['../', './'], '', $relPath);
    $relPath = ltrim($relPath, '/');
    $sourceLabel = stock_uploads_delete_source_label_for_base($baseDir);
    $companySlug = strtolower(trim((string) ($_SESSION['company_slug'] ?? '')));
    $companyId = function_exists('stock_uploads_resolve_company_id')
        ? stock_uploads_resolve_company_id()
        : (int) ($_SESSION['company_id'] ?? 0);

    $deny = stock_uploads_validate_delete_target($baseDir, $relPath, $companyId, $companySlug, $sourceLabel);
    if ($deny !== null) {
        return ['ok' => false, 'message' => $deny];
    }
    $folder = 'uploads';
    if (strpos($relPath, 'products/') === 0) {
        $folder = 'products';
    } elseif (strpos($relPath, 'categories/') === 0) {
        $folder = 'categories';
    } elseif (strpos($relPath, 'documents/') === 0) {
        $folder = 'documents';
    }
    if (function_exists('stock_company_pdo')) {
        $pdo = stock_company_pdo();
    }
    if (!stock_uploads_is_path_allowed($relPath, $sourceLabel, $folder, $pdo, $companyId)) {
        return ['ok' => false, 'message' => 'Access denied: this file belongs to another company or product.'];
    }
    $baseNorm = str_replace('\\', '/', rtrim(realpath($baseDir) ?: $baseDir, '/'));
    $fullPath = realpath($baseDir . '/' . $relPath);

    if (!$fullPath || strpos(str_replace('\\', '/', $fullPath), $baseNorm) !== 0 || !is_file($fullPath)) {
        return ['ok' => false, 'message' => 'Invalid or missing file: ' . $relPath];
    }

    $parts = explode('/', $relPath);
    if ($parts[0] === 'products' && isset($parts[1]) && is_numeric($parts[1])) {
        $productId = (int) $parts[1];
        $filename = basename($fullPath);

        if ($productId < 1) {
            $zr = stock_uploads_recycle_zero_product_files($pdo, $baseDir, $productId, $filename);
            if (empty($zr['ok'])) {
                return ['ok' => false, 'message' => $zr['message'] ?? 'Recycle failed'];
            }
            if (is_file($fullPath)) {
                @unlink($fullPath);
            }

            return ['ok' => true];
        }

        $begin = stock_uploads_recycle_begin_product_image_set($pdo, $baseDir, $productId, $filename);
        if (empty($begin['ok'])) {
            return ['ok' => false, 'message' => $begin['message'] ?? 'Could not move to recycle bin'];
        }

        $moved = $begin['moved'] ?? [];
        $hadDb = !empty($begin['had_db_row']);
        $db = stock_uploads_recycle_finish_product_image_db($pdo, $productId, $filename, $moved, $hadDb);
        if (empty($db['ok'])) {
            if (!empty($begin['bin_id'])) {
                $pdo->prepare('DELETE FROM upload_recycle_bin WHERE id = ?')->execute([(int) $begin['bin_id']]);
                $left = stock_uploads_recycle_storage_base($baseDir, (int) $begin['bin_id']);
                if (is_dir($left)) {
                    stock_uploads_recycle_rrmdir($left);
                }
            }

            return ['ok' => false, 'message' => $db['message'] ?? 'Database update failed'];
        }

        if (is_file($fullPath)) {
            @unlink($fullPath);
        }

        return ['ok' => true];
    }

    if (strpos($relPath, 'recycle_bin/') === 0) {
        return ['ok' => false, 'message' => 'Use the recycle bin screen to restore or purge.'];
    }

    $or = stock_uploads_recycle_other_file($pdo, $baseDir, $relPath);
    if (!empty($or['ok'])) {
        return ['ok' => true];
    }

    return ['ok' => false, 'message' => $or['message'] ?? 'Could not move to recycle bin'];
}
