<?php
// stock/modules/uploads/uploads_documents_collect.inc.php
// Aggregate company-attached documents for Uploads ? Documents (fast path, no globs).

if (!function_exists('uploads_docs_project_root')) {
    function uploads_docs_project_root()
    {
        static $root = null;
        if ($root !== null) {
            return $root;
        }
        $root = str_replace('\\', '/', realpath(__DIR__ . '/../../..') ?: dirname(__DIR__, 3));
        return $root;
    }
}

if (!function_exists('uploads_docs_table_exists')) {
    function uploads_docs_table_exists(PDO $pdo, $table)
    {
        static $cache = [];
        $table = preg_replace('/[^a-zA-Z0-9_]/', '', (string) $table);
        if ($table === '') {
            return false;
        }
        if (array_key_exists($table, $cache)) {
            return $cache[$table];
        }
        try {
            $cache[$table] = (bool) $pdo->query('SHOW TABLES LIKE ' . $pdo->quote($table))->fetchColumn();
        } catch (Throwable $e) {
            $cache[$table] = false;
        }
        return $cache[$table];
    }
}

if (!function_exists('uploads_docs_web_url_from_rel')) {
    function uploads_docs_web_url_from_rel($rel)
    {
        $rel = ltrim(str_replace('\\', '/', (string) $rel), '/');
        if ($rel === '') {
            return '';
        }
        if (function_exists('app_url')) {
            return rtrim((string) app_url('/' . $rel), '/');
        }
        return '/' . $rel;
    }
}

if (!function_exists('uploads_docs_resolve_fast')) {
    /**
     * Fast resolve: direct path checks only (no glob). Returns [abs|'', webRel].
     *
     * @return array{0:string,1:string}
     */
    function uploads_docs_resolve_fast($rel)
    {
        static $existsCache = [];
        $rel = ltrim(str_replace('\\', '/', trim((string) $rel)), '/');
        if ($rel === '' || preg_match('#^https?://#i', $rel)) {
            return ['', ''];
        }

        $root = uploads_docs_project_root();
        $candidates = [$rel];
        if (strpos($rel, 'uploads/') === 0) {
            $candidates[] = 'stock/' . $rel;
            $candidates[] = 'assets/' . $rel;
        } elseif (strpos($rel, 'assets/uploads/') === 0) {
            $candidates[] = substr($rel, strlen('assets/'));
        } elseif (preg_match('#^releases/#i', $rel)) {
            $candidates[] = 'store-management-system/uploads/' . $rel;
        }

        foreach ($candidates as $webRel) {
            $abs = $root . '/' . $webRel;
            if (isset($existsCache[$abs])) {
                if ($existsCache[$abs]) {
                    return [$abs, $webRel];
                }
                continue;
            }
            $ok = is_file($abs);
            $existsCache[$abs] = $ok;
            if ($ok) {
                return [$abs, $webRel];
            }
        }

        // Keep listing even if missing on disk � URL still useful for debugging/proxy.
        return ['', $rel];
    }
}

if (!function_exists('uploads_docs_push_row')) {
    /**
     * @param list<array<string,mixed>> $out
     * @param array<string,bool> $seen
     */
    function uploads_docs_push_row(array &$out, array &$seen, $relPath, $displayName, $sourceLabel, $maxFiles, $sizeHint = null, $mtimeHint = null)
    {
        if (count($out) >= $maxFiles) {
            return;
        }
        $relPath = ltrim(str_replace('\\', '/', trim((string) $relPath)), '/');
        if ($relPath === '') {
            return;
        }
        $dedupe = strtolower($relPath);
        if (isset($seen[$dedupe])) {
            return;
        }
        $seen[$dedupe] = true;

        [$abs, $webRel] = uploads_docs_resolve_fast($relPath);
        if ($webRel === '') {
            return;
        }

        $name = trim((string) $displayName);
        if ($name === '') {
            $name = basename($webRel);
        }

        $size = $sizeHint !== null ? (int) $sizeHint : 0;
        $mtime = $mtimeHint !== null ? (int) $mtimeHint : 0;
        if ($abs !== '') {
            if ($size <= 0) {
                $size = (int) (@filesize($abs) ?: 0);
            }
            if ($mtime <= 0) {
                $mtime = (int) (@filemtime($abs) ?: 0);
            }
        }

        $url = uploads_docs_web_url_from_rel($webRel);
        if ($url === '') {
            return;
        }

        $out[] = [
            'name' => $name,
            'rel' => $webRel,
            'size' => $size,
            'mtime' => $mtime,
            'is_image' => function_exists('is_image_ext')
                ? is_image_ext($name)
                : (bool) preg_match('/\.(jpe?g|png|gif|webp|bmp|svg)$/i', $name),
            'ext' => strtolower(pathinfo($name, PATHINFO_EXTENSION)),
            'base_url' => '',
            'source' => $sourceLabel,
            'url_override' => $url,
        ];
    }
}

if (!function_exists('uploads_collect_system_documents')) {
    /**
     * @return list<array<string,mixed>>
     */
    function uploads_collect_system_documents(PDO $pdo, $companyId, $maxFiles = 2500)
    {
        $out = [];
        $seen = [];
        $maxFiles = max(100, (int) $maxFiles);

        $run = static function ($sql, $source) use ($pdo, &$out, &$seen, $maxFiles) {
            if (count($out) >= $maxFiles) {
                return;
            }
            try {
                $stmt = $pdo->query($sql);
                if (!$stmt) {
                    return;
                }
                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    if (count($out) >= $maxFiles) {
                        return;
                    }
                    uploads_docs_push_row(
                        $out,
                        $seen,
                        $row['path'] ?? '',
                        $row['label'] ?? '',
                        $source,
                        $maxFiles,
                        isset($row['size_hint']) ? $row['size_hint'] : null,
                        isset($row['mtime_hint']) ? (strtotime((string) $row['mtime_hint']) ?: null) : null
                    );
                }
            } catch (Throwable $e) {
                error_log('uploads_collect_system_documents: ' . $e->getMessage());
            }
        };

        if (uploads_docs_table_exists($pdo, 'voucher_attachments')) {
            $run(
                "SELECT file_path AS path, original_name AS label, size_bytes AS size_hint, uploaded_at AS mtime_hint
                 FROM voucher_attachments
                 WHERE file_path IS NOT NULL AND TRIM(file_path) <> ''
                 ORDER BY id DESC",
                'voucher'
            );
        }
        if (uploads_docs_table_exists($pdo, 'payment_vouchers')) {
            $run(
                "SELECT swift_document AS path, 'SWIFT proof' AS label, NULL AS size_hint, COALESCE(updated_at, created_at, date_created) AS mtime_hint
                 FROM payment_vouchers
                 WHERE swift_document IS NOT NULL AND TRIM(swift_document) <> ''
                 ORDER BY id DESC",
                'swift'
            );
        }
        if (uploads_docs_table_exists($pdo, 'erp_expenses')) {
            $run(
                "SELECT attachment AS path, NULL AS label, NULL AS size_hint, created_at AS mtime_hint
                 FROM erp_expenses
                 WHERE attachment IS NOT NULL AND TRIM(attachment) <> ''
                 ORDER BY id DESC",
                'expense'
            );
        }
        if (uploads_docs_table_exists($pdo, 'stocks_purchase_attachments')) {
            $run(
                "SELECT file_path AS path, file_name AS label, file_size AS size_hint, NULL AS mtime_hint
                 FROM stocks_purchase_attachments
                 WHERE file_path IS NOT NULL AND TRIM(file_path) <> ''
                 ORDER BY id DESC",
                'purchase'
            );
        }
        if (uploads_docs_table_exists($pdo, 'stocks_purchase_orders')) {
            try {
                if ($pdo->query("SHOW COLUMNS FROM `stocks_purchase_orders` LIKE 'invoice_attachment'")->fetchColumn()) {
                    $run(
                        "SELECT invoice_attachment AS path, NULL AS label, NULL AS size_hint, NULL AS mtime_hint
                         FROM stocks_purchase_orders
                         WHERE invoice_attachment IS NOT NULL AND TRIM(invoice_attachment) <> ''
                         ORDER BY id DESC",
                        'purchase_invoice'
                    );
                }
            } catch (Throwable $e) {
            }
        }
        if (uploads_docs_table_exists($pdo, 'store_release_documents')) {
            $run(
                "SELECT file_path AS path, original_name AS label, NULL AS size_hint, created_at AS mtime_hint
                 FROM store_release_documents
                 WHERE file_path IS NOT NULL AND TRIM(file_path) <> ''
                 ORDER BY id DESC",
                'store_release'
            );
        }
        if (uploads_docs_table_exists($pdo, 'store_receipt_documents')) {
            $run(
                "SELECT file_path AS path, original_name AS label, NULL AS size_hint, created_at AS mtime_hint
                 FROM store_receipt_documents
                 WHERE file_path IS NOT NULL AND TRIM(file_path) <> ''
                 ORDER BY id DESC",
                'store_receipt'
            );
        }
        if (uploads_docs_table_exists($pdo, 'message_attachments')) {
            $run(
                "SELECT file_path AS path, file_name AS label, size_bytes AS size_hint, created_at AS mtime_hint
                 FROM message_attachments
                 WHERE file_path IS NOT NULL AND TRIM(file_path) <> ''
                 ORDER BY id DESC",
                'message'
            );
        }
        if (uploads_docs_table_exists($pdo, 'module_email_attachments')) {
            $run(
                "SELECT file_path AS path, file_name AS label, file_size AS size_hint, created_at AS mtime_hint
                 FROM module_email_attachments
                 WHERE file_path IS NOT NULL AND TRIM(file_path) <> ''
                 ORDER BY id DESC",
                'email'
            );
        }
        if (uploads_docs_table_exists($pdo, 'revenue_entries')) {
            try {
                if ($pdo->query("SHOW COLUMNS FROM `revenue_entries` LIKE 'attachment'")->fetchColumn()) {
                    $run(
                        "SELECT attachment AS path, NULL AS label, NULL AS size_hint, NULL AS mtime_hint
                         FROM revenue_entries
                         WHERE attachment IS NOT NULL AND TRIM(attachment) <> ''
                         ORDER BY id DESC",
                        'revenue'
                    );
                }
            } catch (Throwable $e) {
            }
        }
        if (uploads_docs_table_exists($pdo, 'attachments')) {
            $run(
                "SELECT file_path AS path, file_name AS label, file_size AS size_hint, uploaded_at AS mtime_hint
                 FROM attachments
                 WHERE file_path IS NOT NULL AND TRIM(file_path) <> ''
                 ORDER BY id DESC",
                'attachment'
            );
        }
        if (uploads_docs_table_exists($pdo, 'petty_cash_vouchers')) {
            try {
                if ($pdo->query("SHOW COLUMNS FROM `petty_cash_vouchers` LIKE 'receipt_path'")->fetchColumn()) {
                    $run(
                        "SELECT receipt_path AS path, NULL AS label, NULL AS size_hint, COALESCE(updated_at, created_at, date) AS mtime_hint
                         FROM petty_cash_vouchers
                         WHERE receipt_path IS NOT NULL AND TRIM(receipt_path) <> ''
                         ORDER BY id DESC",
                        'petty_cash'
                    );
                }
            } catch (Throwable $e) {
            }
        }
        // Some installs use petty_cash without the _vouchers suffix.
        if (uploads_docs_table_exists($pdo, 'petty_cash')) {
            try {
                if ($pdo->query("SHOW COLUMNS FROM `petty_cash` LIKE 'receipt_path'")->fetchColumn()) {
                    $run(
                        "SELECT receipt_path AS path, NULL AS label, NULL AS size_hint, NULL AS mtime_hint
                         FROM petty_cash
                         WHERE receipt_path IS NOT NULL AND TRIM(receipt_path) <> ''
                         ORDER BY id DESC",
                        'petty_cash'
                    );
                }
            } catch (Throwable $e) {
            }
        }
        if (uploads_docs_table_exists($pdo, 'expenses_requests')) {
            try {
                if ($pdo->query("SHOW COLUMNS FROM `expenses_requests` LIKE 'receipt_path'")->fetchColumn()) {
                    $run(
                        "SELECT receipt_path AS path, NULL AS label, NULL AS size_hint, NULL AS mtime_hint
                         FROM expenses_requests
                         WHERE receipt_path IS NOT NULL AND TRIM(receipt_path) <> ''
                         ORDER BY id DESC",
                        'finance_expense'
                    );
                }
            } catch (Throwable $e) {
            }
        }
        if (uploads_docs_table_exists($pdo, 'outstanding_invoices')) {
            try {
                $cols = $pdo->query('SHOW COLUMNS FROM `outstanding_invoices`')->fetchAll(PDO::FETCH_COLUMN) ?: [];
                $pathCol = null;
                foreach (['attachment', 'attachment_path', 'file_path', 'document_path'] as $candidate) {
                    if (in_array($candidate, $cols, true)) {
                        $pathCol = $candidate;
                        break;
                    }
                }
                if ($pathCol !== null) {
                    $run(
                        "SELECT `{$pathCol}` AS path, NULL AS label, NULL AS size_hint, NULL AS mtime_hint
                         FROM outstanding_invoices
                         WHERE `{$pathCol}` IS NOT NULL AND TRIM(`{$pathCol}`) <> ''
                         ORDER BY id DESC",
                        'invoice'
                    );
                }
            } catch (Throwable $e) {
            }
        }
        if (uploads_docs_table_exists($pdo, 'deliveries')) {
            try {
                $cols = $pdo->query('SHOW COLUMNS FROM `deliveries`')->fetchAll(PDO::FETCH_COLUMN) ?: [];
                foreach (['receipt_path', 'delivery_note', 'attachment', 'file_path'] as $candidate) {
                    if (!in_array($candidate, $cols, true)) {
                        continue;
                    }
                    $run(
                        "SELECT `{$candidate}` AS path, NULL AS label, NULL AS size_hint, NULL AS mtime_hint
                         FROM deliveries
                         WHERE `{$candidate}` IS NOT NULL AND TRIM(`{$candidate}`) <> ''
                         ORDER BY id DESC",
                        'delivery'
                    );
                }
            } catch (Throwable $e) {
            }
        }
        if (uploads_docs_table_exists($pdo, 'delivery_evidence') || uploads_docs_table_exists($pdo, 'delivery_pod')) {
            $table = uploads_docs_table_exists($pdo, 'delivery_evidence') ? 'delivery_evidence' : 'delivery_pod';
            try {
                $cols = $pdo->query("SHOW COLUMNS FROM `{$table}`")->fetchAll(PDO::FETCH_COLUMN) ?: [];
                $pathCol = null;
                foreach (['file_path', 'evidence_path', 'photo_path', 'attachment', 'path'] as $candidate) {
                    if (in_array($candidate, $cols, true)) {
                        $pathCol = $candidate;
                        break;
                    }
                }
                if ($pathCol !== null) {
                    $run(
                        "SELECT `{$pathCol}` AS path, NULL AS label, NULL AS size_hint, NULL AS mtime_hint
                         FROM `{$table}`
                         WHERE `{$pathCol}` IS NOT NULL AND TRIM(`{$pathCol}`) <> ''
                         ORDER BY id DESC",
                        'evidence'
                    );
                }
            } catch (Throwable $e) {
            }
        }
        if (uploads_docs_table_exists($pdo, 'trips') || uploads_docs_table_exists($pdo, 'trip_attachments')) {
            if (uploads_docs_table_exists($pdo, 'trip_attachments')) {
                try {
                    $cols = $pdo->query('SHOW COLUMNS FROM `trip_attachments`')->fetchAll(PDO::FETCH_COLUMN) ?: [];
                    $pathCol = in_array('file_path', $cols, true) ? 'file_path'
                        : (in_array('attachment', $cols, true) ? 'attachment'
                        : (in_array('path', $cols, true) ? 'path' : null));
                    $labelExpr = 'NULL';
                    if (in_array('file_name', $cols, true)) {
                        $labelExpr = '`file_name`';
                    } elseif (in_array('original_name', $cols, true)) {
                        $labelExpr = '`original_name`';
                    }
                    if ($pathCol !== null) {
                        $run(
                            "SELECT `{$pathCol}` AS path, {$labelExpr} AS label, NULL AS size_hint, NULL AS mtime_hint
                             FROM trip_attachments
                             WHERE `{$pathCol}` IS NOT NULL AND TRIM(`{$pathCol}`) <> ''
                             ORDER BY id DESC",
                            'trip'
                        );
                    }
                } catch (Throwable $e) {
                }
            }
            if (uploads_docs_table_exists($pdo, 'trips')) {
                try {
                    $cols = $pdo->query('SHOW COLUMNS FROM `trips`')->fetchAll(PDO::FETCH_COLUMN) ?: [];
                    foreach (['attachment', 'attachment_path', 'file_path'] as $candidate) {
                        if (!in_array($candidate, $cols, true)) {
                            continue;
                        }
                        $run(
                            "SELECT `{$candidate}` AS path, NULL AS label, NULL AS size_hint, NULL AS mtime_hint
                             FROM trips
                             WHERE `{$candidate}` IS NOT NULL AND TRIM(`{$candidate}`) <> ''
                             ORDER BY id DESC",
                            'trip'
                        );
                    }
                } catch (Throwable $e) {
                }
            }
        }

        return $out;
    }
}

if (!function_exists('uploads_documents_to_payload')) {
    /**
     * @param list<array<string,mixed>> $files
     * @return list<array<string,mixed>>
     */
    function uploads_documents_to_payload(array $files)
    {
        $payload = [];
        foreach ($files as $f) {
            $rel = (string) ($f['rel'] ?? '');
            $url = !empty($f['url_override'])
                ? (string) $f['url_override']
                : uploads_docs_web_url_from_rel($rel);
            $size = (int) ($f['size'] ?? 0);
            $payload[] = [
                'name' => (string) ($f['name'] ?? ''),
                'rel' => $rel,
                'size' => $size,
                'size_label' => function_exists('human_size') ? human_size($size) : (string) $size,
                'mtime' => (int) ($f['mtime'] ?? 0),
                'is_image' => !empty($f['is_image']),
                'ext' => (string) ($f['ext'] ?? ''),
                'url' => $url,
                'source' => (string) ($f['source'] ?? 'system'),
            ];
        }
        return $payload;
    }
}
