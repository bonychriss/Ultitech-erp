<?php
/**
 * Upload recycle bin: DB table + files under uploads/recycle_bin/items/{id}/.
 */

function stock_uploads_recycle_ensure_schema(PDO $pdo)
{
    static $done = false;
    if ($done) {
        return;
    }
    $done = true;
    $sql = 'CREATE TABLE IF NOT EXISTS upload_recycle_bin (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        user_id INT UNSIGNED NULL,
        kind VARCHAR(32) NOT NULL,
        label VARCHAR(512) NULL,
        product_id INT UNSIGNED NULL,
        image_name VARCHAR(255) NULL,
        restore_json LONGTEXT NOT NULL,
        storage_prefix VARCHAR(255) NOT NULL,
        KEY idx_created (created_at),
        KEY idx_product (product_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci';
    try {
        $pdo->exec($sql);
    } catch (Throwable $e) {
        error_log('stock_uploads_recycle_ensure_schema: ' . $e->getMessage());
    }
}

/** @return array{product_id:int,basename:string}|null */
function stock_uploads_recycle_parse_products_meta($relPath)
{
    $r = str_replace(['../', './'], '', trim($relPath));
    $r = ltrim($r, '/');
    if (strpos($r, 'products/') !== 0) {
        $r = 'products/' . $r;
    }
    $inner = substr($r, strlen('products/'));
    $parts = explode('/', $inner);
    if (count($parts) < 3 || !ctype_digit($parts[0])) {
        return null;
    }
    $basename = implode('/', array_slice($parts, 2));
    if ($basename === '' || strpos($basename, '/') !== false) {
        return null;
    }

    return ['product_id' => (int) $parts[0], 'basename' => $basename];
}

function stock_uploads_recycle_current_user_id()
{
    if (!isset($_SESSION['user_id'])) {
        return null;
    }
    $u = (int) $_SESSION['user_id'];

    return $u > 0 ? $u : null;
}

function stock_uploads_recycle_storage_base(string $baseDir, int $binId): string
{
    return rtrim($baseDir, "/\\") . '/recycle_bin/items/' . $binId;
}

function stock_uploads_recycle_storage_prefix(int $binId): string
{
    return 'recycle_bin/items/' . $binId;
}

/**
 * Move product variant files from live uploads into bin. Returns [src, dest] pairs (dest is under bin).
 *
 * @return list<array{0:string,1:string}>
 */
function stock_uploads_recycle_move_product_variants_into(string $baseDir, int $productId, string $filename, int $binId): array
{
    $moved = [];
    $destBase = stock_uploads_recycle_storage_base($baseDir, $binId);
    foreach (['original', 'thumbnail', 'medium', 'large'] as $folder) {
        $rel = 'products/' . $productId . '/' . $folder . '/' . $filename;
        $src = $baseDir . '/' . $rel;
        if (!is_file($src)) {
            continue;
        }
        $dest = $destBase . '/' . $rel;
        $destDir = dirname($dest);
        if (!is_dir($destDir) && !@mkdir($destDir, 0755, true)) {
            stock_uploads_recycle_undo_path_moves($moved);

            throw new RuntimeException('Could not create recycle folder.');
        }
        if (!@rename($src, $dest)) {
            stock_uploads_recycle_undo_path_moves($moved);

            throw new RuntimeException('Could not move file to recycle: ' . $rel);
        }
        $moved[] = [$src, $dest];
    }

    return $moved;
}

/**
 * @param list<array{0:string,1:string}> $pairs (src, dest) from a successful move-into-bin
 */
function stock_uploads_recycle_undo_path_moves(array $pairs)
{
    foreach (array_reverse($pairs) as $pair) {
        if (isset($pair[0], $pair[1]) && is_file($pair[1])) {
            $dir = dirname($pair[0]);
            if (!is_dir($dir)) {
                @mkdir($dir, 0755, true);
            }
            @rename($pair[1], $pair[0]);
        }
    }
}

/**
 * Move one live file into bin, mirroring rel path under storage (e.g. products/1/large/x.jpg).
 *
 * @return list<array{0:string,1:string}>
 */
function stock_uploads_recycle_move_single_rel_into(string $baseDir, string $relPath, int $binId): array
{
    $relPath = str_replace(['../', './'], '', $relPath);
    $relPath = ltrim($relPath, '/');
    $src = $baseDir . '/' . $relPath;
    if (!is_file($src)) {
        return [];
    }
    $dest = stock_uploads_recycle_storage_base($baseDir, $binId) . '/' . $relPath;
    $destDir = dirname($dest);
    if (!is_dir($destDir) && !@mkdir($destDir, 0755, true)) {
        throw new RuntimeException('Could not create recycle folder.');
    }
    if (!@rename($src, $dest)) {
        throw new RuntimeException('Could not move file to recycle: ' . $relPath);
    }

    return [[$src, $dest]];
}

function stock_uploads_recycle_rrmdir($dir)
{
    if (!is_dir($dir)) {
        return;
    }
    $it = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS),
        RecursiveIteratorIterator::CHILD_FIRST
    );
    foreach ($it as $f) {
        $p = $f->getPathname();
        if ($f->isDir()) {
            @rmdir($p);
        } else {
            @unlink($p);
        }
    }
    @rmdir($dir);
}

/**
 * Undo DB delete for a product image using snapshot (after failed file move post-commit � rare).
 */
function stock_uploads_recycle_db_restore_product_image(PDO $pdo, array $restore)
{
    $row = $restore['product_image'] ?? null;
    if (!is_array($row) || empty($row['product_id']) || empty($row['image_name'])) {
        return;
    }
    $pid = (int) $row['product_id'];
    $name = (string) $row['image_name'];
    $isPrimary = (int) ($row['is_primary'] ?? 0);
    $uploadedBy = isset($row['uploaded_by']) ? ($row['uploaded_by'] !== null ? (int) $row['uploaded_by'] : null) : null;

    $ins = $pdo->prepare('INSERT INTO product_images (product_id, image_name, is_primary, uploaded_by) VALUES (?, ?, ?, ?)');
    $ins->execute([$pid, $name, $isPrimary ? 1 : 0, $uploadedBy]);

    $newId = (int) $pdo->lastInsertId();
    if ($isPrimary) {
        $pdo->prepare('UPDATE product_images SET is_primary = 0 WHERE product_id = ? AND id != ?')->execute([$pid, $newId]);
        $pdo->prepare('UPDATE product_images SET is_primary = 1 WHERE id = ?')->execute([$newId]);
    }
    if (array_key_exists('products_main_image_before', $restore)) {
        $mainBefore = $restore['products_main_image_before'];
        $pdo->prepare('UPDATE products SET main_image = ? WHERE id = ?')->execute([$mainBefore !== null && $mainBefore !== '' ? $mainBefore : null, $pid]);
    }
}

/**
 * Register bin row + move files into bin for a full product-image delete. Does not change product_images yet.
 *
 * @return array{ok:bool,bin_id?:int,restore?:array,moved?:list<array{0:string,1:string}>,message?:string}
 */
function stock_uploads_recycle_begin_product_image_set(PDO $pdo, string $baseDir, int $productId, string $filename): array
{
    stock_uploads_recycle_ensure_schema($pdo);

    $piRow = null;
    try {
        $st = $pdo->prepare('SELECT * FROM product_images WHERE product_id = ? AND image_name = ? LIMIT 1');
        $st->execute([$productId, $filename]);
        $piRow = $st->fetch(PDO::FETCH_ASSOC) ?: null;
    } catch (Throwable $e) {
        $piRow = null;
    }

    $mainBefore = null;
    try {
        $st = $pdo->prepare('SELECT main_image FROM products WHERE id = ? LIMIT 1');
        $st->execute([$productId]);
        $mainBefore = $st->fetchColumn();
        $mainBefore = $mainBefore !== false ? (string) $mainBefore : null;
    } catch (Throwable $e) {
        $mainBefore = null;
    }

    $restore = [
        'version' => 1,
        'had_db_row' => $piRow !== null,
        'product_image' => $piRow,
        'products_main_image_before' => $mainBefore,
    ];

    $label = 'Product #' . $productId . ': ' . $filename;
    $uid = stock_uploads_recycle_current_user_id();

    $pdo->prepare('INSERT INTO upload_recycle_bin (user_id, kind, label, product_id, image_name, restore_json, storage_prefix) VALUES (?, ?, ?, ?, ?, ?, ?)')
        ->execute([$uid, 'product_image_set', $label, $productId, $filename, json_encode($restore, JSON_UNESCAPED_UNICODE), '']);

    $binId = (int) $pdo->lastInsertId();
    $prefix = stock_uploads_recycle_storage_prefix($binId);
    $pdo->prepare('UPDATE upload_recycle_bin SET storage_prefix = ? WHERE id = ?')->execute([$prefix, $binId]);

    try {
        $moved = stock_uploads_recycle_move_product_variants_into($baseDir, $productId, $filename, $binId);
    } catch (Throwable $e) {
        $pdo->prepare('DELETE FROM upload_recycle_bin WHERE id = ?')->execute([$binId]);

        return ['ok' => false, 'message' => $e->getMessage()];
    }

    return ['ok' => true, 'bin_id' => $binId, 'restore' => $restore, 'moved' => $moved, 'had_db_row' => $piRow !== null];
}

/**
 * @param list<array{0:string,1:string}> $moved
 */
function stock_uploads_recycle_finish_product_image_db(PDO $pdo, int $productId, string $filename, array $moved, bool $hadDbRow): array
{
    try {
        $pdo->beginTransaction();
        if ($hadDbRow) {
            $pdo->prepare('DELETE FROM product_images WHERE product_id = ? AND image_name = ?')->execute([$productId, $filename]);
            $pdo->prepare('UPDATE products SET main_image = NULL WHERE id = ? AND main_image = ?')->execute([$productId, $filename]);

            $stmtCheck = $pdo->prepare('SELECT image_name FROM product_images WHERE product_id = ? ORDER BY is_primary DESC, id ASC LIMIT 1');
            $stmtCheck->execute([$productId]);
            $newMain = $stmtCheck->fetchColumn();
            if ($newMain) {
                $pdo->prepare('UPDATE products SET main_image = ? WHERE id = ?')->execute([(string) $newMain, $productId]);
            }
        }
        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        stock_uploads_recycle_undo_path_moves($moved);

        return ['ok' => false, 'message' => $e->getMessage()];
    }

    return ['ok' => true];
}

/**
 * Variant-only or stray product file: bin row + single file move, no DB changes.
 */
function stock_uploads_recycle_variant_file(PDO $pdo, string $baseDir, string $relPath): array
{
    stock_uploads_recycle_ensure_schema($pdo);
    $relPath = str_replace(['../', './'], '', $relPath);
    $relPath = ltrim($relPath, '/');
    if (strpos($relPath, 'products/') !== 0) {
        $relPath = 'products/' . $relPath;
    }

    $parsed = stock_uploads_recycle_parse_products_meta($relPath);
    $label = $relPath;
    $pid = $parsed['product_id'] ?? null;
    $imgName = $parsed['basename'] ?? null;

    $restore = [
        'version' => 1,
        'kind' => 'variant_file',
        'rel_path' => $relPath,
    ];

    $uid = stock_uploads_recycle_current_user_id();
    $pdo->prepare('INSERT INTO upload_recycle_bin (user_id, kind, label, product_id, image_name, restore_json, storage_prefix) VALUES (?, ?, ?, ?, ?, ?, ?)')
        ->execute([$uid, 'variant_file', $label, $pid, $imgName, json_encode($restore, JSON_UNESCAPED_UNICODE), '']);

    $binId = (int) $pdo->lastInsertId();
    $prefix = stock_uploads_recycle_storage_prefix($binId);
    $pdo->prepare('UPDATE upload_recycle_bin SET storage_prefix = ? WHERE id = ?')->execute([$prefix, $binId]);

    try {
        stock_uploads_recycle_move_single_rel_into($baseDir, $relPath, $binId);
    } catch (Throwable $e) {
        $pdo->prepare('DELETE FROM upload_recycle_bin WHERE id = ?')->execute([$binId]);

        return ['ok' => false, 'message' => $e->getMessage()];
    }

    return ['ok' => true];
}

/**
 * Non-product file under uploads (e.g. categories/...).
 */
function stock_uploads_recycle_other_file(PDO $pdo, string $baseDir, string $relPath): array
{
    stock_uploads_recycle_ensure_schema($pdo);
    $relPath = str_replace(['../', './'], '', $relPath);
    $relPath = ltrim($relPath, '/');
    if (strpos($relPath, 'recycle_bin/') === 0) {
        return ['ok' => false, 'message' => 'Invalid path.'];
    }

    $restore = ['version' => 1, 'kind' => 'other_file', 'rel_path' => $relPath];
    $uid = stock_uploads_recycle_current_user_id();
    $pdo->prepare('INSERT INTO upload_recycle_bin (user_id, kind, label, product_id, image_name, restore_json, storage_prefix) VALUES (?, ?, ?, NULL, NULL, ?, ?)')
        ->execute([$uid, 'other_file', $relPath, json_encode($restore, JSON_UNESCAPED_UNICODE), '']);

    $binId = (int) $pdo->lastInsertId();
    $prefix = stock_uploads_recycle_storage_prefix($binId);
    $pdo->prepare('UPDATE upload_recycle_bin SET storage_prefix = ? WHERE id = ?')->execute([$prefix, $binId]);

    try {
        stock_uploads_recycle_move_single_rel_into($baseDir, $relPath, $binId);
    } catch (Throwable $e) {
        $pdo->prepare('DELETE FROM upload_recycle_bin WHERE id = ?')->execute([$binId]);

        return ['ok' => false, 'message' => $e->getMessage()];
    }

    return ['ok' => true];
}

/**
 * product_id folder under 1: move files to bin, no DB row.
 */
function stock_uploads_recycle_zero_product_files(PDO $pdo, string $baseDir, int $productId, string $filename): array
{
    stock_uploads_recycle_ensure_schema($pdo);
    $restore = [
        'version' => 1,
        'kind' => 'zero_product_files',
        'product_id' => $productId,
        'filename' => $filename,
    ];
    $uid = stock_uploads_recycle_current_user_id();
    $label = 'Quarantine product folder #' . $productId . ': ' . $filename;
    $pdo->prepare('INSERT INTO upload_recycle_bin (user_id, kind, label, product_id, image_name, restore_json, storage_prefix) VALUES (?, ?, ?, ?, ?, ?, ?)')
        ->execute([$uid, 'zero_product_files', $label, $productId, $filename, json_encode($restore, JSON_UNESCAPED_UNICODE), '']);

    $binId = (int) $pdo->lastInsertId();
    $prefix = stock_uploads_recycle_storage_prefix($binId);
    $pdo->prepare('UPDATE upload_recycle_bin SET storage_prefix = ? WHERE id = ?')->execute([$prefix, $binId]);

    try {
        $moved = stock_uploads_recycle_move_product_variants_into($baseDir, $productId, $filename, $binId);
    } catch (Throwable $e) {
        $pdo->prepare('DELETE FROM upload_recycle_bin WHERE id = ?')->execute([$binId]);

        return ['ok' => false, 'message' => $e->getMessage()];
    }

    return ['ok' => true, 'moved' => $moved];
}

/**
 * Move tree from bin storage back under uploads root; returns pairs [src in bin, dest live].
 *
 * @return list<array{0:string,1:string}>
 */
function stock_uploads_recycle_collect_files_under(string $dir): array
{
    $dirR = realpath($dir);
    if ($dirR === false || !is_dir($dirR)) {
        return [];
    }
    $dirR = str_replace('\\', '/', rtrim($dirR, '/'));
    $out = [];
    $it = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($dirR, FilesystemIterator::SKIP_DOTS)
    );
    foreach ($it as $f) {
        if (!$f->isFile()) {
            continue;
        }
        $full = str_replace('\\', '/', $f->getPathname());
        if (strpos($full, $dirR) !== 0) {
            continue;
        }
        $relFromItem = ltrim(substr($full, strlen($dirR)), '/');
        $out[] = [$full, $relFromItem];
    }

    return $out;
}

/**
 * @param list<array{0:string,1:string}> $applied (file in bin, restored live path)
 */
function stock_uploads_recycle_undo_restore_file_moves(array $applied)
{
    foreach (array_reverse($applied) as $pair) {
        if (!isset($pair[0], $pair[1])) {
            continue;
        }
        $srcInBin = $pair[0];
        $destLive = $pair[1];
        if (!is_file($destLive)) {
            continue;
        }
        $binDir = dirname($srcInBin);
        if (!is_dir($binDir)) {
            @mkdir($binDir, 0755, true);
        }
        @rename($destLive, $srcInBin);
    }
}

/**
 * Restore one bin item (files + DB when applicable).
 *
 * @return array{ok:bool,message?:string}
 */
function stock_uploads_recycle_restore(PDO $pdo, string $baseDir, int $binId): array
{
    stock_uploads_recycle_ensure_schema($pdo);
    $st = $pdo->prepare('SELECT * FROM upload_recycle_bin WHERE id = ? LIMIT 1');
    $st->execute([$binId]);
    $row = $st->fetch(PDO::FETCH_ASSOC);
    if (!$row) {
        return ['ok' => false, 'message' => 'Item not found.'];
    }

    $restore = json_decode((string) $row['restore_json'], true);
    if (!is_array($restore)) {
        return ['ok' => false, 'message' => 'Invalid restore data.'];
    }

    $kind = (string) $row['kind'];
    $prefix = (string) $row['storage_prefix'];
    $storage = $baseDir . '/' . $prefix;
    $storageReal = realpath($storage);

    if ($kind === 'product_image_set') {
        $pi = $restore['product_image'] ?? null;
        if (is_array($pi) && !empty($restore['had_db_row'])) {
            $pid = (int) $pi['product_id'];
            $name = (string) $pi['image_name'];
            $chk = $pdo->prepare('SELECT COUNT(*) FROM product_images WHERE product_id = ? AND image_name = ?');
            $chk->execute([$pid, $name]);
            if ((int) $chk->fetchColumn() > 0) {
                return ['ok' => false, 'message' => 'That image is already linked again; remove the duplicate row or purge this bin entry instead.'];
            }
        }
    }

    $pairs = ($storageReal !== false && is_dir($storageReal))
        ? stock_uploads_recycle_collect_files_under($storageReal)
        : [];
    $applied = [];

    foreach ($pairs as $pair) {
        $srcFull = $pair[0];
        $relTail = $pair[1];
        $destFull = $baseDir . '/' . $relTail;
        $destDir = dirname($destFull);
        if (!is_dir($destDir) && !@mkdir($destDir, 0755, true)) {
            stock_uploads_recycle_undo_restore_file_moves($applied);

            return ['ok' => false, 'message' => 'Could not create folder for restore: ' . $relTail];
        }
        if (is_file($destFull)) {
            stock_uploads_recycle_undo_restore_file_moves($applied);

            return ['ok' => false, 'message' => 'Target already exists (refusing overwrite): ' . $relTail];
        }
        if (!@rename($srcFull, $destFull)) {
            stock_uploads_recycle_undo_restore_file_moves($applied);

            return ['ok' => false, 'message' => 'Could not restore file: ' . $relTail];
        }
        $applied[] = [$srcFull, $destFull];
    }

    try {
        if ($kind === 'product_image_set' && !empty($restore['had_db_row'])) {
            $pdo->beginTransaction();
            stock_uploads_recycle_db_restore_product_image($pdo, $restore);
            $pdo->commit();
        }
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        stock_uploads_recycle_undo_restore_file_moves($applied);

        return ['ok' => false, 'message' => $e->getMessage()];
    }

    if (is_dir($storage)) {
        stock_uploads_recycle_rrmdir($storage);
    }
    $pdo->prepare('DELETE FROM upload_recycle_bin WHERE id = ?')->execute([$binId]);

    return ['ok' => true];
}

/**
 * Permanently delete bin item (disk + row).
 *
 * @return array{ok:bool,message?:string}
 */
function stock_uploads_recycle_purge(PDO $pdo, string $baseDir, int $binId): array
{
    stock_uploads_recycle_ensure_schema($pdo);
    $st = $pdo->prepare('SELECT storage_prefix FROM upload_recycle_bin WHERE id = ? LIMIT 1');
    $st->execute([$binId]);
    $prefix = $st->fetchColumn();
    if ($prefix === false || $prefix === '') {
        return ['ok' => false, 'message' => 'Item not found.'];
    }
    $storage = $baseDir . '/' . $prefix;
    if (is_dir($storage)) {
        stock_uploads_recycle_rrmdir($storage);
    }
    $pdo->prepare('DELETE FROM upload_recycle_bin WHERE id = ?')->execute([$binId]);

    return ['ok' => true];
}

/**
 * @param string $path
 */
function stock_uploads_recycle_is_image_path($path)
{
    $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));

    return in_array($ext, array('jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp', 'svg'), true);
}

/**
 * Pick the best on-disk preview for a recycle-bin item (thumbnail preferred).
 *
 * @return string|null Absolute path to an image file
 */
function stock_uploads_recycle_preview_file_path(string $baseDir, int $binId)
{
    $storage = stock_uploads_recycle_storage_base($baseDir, $binId);
    $storageReal = realpath($storage);
    if ($storageReal === false || !is_dir($storageReal)) {
        return null;
    }

    $files = stock_uploads_recycle_collect_files_under($storageReal);
    if (empty($files)) {
        return null;
    }

    $bestPath = null;
    $bestScore = -1;
    foreach ($files as $pair) {
        if (!isset($pair[0], $pair[1])) {
            continue;
        }
        $full = (string) $pair[0];
        $rel = str_replace('\\', '/', (string) $pair[1]);
        if (!is_file($full) || !stock_uploads_recycle_is_image_path($full)) {
            continue;
        }
        $score = 0;
        if (strpos($rel, '/thumbnail/') !== false || strpos($rel, 'thumbnail/') === 0) {
            $score = 40;
        } elseif (strpos($rel, '/medium/') !== false || strpos($rel, 'medium/') === 0) {
            $score = 30;
        } elseif (strpos($rel, '/large/') !== false || strpos($rel, 'large/') === 0) {
            $score = 20;
        } elseif (strpos($rel, '/original/') !== false || strpos($rel, 'original/') === 0) {
            $score = 10;
        } else {
            $score = 1;
        }
        if ($score > $bestScore) {
            $bestScore = $score;
            $bestPath = $full;
        }
    }

    return $bestPath;
}
