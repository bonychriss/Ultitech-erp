<?php
/**
 * How strongly a product upload path is tied to DB (higher = safer default to KEEP when deduping).
 *
 * @return array{score:int, hints:string[]}
 */
function stock_upload_rel_usage_score(PDO $pdo, string $rel): array
{
    $rel = str_replace(['../', './'], '', trim($rel));
    $rel = ltrim($rel, '/');
    $basename = basename($rel);
    $parts = explode('/', $rel, 2);
    $pid = (isset($parts[0]) && ctype_digit($parts[0])) ? (int) $parts[0] : null;

    $score = 0;
    $hints = [];

    try {
        $pdo->query('SELECT 1 FROM product_images LIMIT 1');
        $hasPi = true;
    } catch (Throwable $e) {
        $hasPi = false;
    }

    if ($hasPi) {
        try {
            if ($pid !== null) {
                $st = $pdo->prepare('SELECT is_primary FROM product_images WHERE product_id = ? AND image_name = ? LIMIT 1');
                $st->execute([$pid, $basename]);
                $row = $st->fetch(PDO::FETCH_ASSOC);
                if ($row) {
                    if (!empty($row['is_primary'])) {
                        $score += 35;
                        $hints[] = 'product_images (primary)';
                    } else {
                        $score += 15;
                        $hints[] = 'product_images';
                    }
                }
            } else {
                $st = $pdo->prepare('SELECT COUNT(*) FROM product_images WHERE image_name = ?');
                $st->execute([$basename]);
                if ((int) $st->fetchColumn() > 0) {
                    $score += 12;
                    $hints[] = 'product_images (any product)';
                }
            }
        } catch (Throwable $e) {
        }
    }

    try {
        $pdo->query('SELECT main_image FROM products LIMIT 1');
        if ($pid !== null) {
            $st = $pdo->prepare("SELECT id FROM products WHERE id = ? AND NULLIF(TRIM(main_image), '') = ? LIMIT 1");
            $st->execute([$pid, $basename]);
            if ($st->fetchColumn()) {
                $score += 50;
                $hints[] = 'main_image';
            }
        } else {
            $st = $pdo->prepare("SELECT COUNT(*) FROM products WHERE NULLIF(TRIM(main_image), '') IS NOT NULL AND (main_image = ? OR main_image LIKE ?)");
            $st->execute([$basename, '%/' . $basename]);
            if ((int) $st->fetchColumn() > 0) {
                $score += 25;
                $hints[] = 'main_image (any)';
            }
        }
    } catch (Throwable $e) {
    }

    try {
        $pdo->query('SELECT image FROM products LIMIT 1');
        if ($pid !== null) {
            $st = $pdo->prepare("SELECT id FROM products WHERE id = ? AND NULLIF(TRIM(image), '') = ? LIMIT 1");
            $st->execute([$pid, $basename]);
            if ($st->fetchColumn()) {
                $score += 8;
                $hints[] = 'legacy image';
            }
        }
    } catch (Throwable $e) {
    }

    return ['score' => $score, 'hints' => $hints];
}
